const { setup, tokenFor, bearer } = require('./helpers');

let ctx;
beforeEach(async () => {
  ctx = await setup();
});

const newPet = {
  name: 'Biscuit', species: 'dog', breed: 'Aspin', age_years: 1.5, gender: 'female', size: 'small',
  description: 'Sweet and calm.', medical: { vaccinated: true, neutered_spayed: false, notes: '' },
};

test('lists pets with medical info and supports filters', async () => {
  const all = await ctx.api.get('/api/pets');
  expect(all.body).toHaveLength(8);
  expect(all.body[0].medical).toEqual(expect.objectContaining({ vaccinated: expect.any(Boolean) }));

  expect((await ctx.api.get('/api/pets?species=cat')).body.every((p) => p.species === 'cat')).toBe(true);
  expect((await ctx.api.get('/api/pets?age=under1')).body.map((p) => p.name)).toEqual(['Ube']);
  expect((await ctx.api.get('/api/pets?age=over5')).body.map((p) => p.name)).toEqual(['Tiger']);
  expect((await ctx.api.get('/api/pets?status=reserved')).body.map((p) => p.name)).toEqual(['Choco']);
  expect((await ctx.api.get('/api/pets?size=huge')).status).toBe(400);
});

test('GET /:id returns one pet or 404', async () => {
  const { id } = await ctx.db.one("SELECT id FROM pets WHERE name = 'Mango'");
  const res = await ctx.api.get(`/api/pets/${id}`);
  expect(res.body).toMatchObject({ name: 'Mango', age_years: 2, date_listed: '2026-09-30' });
  expect(res.body.medical.notes).toMatch(/fracture/);
  expect((await ctx.api.get('/api/pets/9999')).status).toBe(404);
  expect((await ctx.api.get('/api/pets/abc')).status).toBe(404);
});

test('admin can add, edit and archive a pet', async () => {
  const token = await tokenFor(ctx.app, 'admin');
  const created = await ctx.api.post('/api/pets').set(bearer(token)).send(newPet);
  expect(created.status).toBe(201);
  expect(created.body).toMatchObject({ name: 'Biscuit', status: 'available', age_years: 1.5 });
  expect(created.body.medical.vaccinated).toBe(true);

  const edited = await ctx.api.put(`/api/pets/${created.body.id}`).set(bearer(token)).send({ ...newPet, name: 'Biscuit Jr', medical: { vaccinated: true, neutered_spayed: true, notes: 'Done' } });
  expect(edited.body.name).toBe('Biscuit Jr');
  expect(edited.body.medical.neutered_spayed).toBe(true);

  const archived = await ctx.api.patch(`/api/pets/${created.body.id}/archive`).set(bearer(token));
  expect(archived.body.status).toBe('archived');
  // hidden from the public
  expect((await ctx.api.get('/api/pets')).body.map((p) => p.id)).not.toContain(created.body.id);
  expect((await ctx.api.get(`/api/pets/${created.body.id}`)).status).toBe(404);
  // still visible to admins
  const adminList = await ctx.api.get('/api/pets?includeArchived=true').set(bearer(token));
  expect(adminList.body.map((p) => p.id)).toContain(created.body.id);
});

test('non-admins cannot change pets', async () => {
  const token = await tokenFor(ctx.app, 'employee');
  expect((await ctx.api.post('/api/pets').set(bearer(token)).send(newPet)).status).toBe(403);
  expect((await ctx.api.patch('/api/pets/1/archive').set(bearer(token))).status).toBe(403);
});

test('validates pet fields', async () => {
  const token = await tokenFor(ctx.app, 'admin');
  const res = await ctx.api.post('/api/pets').set(bearer(token)).send({ ...newPet, species: 'bird', age_years: -1 });
  expect(res.status).toBe(400);
  expect(Object.keys(res.body.error.fields)).toEqual(expect.arrayContaining(['species', 'age_years']));
});
