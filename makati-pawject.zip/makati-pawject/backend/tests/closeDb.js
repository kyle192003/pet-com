const { closeAll } = require('./helpers');

// Close database pools after each test so Jest exits cleanly
afterEach(async () => {
  await closeAll();
});
