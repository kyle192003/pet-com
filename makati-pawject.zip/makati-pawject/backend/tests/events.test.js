const { setup, tokenFor, bearer } = require('./helpers');

let ctx;
beforeEach(async () => {
  ctx = await setup();
});

const newEvent = {
  title: 'Test Walk', event_type: 'fun_run', date: '2026-12-05', start_time: '08:00', end_time: '10:00',
  location: 'Ayala Triangle', max_attendees: 2, is_volunteer_event: true,
};

describe('GET /api/events', () => {
  test('lists active events sorted by date with counts and roles', async () => {
    const res = await ctx.api.get('/api/events');
    expect(res.status).toBe(200);
    expect(res.body).toHaveLength(5); // the workshop is inactive
    const dates = res.body.map((e) => e.date);
    expect([...dates].sort()).toEqual(dates);
    const funRun = res.body.find((e) => e.title === 'Paws Fun Run 2026');
    expect(funRun).toMatchObject({ volunteer_count: 2, participant_count: 1, volunteer_slots_left: 12, start_time: '05:30' });
    expect(funRun.volunteer_roles).toHaveLength(3);
  });

  test('filters by type, date range and volunteer flags', async () => {
    const byType = await ctx.api.get('/api/events?type=adoption_day');
    expect(byType.body.every((e) => e.event_type === 'adoption_day')).toBe(true);
    const range = await ctx.api.get('/api/events?from=2026-11-01&to=2026-11-15');
    expect(range.body.map((e) => e.date)).toEqual(['2026-11-07', '2026-11-14']);
    const hours = await ctx.api.get('/api/events?hoursEligibleOnly=true');
    expect(hours.body.every((e) => e.is_hours_eligible)).toBe(true);
  });

  test('rejects bad filter values', async () => {
    expect((await ctx.api.get('/api/events?from=yesterday')).status).toBe(400);
  });

  test('only admins can include inactive events', async () => {
    expect((await ctx.api.get('/api/events?includeInactive=true')).body).toHaveLength(5);
    const token = await tokenFor(ctx.app, 'admin');
    expect((await ctx.api.get('/api/events?includeInactive=true').set(bearer(token))).body).toHaveLength(6);
  });

  test('GET /:id returns 404 for missing or inactive events (non-admin)', async () => {
    expect((await ctx.api.get('/api/events/999')).status).toBe(404);
    const inactive = await ctx.db.one("SELECT id FROM events WHERE is_active = FALSE");
    expect((await ctx.api.get(`/api/events/${inactive.id}`)).status).toBe(404);
  });
});

describe('admin event management', () => {
  test('non-admins cannot create events', async () => {
    const token = await tokenFor(ctx.app, 'makatizen');
    expect((await ctx.api.post('/api/events').set(bearer(token)).send(newEvent)).status).toBe(403);
    expect((await ctx.api.post('/api/events').send(newEvent)).status).toBe(401);
  });

  test('admin can create, update and delete an event', async () => {
    const token = await tokenFor(ctx.app, 'admin');
    const created = await ctx.api.post('/api/events').set(bearer(token)).send(newEvent);
    expect(created.status).toBe(201);
    expect(created.body).toMatchObject({ title: 'Test Walk', date: '2026-12-05', is_active: true });

    const updated = await ctx.api.put(`/api/events/${created.body.id}`).set(bearer(token)).send({ ...newEvent, title: 'Renamed Walk' });
    expect(updated.body.title).toBe('Renamed Walk');

    expect((await ctx.api.delete(`/api/events/${created.body.id}`).set(bearer(token))).status).toBe(204);
    expect((await ctx.api.get(`/api/events/${created.body.id}`)).status).toBe(404);
  });

  test('create validates the body', async () => {
    const token = await tokenFor(ctx.app, 'admin');
    const res = await ctx.api.post('/api/events').set(bearer(token)).send({ ...newEvent, title: '' });
    expect(res.status).toBe(400);
    expect(res.body.error.fields).toHaveProperty('title');
  });
});

describe('POST /api/events/:id/register', () => {
  test('registers once, then refuses a second registration', async () => {
    const token = await tokenFor(ctx.app, 'makatizen');
    const { id } = await ctx.db.one("SELECT id FROM events WHERE title = 'Adoption Day at the Park'");
    const first = await ctx.api.post(`/api/events/${id}/register`).set(bearer(token)).send({ role_at_event: 'participant' });
    expect(first.status).toBe(201);
    expect(first.body.participant_count).toBe(3);
    const second = await ctx.api.post(`/api/events/${id}/register`).set(bearer(token)).send({ role_at_event: 'participant' });
    expect(second.status).toBe(409);

    const mine = await ctx.api.get('/api/events/registrations/me').set(bearer(token));
    expect(mine.body.map((r) => r.event_id)).toContain(id);
  });

  test("can't volunteer at an event that doesn't need volunteers", async () => {
    const token = await tokenFor(ctx.app, 'makatizen');
    const { id } = await ctx.db.one("SELECT id FROM events WHERE title = 'Adoption Day at the Park'");
    const res = await ctx.api.post(`/api/events/${id}/register`).set(bearer(token)).send({ role_at_event: 'volunteer' });
    expect(res.status).toBe(409);
  });

  test('refuses when the event is full', async () => {
    const admin = await tokenFor(ctx.app, 'admin');
    const ev = await ctx.api.post('/api/events').set(bearer(admin)).send({ ...newEvent, max_attendees: 1 });
    const juan = await tokenFor(ctx.app, 'makatizen');
    const ana = await tokenFor(ctx.app, 'employee');
    expect((await ctx.api.post(`/api/events/${ev.body.id}/register`).set(bearer(juan)).send({ role_at_event: 'participant' })).status).toBe(201);
    const full = await ctx.api.post(`/api/events/${ev.body.id}/register`).set(bearer(ana)).send({ role_at_event: 'participant' });
    expect(full.status).toBe(409);
    expect(full.body.error.message).toMatch(/full/);
  });

  test('requires login', async () => {
    expect((await ctx.api.post('/api/events/1/register').send({ role_at_event: 'participant' })).status).toBe(401);
  });
});
