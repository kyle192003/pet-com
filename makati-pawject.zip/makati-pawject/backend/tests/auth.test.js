const { setup, tokenFor, bearer } = require('./helpers');

let ctx;
beforeEach(async () => {
  ctx = await setup();
});

describe('POST /api/auth/login', () => {
  test('returns a token and the user without the password hash', async () => {
    const res = await ctx.api.post('/api/auth/login').send({ email: 'admin@makati.gov.ph', password: 'admin123' });
    expect(res.status).toBe(200);
    expect(res.body.token).toEqual(expect.any(String));
    expect(res.body.user).toMatchObject({ role: 'admin', email: 'admin@makati.gov.ph' });
    expect(res.body.user).not.toHaveProperty('password_hash');
  });

  test('email is case-insensitive', async () => {
    const res = await ctx.api.post('/api/auth/login').send({ email: 'ADMIN@makati.gov.ph', password: 'admin123' });
    expect(res.status).toBe(200);
  });

  test('wrong password gives 401 with a clear message', async () => {
    const res = await ctx.api.post('/api/auth/login').send({ email: 'admin@makati.gov.ph', password: 'nope' });
    expect(res.status).toBe(401);
    expect(res.body.error.message).toBe('Email or password is incorrect.');
  });

  test('invalid body gives 400 with field errors', async () => {
    const res = await ctx.api.post('/api/auth/login').send({ email: 'not-an-email' });
    expect(res.status).toBe(400);
    expect(res.body.error.fields).toHaveProperty('email');
  });
});

describe('POST /api/auth/register', () => {
  const newUser = {
    full_name: 'Pia Santos', username: 'pias', email: 'pia@example.com', password: 'password123',
    mobile_number: '0917 555 1234', address: 'Bel-Air, Makati', wants_to_volunteer: true, skills: 'Dog walking',
  };

  test('creates a Makatizen and a volunteer record', async () => {
    const res = await ctx.api.post('/api/auth/register').send(newUser);
    expect(res.status).toBe(201);
    expect(res.body.user.role).toBe('makatizen');
    const vol = await ctx.db.one('SELECT * FROM volunteers WHERE user_id = $1', [res.body.user.id]);
    expect(vol.skills).toBe('Dog walking');
  });

  test('cannot choose the admin role', async () => {
    const res = await ctx.api.post('/api/auth/register').send({ ...newUser, role: 'admin' });
    expect(res.body.user.role).toBe('makatizen');
  });

  test('duplicate email gives 409', async () => {
    const res = await ctx.api.post('/api/auth/register').send({ ...newUser, email: 'juan@example.com' });
    expect(res.status).toBe(409);
    expect(res.body.error.message).toMatch(/already exists/);
  });

  test('duplicate username gives 409', async () => {
    const res = await ctx.api.post('/api/auth/register').send({ ...newUser, username: 'juandc' });
    expect(res.status).toBe(409);
  });

  test('stores a bcrypt hash, not the password', async () => {
    await ctx.api.post('/api/auth/register').send(newUser);
    const row = await ctx.db.one('SELECT password_hash FROM users WHERE email = $1', [newUser.email]);
    expect(row.password_hash).not.toBe(newUser.password);
    expect(row.password_hash).toMatch(/^\$2[aby]\$/);
  });
});

describe('GET /api/auth/me', () => {
  test('returns the current user', async () => {
    const token = await tokenFor(ctx.app, 'employee');
    const res = await ctx.api.get('/api/auth/me').set(bearer(token));
    expect(res.status).toBe(200);
    expect(res.body.full_name).toBe('Ana Reyes');
  });

  test('401 without a token', async () => {
    expect((await ctx.api.get('/api/auth/me')).status).toBe(401);
  });

  test('401 with a bad token', async () => {
    expect((await ctx.api.get('/api/auth/me').set(bearer('garbage'))).status).toBe(401);
  });
});

test('unknown endpoints give a JSON 404', async () => {
  const res = await ctx.api.get('/api/nope');
  expect(res.status).toBe(404);
  expect(res.body.error.message).toMatch(/No endpoint/);
});
