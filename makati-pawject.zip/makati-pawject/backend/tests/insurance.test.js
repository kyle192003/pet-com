const { setup, tokenFor, bearer } = require('./helpers');

let ctx;
beforeEach(async () => {
  ctx = await setup();
});

test('employees see their own policies, newest first', async () => {
  const token = await tokenFor(ctx.app, 'employee');
  const res = await ctx.api.get('/api/insurance/policies/me').set(bearer(token));
  expect(res.status).toBe(200);
  expect(res.body.map((p) => p.pet_name)).toEqual(['Luna', 'Mango', 'Brownie']);
});

test('employees can enroll a pet; it starts as pending', async () => {
  const token = await tokenFor(ctx.app, 'employee');
  const res = await ctx.api.post('/api/insurance/policies').set(bearer(token)).send({ pet_name: 'Kape', species: 'cat', breed: 'Puspin', age_years: '3' });
  expect(res.status).toBe(201);
  expect(res.body).toMatchObject({ pet_name: 'Kape', policy_status: 'pending', age_years: 3 });
});

test('Makatizens and admins cannot use pet insurance', async () => {
  for (const who of ['makatizen', 'admin']) {
    // eslint-disable-next-line no-await-in-loop
    const token = await tokenFor(ctx.app, who);
    // eslint-disable-next-line no-await-in-loop
    expect((await ctx.api.get('/api/insurance/policies/me').set(bearer(token))).status).toBe(403);
  }
  expect((await ctx.api.get('/api/insurance/policies/me')).status).toBe(401);
});

test('validates enrollment', async () => {
  const token = await tokenFor(ctx.app, 'employee');
  const res = await ctx.api.post('/api/insurance/policies').set(bearer(token)).send({ pet_name: '', species: 'hamster', breed: 'x', age_years: 'old' });
  expect(res.status).toBe(400);
  expect(Object.keys(res.body.error.fields)).toEqual(expect.arrayContaining(['pet_name', 'species', 'age_years']));
});
