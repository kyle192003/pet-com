const s = require('../../src/validators/schemas');
const { TINY_PNG } = require('../helpers');

const validApplication = {
  pet_id: 1,
  applicant_name: 'Juan Dela Cruz',
  applicant_email: 'juan@example.com',
  applicant_phone: '0917 123 4567',
  address: 'Poblacion, Makati',
  residence_type: 'house',
  agreed_to_terms: true,
  valid_id_type: 'philsys',
  valid_id_image: TINY_PNG,
  id_terms_accepted: true,
  privacy_consent: true,
  terms_version: '2026-09',
};

describe('register schema', () => {
  const base = { full_name: 'Juan', username: 'juan', email: 'juan@x.com', password: 'longenough', mobile_number: '0917 123 4567', address: 'Makati' };

  test('accepts valid data and fills defaults', () => {
    const out = s.register.parse(base);
    expect(out.wants_to_volunteer).toBe(false);
    expect(out.preferred_pet_type).toBe('both');
  });

  test('rejects short passwords', () => {
    const r = s.register.safeParse({ ...base, password: 'short' });
    expect(r.success).toBe(false);
    expect(r.error.issues[0].message).toMatch(/8 characters/);
  });

  test('rejects bad mobile numbers', () => {
    expect(s.register.safeParse({ ...base, mobile_number: '123' }).success).toBe(false);
  });
});

describe('adoption application schema', () => {
  test('accepts a complete application', () => {
    expect(s.application.safeParse(validApplication).success).toBe(true);
  });

  test('requires Data Privacy Act consent', () => {
    const r = s.application.safeParse({ ...validApplication, privacy_consent: false });
    expect(r.success).toBe(false);
    expect(r.error.issues[0].message).toMatch(/Data Privacy Act/);
  });

  test('requires the ID upload terms', () => {
    expect(s.application.safeParse({ ...validApplication, id_terms_accepted: false }).success).toBe(false);
  });

  test('rejects non-image uploads and SVGs', () => {
    expect(s.application.safeParse({ ...validApplication, valid_id_image: 'data:application/pdf;base64,AAAA' }).success).toBe(false);
    expect(s.application.safeParse({ ...validApplication, valid_id_image: 'data:image/svg+xml;base64,AAAA' }).success).toBe(false);
  });

  test('rejects ID photos over 5 MB', () => {
    const huge = `data:image/png;base64,${'A'.repeat(7 * 1024 * 1024)}`;
    const r = s.application.safeParse({ ...validApplication, valid_id_image: huge });
    expect(r.success).toBe(false);
    expect(r.error.issues[0].message).toMatch(/5 MB/);
  });
});

describe('event schema', () => {
  test('validates date and time formats', () => {
    const base = { title: 'Walk', event_type: 'fun_run', date: '2026-12-05', start_time: '08:00', end_time: '10:00', location: 'Ayala' };
    expect(s.eventBody.safeParse(base).success).toBe(true);
    expect(s.eventBody.safeParse({ ...base, date: '12/05/2026' }).success).toBe(false);
    expect(s.eventBody.safeParse({ ...base, start_time: '8am' }).success).toBe(false);
    expect(s.eventBody.safeParse({ ...base, event_type: 'party' }).success).toBe(false);
  });
});
