const m = require('../../src/utils/mappers');

describe('mappers', () => {
  test('toDate handles Date objects and strings', () => {
    expect(m.toDate(new Date('2026-10-17T00:00:00Z'))).toBe('2026-10-17');
    expect(m.toDate('2026-10-17')).toBe('2026-10-17');
    expect(m.toDate(null)).toBeNull();
  });

  test('toTime trims seconds', () => {
    expect(m.toTime('08:30:00')).toBe('08:30');
    expect(m.toTime('17:05')).toBe('17:05');
  });

  test('toNum converts numeric strings', () => {
    expect(m.toNum('2.5')).toBe(2.5);
    expect(m.toNum(null)).toBeNull();
  });

  test('user never exposes the password hash', () => {
    const out = m.user({ id: 1, role: 'admin', full_name: 'A', email: 'a@x.com', username: 'a', password_hash: 'secret', created_at: new Date() });
    expect(out).not.toHaveProperty('password_hash');
    expect(out.mobile_number).toBe('');
  });

  test('application never exposes the ID image', () => {
    const out = m.application({ id: 1, valid_id_image: 'data:image/png;base64,AAAA', created_at: new Date(), consent_at: new Date() });
    expect(out).not.toHaveProperty('valid_id_image');
    expect(out.has_valid_id).toBe(true);
  });

  test('pet maps numbers and dates', () => {
    const out = m.pet({ id: 1, name: 'Ube', age_years: '0.7', date_listed: new Date('2026-09-18T00:00:00Z'), status: 'available' });
    expect(out.age_years).toBe(0.7);
    expect(out.date_listed).toBe('2026-09-18');
    expect(out.photo_url).toBe('');
  });
});
