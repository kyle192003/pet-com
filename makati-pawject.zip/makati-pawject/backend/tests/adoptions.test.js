const { setup, tokenFor, bearer, TINY_PNG } = require('./helpers');

let ctx;
beforeEach(async () => {
  ctx = await setup();
});

const petId = async (name) => (await ctx.db.one('SELECT id FROM pets WHERE name = $1', [name])).id;

const applicationFor = (pet_id) => ({
  pet_id,
  applicant_name: 'Juan Dela Cruz',
  applicant_email: 'juan@example.com',
  applicant_phone: '0917 123 4567',
  address: '123 J.P. Rizal Ave, Makati',
  residence_type: 'condo',
  experience_notes: 'Grew up with cats.',
  agreed_to_terms: true,
  valid_id_type: 'philsys',
  valid_id_image: TINY_PNG,
  valid_id_file_name: 'my-id.png',
  id_terms_accepted: true,
  privacy_consent: true,
  terms_version: '2026-09',
});

describe('submitting an application', () => {
  test('saves it as pending with an unverified ID and records consent', async () => {
    const token = await tokenFor(ctx.app, 'makatizen');
    const res = await ctx.api.post('/api/adoptions').set(bearer(token)).send(applicationFor(await petId('Tiger')));
    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ status: 'pending', id_verification_status: 'unverified', pet_name: 'Tiger', has_valid_id: true, privacy_consent: true });
    expect(res.body.consent_at).toEqual(expect.any(String));
    expect(res.body).not.toHaveProperty('valid_id_image');
  });

  test('requires login and a non-admin account', async () => {
    const body = applicationFor(await petId('Tiger'));
    expect((await ctx.api.post('/api/adoptions').send(body)).status).toBe(401);
    const admin = await tokenFor(ctx.app, 'admin');
    expect((await ctx.api.post('/api/adoptions').set(bearer(admin)).send(body)).status).toBe(403);
  });

  test('refuses without an ID or without Data Privacy Act consent', async () => {
    const token = await tokenFor(ctx.app, 'makatizen');
    const body = applicationFor(await petId('Tiger'));
    const noId = await ctx.api.post('/api/adoptions').set(bearer(token)).send({ ...body, valid_id_image: undefined });
    expect(noId.status).toBe(400);
    expect(noId.body.error.fields).toHaveProperty('valid_id_image');
    const noConsent = await ctx.api.post('/api/adoptions').set(bearer(token)).send({ ...body, privacy_consent: false });
    expect(noConsent.status).toBe(400);
    expect(noConsent.body.error.message).toMatch(/Data Privacy Act/);
  });

  test('refuses pets that are not available and duplicate pending applications', async () => {
    const token = await tokenFor(ctx.app, 'makatizen');
    expect((await ctx.api.post('/api/adoptions').set(bearer(token)).send(applicationFor(await petId('Choco')))).status).toBe(409);
    const tiger = await petId('Tiger');
    expect((await ctx.api.post('/api/adoptions').set(bearer(token)).send(applicationFor(tiger))).status).toBe(201);
    expect((await ctx.api.post('/api/adoptions').set(bearer(token)).send(applicationFor(tiger))).status).toBe(409);
  });

  test('applicants see their own applications', async () => {
    const token = await tokenFor(ctx.app, 'makatizen');
    await ctx.api.post('/api/adoptions').set(bearer(token)).send(applicationFor(await petId('Tiger')));
    const mine = await ctx.api.get('/api/adoptions/me').set(bearer(token));
    expect(mine.body).toHaveLength(1);
    expect(mine.body[0].pet_name).toBe('Tiger');
  });
});

describe('admin review', () => {
  const pendingFor = async (name) => ctx.db.one("SELECT id, pet_id FROM adoption_applications WHERE applicant_name = $1", [name]);

  test('lists applications without ID images and filters by status', async () => {
    const token = await tokenFor(ctx.app, 'admin');
    const all = await ctx.api.get('/api/adoptions').set(bearer(token));
    expect(all.body).toHaveLength(5);
    expect(all.body.some((a) => 'valid_id_image' in a)).toBe(false);
    const pending = await ctx.api.get('/api/adoptions?status=pending').set(bearer(token));
    expect(pending.body.every((a) => a.status === 'pending')).toBe(true);
  });

  test('only admins can view the ID image, and it is not cached', async () => {
    const { id } = await pendingFor('Maria Santos');
    const makatizen = await tokenFor(ctx.app, 'makatizen');
    expect((await ctx.api.get(`/api/adoptions/${id}/id-image`).set(bearer(makatizen))).status).toBe(403);
    expect((await ctx.api.get(`/api/adoptions/${id}/id-image`)).status).toBe(401);
    const admin = await tokenFor(ctx.app, 'admin');
    const res = await ctx.api.get(`/api/adoptions/${id}/id-image`).set(bearer(admin));
    expect(res.status).toBe(200);
    expect(res.headers['cache-control']).toBe('no-store');
    expect(res.body.data_url).toMatch(/^data:image\//);
  });

  test('cannot approve until the ID is verified', async () => {
    const token = await tokenFor(ctx.app, 'admin');
    const { id } = await pendingFor('Maria Santos');
    const early = await ctx.api.patch(`/api/adoptions/${id}`).set(bearer(token)).send({ status: 'approved' });
    expect(early.status).toBe(409);
    expect(early.body.error.message).toMatch(/Verify the applicant's ID/);

    const mismatch = await ctx.api.patch(`/api/adoptions/${id}/id-verification`).set(bearer(token)).send({ id_verification_status: 'mismatch' });
    expect(mismatch.body.id_verification_status).toBe('mismatch');
    expect((await ctx.api.patch(`/api/adoptions/${id}`).set(bearer(token)).send({ status: 'approved' })).status).toBe(409);
  });

  test('verifying then approving marks the pet as adopted', async () => {
    const token = await tokenFor(ctx.app, 'admin');
    const { id, pet_id } = await pendingFor('Maria Santos');
    const verified = await ctx.api.patch(`/api/adoptions/${id}/id-verification`).set(bearer(token)).send({ id_verification_status: 'verified' });
    expect(verified.body).toMatchObject({ id_verification_status: 'verified', id_verified_at: expect.any(String) });

    const approved = await ctx.api.patch(`/api/adoptions/${id}`).set(bearer(token)).send({ status: 'approved', admin_notes: 'Home visit done' });
    expect(approved.status).toBe(200);
    expect(approved.body).toMatchObject({ status: 'approved', admin_notes: 'Home visit done' });
    const pet = await ctx.db.one('SELECT status FROM pets WHERE id = $1', [pet_id]);
    expect(pet.status).toBe('adopted');
  });

  test('can reject without verifying, and save notes only', async () => {
    const token = await tokenFor(ctx.app, 'admin');
    const { id } = await pendingFor('Paolo Cruz');
    const notes = await ctx.api.patch(`/api/adoptions/${id}`).set(bearer(token)).send({ admin_notes: 'Called, no answer' });
    expect(notes.body).toMatchObject({ status: 'pending', admin_notes: 'Called, no answer' });
    const rejected = await ctx.api.patch(`/api/adoptions/${id}`).set(bearer(token)).send({ status: 'rejected' });
    expect(rejected.body.status).toBe('rejected');
    // closed applications can't be re-checked
    expect((await ctx.api.patch(`/api/adoptions/${id}/id-verification`).set(bearer(token)).send({ id_verification_status: 'verified' })).status).toBe(409);
  });

  test('an empty update is rejected', async () => {
    const token = await tokenFor(ctx.app, 'admin');
    const { id } = await pendingFor('Paolo Cruz');
    expect((await ctx.api.patch(`/api/adoptions/${id}`).set(bearer(token)).send({})).status).toBe(400);
  });
});
