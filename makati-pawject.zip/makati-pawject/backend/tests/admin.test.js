const { setup, tokenFor, bearer } = require('./helpers');

let ctx;
beforeEach(async () => {
  ctx = await setup();
});

test('GET /api/admin/stats returns dashboard counts', async () => {
  const token = await tokenFor(ctx.app, 'admin');
  const res = await ctx.api.get('/api/admin/stats').set(bearer(token));
  expect(res.body).toEqual({ activeEvents: 5, pendingApplications: 4, volunteers: 5, services: 6, availablePets: 7 });
});

test('stats are admin-only', async () => {
  const token = await tokenFor(ctx.app, 'employee');
  expect((await ctx.api.get('/api/admin/stats').set(bearer(token))).status).toBe(403);
});

test('health check reports the database mode', async () => {
  const res = await ctx.api.get('/api/health');
  expect(res.body).toEqual({ ok: true, database: process.env.TEST_DATABASE_URL ? 'postgresql' : 'in-memory' });
});

test('oversized JSON bodies get a friendly 413', async () => {
  const token = await tokenFor(ctx.app, 'makatizen');
  const res = await ctx.api
    .post('/api/adoptions')
    .set(bearer(token))
    .set('Content-Type', 'application/json')
    .send(JSON.stringify({ valid_id_image: 'A'.repeat(9 * 1024 * 1024) }));
  expect(res.status).toBe(413);
  expect(res.body.error.message).toMatch(/too large/);
});

test('malformed JSON gets a 400', async () => {
  const res = await ctx.api.post('/api/auth/login').set('Content-Type', 'application/json').send('{bad json');
  expect(res.status).toBe(400);
});
