const request = require('supertest');
const { createDb, applySchema } = require('../src/db');
const { seed } = require('../src/db/seed');
const { createApp } = require('../src/app');

const openDbs = [];

// Fresh database with sample data for each test.
// Uses in-memory PostgreSQL, or a real one when TEST_DATABASE_URL is set
// (its tables are dropped and recreated, so use a throwaway database).
async function setup() {
  const db = createDb({ url: process.env.TEST_DATABASE_URL || '' });
  openDbs.push(db);
  await applySchema(db);
  const ids = await seed(db);
  const app = createApp({ db });
  return { app, db, ids, api: request(app) };
}

const ACCOUNTS = {
  admin: { email: 'admin@makati.gov.ph', password: 'admin123' },
  employee: { email: 'ana.reyes@manulife.com', password: 'employee123' },
  makatizen: { email: 'juan@example.com', password: 'makatizen123' },
};

async function tokenFor(app, who) {
  const res = await request(app).post('/api/auth/login').send(ACCOUNTS[who]);
  if (res.status !== 200) throw new Error(`login failed for ${who}: ${res.status}`);
  return res.body.token;
}

const bearer = (token) => ({ Authorization: `Bearer ${token}` });

// 1x1 PNG
const TINY_PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

async function closeAll() {
  while (openDbs.length) {
    // eslint-disable-next-line no-await-in-loop
    await openDbs.pop().close();
  }
}

module.exports = { setup, closeAll, tokenFor, bearer, ACCOUNTS, TINY_PNG };
