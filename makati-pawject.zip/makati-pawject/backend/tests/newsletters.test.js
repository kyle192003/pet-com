const { setup, tokenFor, bearer } = require('./helpers');

let ctx;
beforeEach(async () => {
  ctx = await setup();
});

test('public list shows only published issues, newest first', async () => {
  const res = await ctx.api.get('/api/newsletters?includeDrafts=true'); // ignored for non-admins
  expect(res.body).toHaveLength(4);
  expect(res.body.every((n) => n.published_at)).toBe(true);
  const dates = res.body.map((n) => n.published_at);
  expect([...dates].sort().reverse()).toEqual(dates);
});

test('drafts are hidden from the public but visible to admins', async () => {
  const draft = await ctx.db.one('SELECT id FROM newsletters WHERE published_at IS NULL');
  expect((await ctx.api.get(`/api/newsletters/${draft.id}`)).status).toBe(404);
  const token = await tokenFor(ctx.app, 'admin');
  expect((await ctx.api.get(`/api/newsletters/${draft.id}`).set(bearer(token))).status).toBe(200);
  expect((await ctx.api.get('/api/newsletters?includeDrafts=true').set(bearer(token))).body).toHaveLength(5);
});

test('admin can write a draft, publish it, unpublish it and delete it', async () => {
  const token = await tokenFor(ctx.app, 'admin');
  const draft = await ctx.api.post('/api/newsletters').set(bearer(token)).send({ title: 'Hello', summary: 'Short', body: 'Long body', publish: false });
  expect(draft.status).toBe(201);
  expect(draft.body.published_at).toBeNull();

  const published = await ctx.api.put(`/api/newsletters/${draft.body.id}`).set(bearer(token)).send({ title: 'Hello', summary: 'Short', body: 'Long body', publish: true });
  expect(published.body.published_at).toEqual(expect.any(String));

  const unpublished = await ctx.api.put(`/api/newsletters/${draft.body.id}`).set(bearer(token)).send({ title: 'Hello', summary: 'Short', body: 'Long body', publish: false });
  expect(unpublished.body.published_at).toBeNull();

  expect((await ctx.api.delete(`/api/newsletters/${draft.body.id}`).set(bearer(token))).status).toBe(204);
});

test('non-admins cannot write newsletters', async () => {
  const token = await tokenFor(ctx.app, 'employee');
  expect((await ctx.api.post('/api/newsletters').set(bearer(token)).send({ title: 'x', summary: 'y', body: 'z' })).status).toBe(403);
});
