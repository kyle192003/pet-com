const { setup, tokenFor, bearer } = require('./helpers');

let ctx;
beforeEach(async () => {
  ctx = await setup();
});

const roleId = async (name, event) =>
  (await ctx.db.one('SELECT r.id FROM volunteer_roles r JOIN events e ON e.id = r.event_id WHERE r.role_name = $1 AND e.title = $2', [name, event])).id;

test('GET /opportunities lists only volunteer events, optionally hours-eligible', async () => {
  const all = await ctx.api.get('/api/volunteers/opportunities');
  expect(all.body.every((e) => e.is_volunteer_event)).toBe(true);
  const eligible = await ctx.api.get('/api/volunteers/opportunities?hoursEligibleOnly=true');
  expect(eligible.body.length).toBeLessThan(all.body.length);
  expect(eligible.body.every((e) => e.is_hours_eligible)).toBe(true);
});

test('sign-up takes a slot and cannot be repeated', async () => {
  const token = await tokenFor(ctx.app, 'makatizen');
  const id = await roleId('Route marshal', 'Paws Fun Run 2026'); // 2 slots
  const first = await ctx.api.post(`/api/volunteers/roles/${id}/signup`).set(bearer(token));
  expect(first.status).toBe(201);
  expect(first.body.slots_available).toBe(1);
  const again = await ctx.api.post(`/api/volunteers/roles/${id}/signup`).set(bearer(token));
  expect(again.status).toBe(409);

  const mine = await ctx.api.get('/api/volunteers/assignments/me').set(bearer(token));
  expect(mine.body.map((a) => a.volunteer_role_id)).toContain(id);
});

test('a full role refuses new volunteers', async () => {
  const id = await roleId('Route marshal', 'Paws Fun Run 2026');
  await ctx.db.query('UPDATE volunteer_roles SET slots_available = 0 WHERE id = $1', [id]);
  const token = await tokenFor(ctx.app, 'employee');
  const res = await ctx.api.post(`/api/volunteers/roles/${id}/signup`).set(bearer(token));
  expect(res.status).toBe(409);
  expect(res.body.error.message).toMatch(/full/);
});

test('unknown role gives 404, no login gives 401', async () => {
  const token = await tokenFor(ctx.app, 'employee');
  expect((await ctx.api.post('/api/volunteers/roles/9999/signup').set(bearer(token))).status).toBe(404);
  expect((await ctx.api.post('/api/volunteers/roles/1/signup')).status).toBe(401);
});

test('summary returns hours and assignment counts', async () => {
  const token = await tokenFor(ctx.app, 'employee');
  const res = await ctx.api.get('/api/volunteers/me/summary').set(bearer(token));
  expect(res.body).toEqual({ total_hours: 18.5, completed: 1, upcoming: 0, goal_hours: 40 });
});

test('only admins can list all volunteers', async () => {
  const makatizen = await tokenFor(ctx.app, 'makatizen');
  expect((await ctx.api.get('/api/volunteers').set(bearer(makatizen))).status).toBe(403);
  const admin = await tokenFor(ctx.app, 'admin');
  const res = await ctx.api.get('/api/volunteers').set(bearer(admin));
  expect(res.status).toBe(200);
  expect(res.body.length).toBe(5);
});
