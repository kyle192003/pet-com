// Runs before every test file
process.env.NODE_ENV = 'test';
process.env.BCRYPT_ROUNDS = '4'; // fast hashing in tests
process.env.JWT_SECRET = 'test-secret';
process.env.DATABASE_URL = ''; // always use the in-memory database
