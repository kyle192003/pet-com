const { setup, tokenFor, bearer } = require('./helpers');

let ctx;
beforeEach(async () => {
  ctx = await setup();
});

const newService = {
  title: 'Free grooming day', description: 'Basic grooming for shelter adoptees.', service_type: 'free',
  pet_type: 'both', availability_schedule: 'Last Sunday of the month', location: 'Makati Veterinary Office', how_to_avail: 'walk_in',
};

test('filters by type and pet type (dog includes "both")', async () => {
  const free = await ctx.api.get('/api/services?type=free');
  expect(free.body.every((s) => s.service_type === 'free')).toBe(true);
  const cats = await ctx.api.get('/api/services?petType=cat');
  expect(cats.body.every((s) => ['cat', 'both'].includes(s.pet_type))).toBe(true);
  expect(cats.body.map((s) => s.title)).not.toContain('Free pet registration'); // dogs only
});

test('admin CRUD', async () => {
  const token = await tokenFor(ctx.app, 'admin');
  const created = await ctx.api.post('/api/services').set(bearer(token)).send(newService);
  expect(created.status).toBe(201);
  const updated = await ctx.api.put(`/api/services/${created.body.id}`).set(bearer(token)).send({ ...newService, service_type: 'discounted' });
  expect(updated.body.service_type).toBe('discounted');
  expect((await ctx.api.delete(`/api/services/${created.body.id}`).set(bearer(token))).status).toBe(204);
  expect((await ctx.api.get(`/api/services/${created.body.id}`)).status).toBe(404);
});

test('non-admins cannot change services; bad data is rejected', async () => {
  const user = await tokenFor(ctx.app, 'makatizen');
  expect((await ctx.api.post('/api/services').set(bearer(user)).send(newService)).status).toBe(403);
  const admin = await tokenFor(ctx.app, 'admin');
  expect((await ctx.api.post('/api/services').set(bearer(admin)).send({ ...newService, pet_type: 'fish' })).status).toBe(400);
});
