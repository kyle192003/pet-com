const config = require('../config');

// Unknown routes
function notFoundHandler(req, res) {
  res.status(404).json({ error: { message: `No endpoint for ${req.method} ${req.originalUrl}.` } });
}

// Every error becomes { error: { message, fields? } }
// eslint-disable-next-line no-unused-vars
function errorHandler(err, _req, res, _next) {
  // Body too large (ID photo)
  if (err.type === 'entity.too.large') {
    return res.status(413).json({ error: { message: 'This upload is too large. Use a photo under 5 MB.' } });
  }
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: { message: 'The request body is not valid JSON.' } });
  }
  // PostgreSQL unique / check violations
  if (err.code === '23505') {
    return res.status(409).json({ error: { message: 'This already exists.' } });
  }
  if (err.code === '23514' || err.code === '23503') {
    return res.status(400).json({ error: { message: 'Some values are not allowed.' } });
  }

  const status = err.status || 500;
  if (status >= 500 && !config.isTest) console.error(err);
  const body = { message: status >= 500 ? 'Something went wrong on the server. Try again.' : err.message };
  if (err.details) body.fields = err.details;
  return res.status(status).json({ error: body });
}

module.exports = { notFoundHandler, errorHandler };
