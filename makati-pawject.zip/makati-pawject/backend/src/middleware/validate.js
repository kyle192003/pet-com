const { badRequest } = require('../utils/httpError');

// Validate req.body (or req.query) with a zod schema. Replaces it with the parsed value.
const validate =
  (schema, source = 'body') =>
  (req, _res, next) => {
    const result = schema.safeParse(req[source] ?? {});
    if (!result.success) {
      const fields = {};
      for (const issue of result.error.issues) {
        const key = issue.path.join('.') || '_';
        if (!fields[key]) fields[key] = issue.message;
      }
      const first = Object.values(fields)[0];
      return next(badRequest(first || 'Check the highlighted fields.', fields));
    }
    if (source === 'query') {
      req.validatedQuery = result.data; // req.query is read-only in Express 5
    } else {
      req[source] = result.data;
    }
    return next();
  };

module.exports = validate;
