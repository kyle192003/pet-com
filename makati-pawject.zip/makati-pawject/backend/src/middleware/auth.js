const jwt = require('jsonwebtoken');
const config = require('../config');
const { unauthorized, forbidden } = require('../utils/httpError');
const mappers = require('../utils/mappers');

function signToken(user) {
  return jwt.sign({ sub: user.id, role: user.role }, config.jwtSecret, { expiresIn: config.jwtExpiresIn });
}

// Reads "Authorization: Bearer <token>" and sets req.user when valid.
// Public routes still work without a token.
async function authenticate(req, _res, next) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');
  if (scheme !== 'Bearer' || !token) return next();
  try {
    const payload = jwt.verify(token, config.jwtSecret);
    const row = await req.app.locals.db.one('SELECT * FROM users WHERE id = $1', [payload.sub]);
    if (!row) return next(unauthorized('Your account no longer exists. Log in again.'));
    req.user = mappers.user(row);
    return next();
  } catch {
    return next(unauthorized('Your session has ended. Log in again.'));
  }
}

const requireAuth = (req, _res, next) => (req.user ? next() : next(unauthorized()));

// requireRole('admin') or requireRole('admin', 'employee')
const requireRole =
  (...roles) =>
  (req, _res, next) => {
    if (!req.user) return next(unauthorized());
    if (!roles.includes(req.user.role)) return next(forbidden());
    return next();
  };

module.exports = { signToken, authenticate, requireAuth, requireRole };
