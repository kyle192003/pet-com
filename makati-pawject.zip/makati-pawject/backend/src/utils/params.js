const { notFound } = require('./httpError');

// Parse a numeric :id route param, or 404
function idParam(req, name = 'id') {
  const id = Number(req.params[name]);
  if (!Number.isInteger(id) || id <= 0) throw notFound();
  return id;
}

module.exports = { idParam };
