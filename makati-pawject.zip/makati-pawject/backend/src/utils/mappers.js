// Normalize database rows into the JSON shape the frontend expects.
// Works for real PostgreSQL and pg-mem (which returns Date objects for DATE).

const toDate = (v) => {
  if (v === null || v === undefined) return null;
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  return String(v).slice(0, 10);
};

const toIso = (v) => {
  if (v === null || v === undefined) return null;
  return v instanceof Date ? v.toISOString() : new Date(v).toISOString();
};

const toNum = (v) => (v === null || v === undefined ? null : Number(v));
const toTime = (v) => (v ? String(v).slice(0, 5) : v);

function user(row) {
  if (!row) return null;
  return {
    id: row.id,
    role: row.role,
    full_name: row.full_name,
    email: row.email,
    username: row.username,
    mobile_number: row.mobile_number || '',
    address: row.address || '',
    created_at: toIso(row.created_at),
  };
}

function event(row) {
  return {
    id: row.id,
    title: row.title,
    short_description: row.short_description || '',
    description: row.description || '',
    event_type: row.event_type,
    date: toDate(row.date),
    start_time: toTime(row.start_time),
    end_time: toTime(row.end_time),
    location: row.location,
    max_attendees: toNum(row.max_attendees),
    sponsor: row.sponsor || '',
    is_active: row.is_active,
    is_volunteer_event: row.is_volunteer_event,
    is_hours_eligible: row.is_hours_eligible,
    created_by_user_id: row.created_by_user_id,
    created_at: toIso(row.created_at),
  };
}

function volunteerRole(row) {
  return {
    id: row.id,
    event_id: row.event_id,
    role_name: row.role_name,
    description: row.description || '',
    slots_available: toNum(row.slots_available),
  };
}

function pet(row) {
  return {
    id: row.id,
    name: row.name,
    species: row.species,
    breed: row.breed,
    age_years: toNum(row.age_years),
    gender: row.gender,
    size: row.size,
    description: row.description,
    temperament: row.temperament || '',
    photo_url: row.photo_url || '',
    status: row.status,
    rescued_location: row.rescued_location || '',
    date_listed: toDate(row.date_listed),
  };
}

function medical(row) {
  if (!row) return null;
  return { vaccinated: row.vaccinated, neutered_spayed: row.neutered_spayed, notes: row.notes || '' };
}

// Never includes valid_id_image: that is fetched separately by admins only
function application(row) {
  return {
    id: row.id,
    pet_id: row.pet_id,
    pet_name: row.pet_name,
    pet_species: row.pet_species,
    user_id: row.user_id,
    applicant_name: row.applicant_name,
    applicant_email: row.applicant_email,
    applicant_phone: row.applicant_phone,
    address: row.address,
    residence_type: row.residence_type,
    experience_notes: row.experience_notes || '',
    status: row.status,
    admin_notes: row.admin_notes || '',
    valid_id_type: row.valid_id_type,
    valid_id_file_name: row.valid_id_file_name,
    has_valid_id: Boolean(row.has_valid_id ?? row.valid_id_image),
    id_terms_accepted: row.id_terms_accepted,
    privacy_consent: row.privacy_consent,
    consent_at: toIso(row.consent_at),
    terms_version: row.terms_version,
    id_verification_status: row.id_verification_status,
    id_verified_by_user_id: row.id_verified_by_user_id,
    id_verified_at: toIso(row.id_verified_at),
    created_at: toIso(row.created_at),
  };
}

function service(row) {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    service_type: row.service_type,
    pet_type: row.pet_type,
    availability_schedule: row.availability_schedule,
    location: row.location,
    contact_info: row.contact_info || '',
    how_to_avail: row.how_to_avail,
    created_by_user_id: row.created_by_user_id,
  };
}

function newsletter(row) {
  return {
    id: row.id,
    title: row.title,
    summary: row.summary,
    body: row.body,
    published_at: toIso(row.published_at),
    author_user_id: row.author_user_id,
  };
}

function policy(row) {
  return {
    id: row.id,
    user_id: row.user_id,
    pet_name: row.pet_name,
    species: row.species,
    breed: row.breed,
    age_years: toNum(row.age_years),
    policy_status: row.policy_status,
    created_at: toIso(row.created_at),
  };
}

module.exports = { toDate, toIso, toNum, toTime, user, event, volunteerRole, pet, medical, application, service, newsletter, policy };
