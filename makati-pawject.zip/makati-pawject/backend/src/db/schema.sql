-- The Makati Pawject database schema (PostgreSQL 14+)
-- Tables follow the MU_G2 brainstorm doc, plus the columns the UI needs.

DROP TABLE IF EXISTS pet_insurance_policies CASCADE;
DROP TABLE IF EXISTS newsletters CASCADE;
DROP TABLE IF EXISTS services CASCADE;
DROP TABLE IF EXISTS adoption_applications CASCADE;
DROP TABLE IF EXISTS pet_medical_info CASCADE;
DROP TABLE IF EXISTS pets CASCADE;
DROP TABLE IF EXISTS volunteer_assignments CASCADE;
DROP TABLE IF EXISTS volunteer_roles CASCADE;
DROP TABLE IF EXISTS event_registrations CASCADE;
DROP TABLE IF EXISTS events CASCADE;
DROP TABLE IF EXISTS volunteers CASCADE;
DROP TABLE IF EXISTS users CASCADE;

CREATE TABLE users (
  id             SERIAL PRIMARY KEY,
  role           TEXT NOT NULL CHECK (role IN ('admin', 'employee', 'makatizen')),
  full_name      TEXT NOT NULL,
  email          TEXT NOT NULL UNIQUE,
  username       TEXT NOT NULL UNIQUE,
  password_hash  TEXT NOT NULL,
  mobile_number  TEXT,
  address        TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE volunteers (
  id                     SERIAL PRIMARY KEY,
  user_id                INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  preferred_pet_type     TEXT NOT NULL DEFAULT 'both' CHECK (preferred_pet_type IN ('dog', 'cat', 'both')),
  skills                 TEXT,
  availability_notes     TEXT,
  total_volunteer_hours  NUMERIC(6,1) NOT NULL DEFAULT 0
);

CREATE TABLE events (
  id                  SERIAL PRIMARY KEY,
  title               TEXT NOT NULL,
  short_description   TEXT,
  description         TEXT,
  event_type          TEXT NOT NULL CHECK (event_type IN ('fun_run', 'adoption_day', 'volunteer', 'recreational')),
  date                DATE NOT NULL,
  start_time          TEXT NOT NULL,   -- 'HH:MM'
  end_time            TEXT NOT NULL,   -- 'HH:MM'
  location            TEXT NOT NULL,
  max_attendees       INTEGER,
  sponsor             TEXT,
  is_active           BOOLEAN NOT NULL DEFAULT TRUE,
  is_volunteer_event  BOOLEAN NOT NULL DEFAULT FALSE,
  is_hours_eligible   BOOLEAN NOT NULL DEFAULT FALSE,
  created_by_user_id  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE event_registrations (
  id              SERIAL PRIMARY KEY,
  event_id        INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_at_event   TEXT NOT NULL CHECK (role_at_event IN ('volunteer', 'participant')),
  status          TEXT NOT NULL DEFAULT 'confirmed' CHECK (status IN ('confirmed', 'waitlisted', 'cancelled')),
  hours_credited  NUMERIC(5,1) NOT NULL DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE volunteer_roles (
  id               SERIAL PRIMARY KEY,
  event_id         INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  role_name        TEXT NOT NULL,
  description      TEXT,
  slots_available  INTEGER NOT NULL DEFAULT 0 CHECK (slots_available >= 0)
);

CREATE TABLE volunteer_assignments (
  id                 SERIAL PRIMARY KEY,
  volunteer_role_id  INTEGER NOT NULL REFERENCES volunteer_roles(id) ON DELETE CASCADE,
  user_id            INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status             TEXT NOT NULL DEFAULT 'assigned' CHECK (status IN ('assigned', 'completed')),
  hours_earned       NUMERIC(5,1) NOT NULL DEFAULT 0,
  UNIQUE (volunteer_role_id, user_id)
);

CREATE TABLE pets (
  id                SERIAL PRIMARY KEY,
  name              TEXT NOT NULL,
  species           TEXT NOT NULL CHECK (species IN ('dog', 'cat')),
  breed             TEXT NOT NULL,
  age_years         NUMERIC(4,1) NOT NULL CHECK (age_years >= 0),
  gender            TEXT NOT NULL CHECK (gender IN ('male', 'female')),
  size              TEXT NOT NULL CHECK (size IN ('small', 'medium', 'large')),
  description       TEXT NOT NULL,
  temperament       TEXT,
  photo_url         TEXT,
  status            TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'reserved', 'adopted', 'archived')),
  rescued_location  TEXT,
  date_listed       DATE NOT NULL DEFAULT CURRENT_DATE
);

CREATE TABLE pet_medical_info (
  id               SERIAL PRIMARY KEY,
  pet_id           INTEGER NOT NULL UNIQUE REFERENCES pets(id) ON DELETE CASCADE,
  vaccinated       BOOLEAN NOT NULL DEFAULT FALSE,
  neutered_spayed  BOOLEAN NOT NULL DEFAULT FALSE,
  notes            TEXT
);

-- valid_id_image holds the ID photo as a base64 data URL. It is only ever
-- returned by GET /api/adoptions/:id/id-image (admin only).
CREATE TABLE adoption_applications (
  id                      SERIAL PRIMARY KEY,
  pet_id                  INTEGER NOT NULL REFERENCES pets(id) ON DELETE CASCADE,
  user_id                 INTEGER REFERENCES users(id) ON DELETE SET NULL,
  applicant_name          TEXT NOT NULL,
  applicant_email         TEXT NOT NULL,
  applicant_phone         TEXT NOT NULL,
  address                 TEXT NOT NULL,
  residence_type          TEXT NOT NULL CHECK (residence_type IN ('house', 'condo', 'apartment', 'townhouse')),
  experience_notes        TEXT,
  status                  TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  admin_notes             TEXT,
  valid_id_type           TEXT NOT NULL,
  valid_id_image          TEXT NOT NULL,
  valid_id_file_name      TEXT,
  id_terms_accepted       BOOLEAN NOT NULL,
  privacy_consent         BOOLEAN NOT NULL,
  consent_at              TIMESTAMPTZ NOT NULL,
  terms_version           TEXT NOT NULL,
  id_verification_status  TEXT NOT NULL DEFAULT 'unverified' CHECK (id_verification_status IN ('unverified', 'verified', 'mismatch')),
  id_verified_by_user_id  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  id_verified_at          TIMESTAMPTZ,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE services (
  id                     SERIAL PRIMARY KEY,
  title                  TEXT NOT NULL,
  description            TEXT NOT NULL,
  service_type           TEXT NOT NULL CHECK (service_type IN ('free', 'discounted')),
  pet_type               TEXT NOT NULL CHECK (pet_type IN ('dog', 'cat', 'both')),
  availability_schedule  TEXT NOT NULL,
  location               TEXT NOT NULL,
  contact_info           TEXT,
  how_to_avail           TEXT NOT NULL DEFAULT 'walk_in' CHECK (how_to_avail IN ('walk_in', 'appointment')),
  created_by_user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL
);

-- published_at NULL means draft
CREATE TABLE newsletters (
  id              SERIAL PRIMARY KEY,
  title           TEXT NOT NULL,
  summary         TEXT NOT NULL,
  body            TEXT NOT NULL,
  published_at    TIMESTAMPTZ,
  author_user_id  INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE pet_insurance_policies (
  id             SERIAL PRIMARY KEY,
  user_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  pet_name       TEXT NOT NULL,
  species        TEXT NOT NULL CHECK (species IN ('dog', 'cat')),
  breed          TEXT NOT NULL,
  age_years      NUMERIC(4,1) NOT NULL CHECK (age_years >= 0),
  policy_status  TEXT NOT NULL DEFAULT 'pending' CHECK (policy_status IN ('pending', 'active', 'expired')),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_events_date ON events (date);
CREATE INDEX idx_event_registrations_event ON event_registrations (event_id);
CREATE INDEX idx_volunteer_roles_event ON volunteer_roles (event_id);
CREATE INDEX idx_adoption_applications_status ON adoption_applications (status);
CREATE INDEX idx_pets_status ON pets (status);
