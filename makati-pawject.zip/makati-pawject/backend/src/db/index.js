const fs = require('fs');
const path = require('path');
const { Pool, types } = require('pg');

// Return DATE columns as 'YYYY-MM-DD' strings and NUMERIC as numbers
types.setTypeParser(1082, (v) => v);
types.setTypeParser(1700, (v) => (v === null ? null : parseFloat(v)));

const SCHEMA_PATH = path.join(__dirname, 'schema.sql');

// Split schema.sql into statements, ignoring comments
function splitSql(sql) {
  return sql
    .split('\n')
    .filter((line) => !line.trim().startsWith('--'))
    .join('\n')
    .split(';')
    .map((s) => s.trim())
    .filter(Boolean);
}

function wrap(pool, memory) {
  return {
    memory,
    query: (text, params) => pool.query(text, params),
    async one(text, params) {
      const { rows } = await pool.query(text, params);
      return rows[0] || null;
    },
    async many(text, params) {
      const { rows } = await pool.query(text, params);
      return rows;
    },
    close: () => pool.end(),
  };
}

/**
 * Create a database handle.
 * - With a connection string: real PostgreSQL (local or Render)
 * - Without: an in-memory PostgreSQL (pg-mem), handy for demos and tests
 */
function createDb({ url, ssl } = {}) {
  if (url) {
    const pool = new Pool({
      connectionString: url,
      ssl: ssl ? { rejectUnauthorized: false } : undefined,
    });
    return wrap(pool, false);
  }
  // Loaded lazily so production installs can skip it if they want
  // eslint-disable-next-line global-require
  const { newDb } = require('pg-mem');
  const mem = newDb();
  const { Pool: MemPool } = mem.adapters.createPg();
  return wrap(new MemPool(), true);
}

async function applySchema(db) {
  const sql = fs.readFileSync(SCHEMA_PATH, 'utf8');
  for (const statement of splitSql(sql)) {
    // pg-mem doesn't support DROP ... CASCADE on an empty database; skip drops there
    if (db.memory && /^DROP TABLE/i.test(statement)) continue;
    // eslint-disable-next-line no-await-in-loop
    await db.query(statement);
  }
}

module.exports = { createDb, applySchema, splitSql };
