// Usage:
//   npm run db:migrate   create tables on DATABASE_URL (drops existing ones)
//   npm run db:seed      create tables and add sample data
const config = require('../config');
const { createDb, applySchema } = require('./index');
const { seed } = require('./seed');

async function main() {
  if (!config.databaseUrl) {
    console.error('Set DATABASE_URL in .env first. Without it the server uses an in-memory database automatically.');
    process.exit(1);
  }
  const db = createDb({ url: config.databaseUrl, ssl: config.databaseSsl });
  try {
    await applySchema(db);
    console.log('Schema created.');
    if (process.argv.includes('--seed')) {
      await seed(db);
      console.log('Sample data added.');
    }
  } finally {
    await db.close();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
