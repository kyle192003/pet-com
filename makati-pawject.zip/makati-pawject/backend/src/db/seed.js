const bcrypt = require('bcryptjs');

const ROUNDS = Number(process.env.BCRYPT_ROUNDS) || 10;

// Generic placeholder ID card for sample applications (not a real ID design)
function sampleIdImage(name, idTypeLabel) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="400" viewBox="0 0 640 400">
<rect width="640" height="400" rx="28" fill="#ffffff" stroke="#000" stroke-width="4"/>
<rect x="2" y="2" width="636" height="70" rx="26" fill="#008657"/>
<text x="32" y="47" font-family="Arial, sans-serif" font-size="26" font-weight="700" fill="#fff">SAMPLE ID · DEMO ONLY</text>
<rect x="32" y="104" width="170" height="210" rx="14" fill="#e6fff3" stroke="#008657" stroke-width="3"/>
<circle cx="117" cy="180" r="42" fill="#008657"/>
<path d="M57 300c8-44 34-66 60-66s52 22 60 66z" fill="#008657"/>
<text x="232" y="138" font-family="Arial, sans-serif" font-size="18" fill="#555">Name</text>
<text x="232" y="170" font-family="Arial, sans-serif" font-size="28" font-weight="700" fill="#000">${name}</text>
<text x="232" y="218" font-family="Arial, sans-serif" font-size="18" fill="#555">ID type</text>
<text x="232" y="248" font-family="Arial, sans-serif" font-size="24" fill="#000">${idTypeLabel}</text>
<text x="232" y="296" font-family="Arial, sans-serif" font-size="18" fill="#555">No. XXXX-XXXX-0000</text>
</svg>`;
  return `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`;
}

// Demo accounts (also listed in the README and on the login page)
const USERS = [
  { key: 'admin', role: 'admin', full_name: 'Makati Admin', email: 'admin@makati.gov.ph', username: 'makatiadmin', password: 'admin123', mobile_number: '', address: 'Makati City Hall' },
  { key: 'ana', role: 'employee', full_name: 'Ana Reyes', email: 'ana.reyes@manulife.com', username: 'anareyes', password: 'employee123', mobile_number: '0917 000 1111', address: '' },
  { key: 'juan', role: 'makatizen', full_name: 'Juan Dela Cruz', email: 'juan@example.com', username: 'juandc', password: 'makatizen123', mobile_number: '0917 123 4567', address: '123 J.P. Rizal Ave, Poblacion, Makati' },
  { key: 'rica', role: 'makatizen', full_name: 'Rica Bautista', email: 'rica@example.com', username: 'ricab', password: 'makatizen123', mobile_number: '0918 222 1010', address: 'Bel-Air, Makati' },
  { key: 'leo', role: 'employee', full_name: 'Leo Tan', email: 'leo.tan@manulife.com', username: 'leotan', password: 'employee123', mobile_number: '0917 333 2020', address: '' },
  { key: 'mika', role: 'makatizen', full_name: 'Mika Flores', email: 'mika@example.com', username: 'mikaf', password: 'makatizen123', mobile_number: '0919 444 3030', address: 'Poblacion, Makati' },
];

const VOLUNTEERS = [
  { user: 'ana', preferred_pet_type: 'both', skills: 'Event marshal', availability_notes: 'Weekends', total_volunteer_hours: 18.5 },
  { user: 'juan', preferred_pet_type: 'dog', skills: 'Dog walking', availability_notes: 'Saturday mornings', total_volunteer_hours: 6 },
  { user: 'rica', preferred_pet_type: 'cat', skills: 'Vet assistant', availability_notes: 'Sundays', total_volunteer_hours: 3 },
  { user: 'leo', preferred_pet_type: 'both', skills: 'Photography', availability_notes: 'Weekends', total_volunteer_hours: 9 },
  { user: 'mika', preferred_pet_type: 'dog', skills: 'Registration booth', availability_notes: 'Mornings', total_volunteer_hours: 0 },
];

const EVENTS = [
  { key: 'funrun', title: 'Paws Fun Run 2026', short_description: 'Run 3K or 5K with your dog. Proceeds support shelter care.', description: 'Run a 3K or 5K route around Ayala Triangle with your dog, or come on your own and cheer. Every registration helps fund food, vaccines and medical care for rescued animals at the city shelter.\n\nDogs must be leashed and vaccinated. Water stations for pets are set up every kilometer, and shelter dogs will be at the finish line for anyone ready to adopt.', event_type: 'fun_run', date: '2026-10-17', start_time: '05:30', end_time: '09:00', location: 'Ayala Triangle Gardens', max_attendees: 300, sponsor: 'Manulife', is_active: true, is_volunteer_event: true, is_hours_eligible: true },
  { key: 'adoptday', title: 'Adoption Day at the Park', short_description: 'Meet dogs and cats ready for a home and talk to shelter staff.', description: 'Meet dogs and cats ready for a home and talk to shelter staff about the adoption process. Bring a valid ID if you plan to apply on the day.', event_type: 'adoption_day', date: '2026-10-25', start_time: '09:00', end_time: '15:00', location: 'Washington SyCip Park', max_attendees: 500, sponsor: 'Manulife', is_active: true, is_volunteer_event: false, is_hours_eligible: false },
  { key: 'cleanup', title: 'Shelter Clean-up Drive', short_description: 'Help clean kennels, sort donations and walk the dogs.', description: 'Help clean kennels, sort donated food and supplies, and take the shelter dogs for short walks. Wear comfortable clothes you do not mind getting dirty.', event_type: 'volunteer', date: '2026-11-07', start_time: '08:00', end_time: '12:00', location: 'Makati City Animal Shelter', max_attendees: 40, sponsor: 'Manulife', is_active: true, is_volunteer_event: true, is_hours_eligible: true },
  { key: 'seniors', title: 'Meet & Greet: Senior Dogs', short_description: 'Spend an afternoon with older dogs looking for a quiet home.', description: "Spend a relaxed afternoon with older dogs who are looking for a quiet home. Shelter staff will share each dog's story and care needs.", event_type: 'adoption_day', date: '2026-11-14', start_time: '13:00', end_time: '17:00', location: 'Poblacion Barangay Hall', max_attendees: 80, sponsor: '', is_active: true, is_volunteer_event: true, is_hours_eligible: false },
  { key: 'rabies', title: 'Anti-Rabies Vaccination Day', short_description: 'Assist vets with registration and pet handling.', description: 'City veterinarians will vaccinate dogs and cats for free. Volunteers help with registration, queueing and holding pets during vaccination.', event_type: 'volunteer', date: '2026-11-22', start_time: '08:00', end_time: '14:00', location: 'Bel-Air Covered Court', max_attendees: 30, sponsor: 'Manulife', is_active: true, is_volunteer_event: true, is_hours_eligible: true },
  { key: 'catclass', title: 'Cat Care Basics Workshop', short_description: 'A short class on feeding, litter training and vet visits.', description: 'A short class on feeding, litter training, grooming and when to see a vet. Great for first-time cat owners and new adopters.', event_type: 'recreational', date: '2026-11-28', start_time: '10:00', end_time: '12:00', location: 'Makati City Hall, Bldg. II', max_attendees: 60, sponsor: '', is_active: false, is_volunteer_event: false, is_hours_eligible: false },
];

const VOLUNTEER_ROLES = [
  { key: 'reg', event: 'funrun', role_name: 'Registration booth', description: 'Check in runners and hand out race kits.', slots_available: 4 },
  { key: 'handler', event: 'funrun', role_name: 'Dog handler', description: 'Help manage shelter dogs at the finish line.', slots_available: 6 },
  { key: 'marshal', event: 'funrun', role_name: 'Route marshal', description: 'Guide runners and keep the route safe.', slots_available: 2 },
  { key: 'kennel', event: 'cleanup', role_name: 'Kennel cleaning', description: 'Clean and disinfect kennels.', slots_available: 10 },
  { key: 'sort', event: 'cleanup', role_name: 'Donation sorting', description: 'Sort donated food and supplies.', slots_available: 6 },
  { key: 'walker', event: 'cleanup', role_name: 'Dog walker', description: 'Walk shelter dogs around the compound.', slots_available: 4 },
  { key: 'petholder', event: 'rabies', role_name: 'Pet handler', description: 'Hold pets steady during vaccination.', slots_available: 5 },
  { key: 'rabiesreg', event: 'rabies', role_name: 'Registration booth', description: 'Record pet owner details.', slots_available: 3 },
  { key: 'photo', event: 'seniors', role_name: 'Photographer', description: 'Take adoption profile photos.', slots_available: 2 },
  { key: 'counselor', event: 'seniors', role_name: 'Adoption counselor', description: 'Talk visitors through the adoption process.', slots_available: 3 },
];

const ASSIGNMENTS = [
  { role: 'kennel', user: 'ana', status: 'completed', hours_earned: 4 },
  { role: 'handler', user: 'leo', status: 'assigned', hours_earned: 0 },
  { role: 'reg', user: 'rica', status: 'assigned', hours_earned: 0 },
];

const REGISTRATIONS = [
  { event: 'funrun', user: 'rica', role_at_event: 'volunteer' },
  { event: 'funrun', user: 'leo', role_at_event: 'volunteer' },
  { event: 'funrun', user: 'mika', role_at_event: 'participant' },
  { event: 'adoptday', user: 'mika', role_at_event: 'participant' },
  { event: 'adoptday', user: 'rica', role_at_event: 'participant' },
  { event: 'cleanup', user: 'ana', role_at_event: 'volunteer' },
];

const PETS = [
  { key: 'mango', name: 'Mango', species: 'dog', breed: 'Aspin', age_years: 2, gender: 'male', size: 'medium', description: 'Gentle, loves long walks and belly rubs.', temperament: 'Gentle and a little shy with strangers. Loves long walks, belly rubs and napping by the door. Gets along with other calm dogs.', status: 'available', rescued_location: 'Barangay Poblacion', date_listed: '2026-09-30', medical: { vaccinated: true, neutered_spayed: true, notes: 'Healed leg fracture, no ongoing treatment needed.' } },
  { key: 'luna', name: 'Luna', species: 'cat', breed: 'Puspin', age_years: 1, gender: 'female', size: 'small', description: 'Curious lap cat who follows you room to room.', temperament: 'Very social and curious. Will sit on your laptop. Fine with gentle kids.', status: 'available', rescued_location: 'Barangay Bel-Air', date_listed: '2026-09-22', medical: { vaccinated: true, neutered_spayed: true, notes: '' } },
  { key: 'choco', name: 'Choco', species: 'dog', breed: 'Shih Tzu mix', age_years: 4, gender: 'male', size: 'small', description: 'Calm, good with kids, already house-trained.', temperament: 'Calm and patient. House-trained and used to apartment life.', status: 'reserved', rescued_location: 'Barangay San Lorenzo', date_listed: '2026-08-14', medical: { vaccinated: true, neutered_spayed: true, notes: 'Mild skin allergy, managed with diet.' } },
  { key: 'mochi', name: 'Mochi', species: 'cat', breed: 'Persian mix', age_years: 3, gender: 'female', size: 'small', description: 'Quiet and shy at first, then very affectionate.', temperament: 'Takes a few days to warm up, then loves to be brushed and held.', status: 'available', rescued_location: 'Barangay Guadalupe Nuevo', date_listed: '2026-09-02', medical: { vaccinated: true, neutered_spayed: false, notes: 'Scheduled for spay next month.' } },
  { key: 'bantay', name: 'Bantay', species: 'dog', breed: 'Aspin', age_years: 5, gender: 'male', size: 'large', description: 'Loyal watchdog, best as the only pet at home.', temperament: 'Protective and loyal. Needs a yard and an owner with dog experience.', status: 'available', rescued_location: 'Barangay Pio del Pilar', date_listed: '2026-07-19', medical: { vaccinated: true, neutered_spayed: true, notes: '' } },
  { key: 'ube', name: 'Ube', species: 'cat', breed: 'Puspin', age_years: 0.7, gender: 'female', size: 'small', description: 'Playful kitten, needs toys and attention.', temperament: 'High energy kitten. Best with someone home most of the day.', status: 'available', rescued_location: 'Barangay Poblacion', date_listed: '2026-09-18', medical: { vaccinated: false, neutered_spayed: false, notes: 'Second vaccine dose due soon.' } },
  { key: 'kulot', name: 'Kulot', species: 'dog', breed: 'Poodle mix', age_years: 2, gender: 'female', size: 'medium', description: 'Smart, energetic, learns tricks quickly.', temperament: 'Eager to please and quick to learn. Needs daily play.', status: 'available', rescued_location: 'Barangay Palanan', date_listed: '2026-09-09', medical: { vaccinated: true, neutered_spayed: true, notes: '' } },
  { key: 'tiger', name: 'Tiger', species: 'cat', breed: 'Puspin', age_years: 6, gender: 'male', size: 'medium', description: 'Relaxed senior who loves sunny windows.', temperament: 'Laid back and quiet. Happy to nap most of the day.', status: 'available', rescued_location: 'Barangay Olympia', date_listed: '2026-06-28', medical: { vaccinated: true, neutered_spayed: true, notes: 'Senior check-up done in September.' } },
];

const APPLICATIONS = [
  { pet: 'mango', applicant_name: 'Maria Santos', applicant_email: 'maria.santos@example.com', applicant_phone: '0918 555 0142', address: '45 Kalayaan Ave, Poblacion, Makati', residence_type: 'house', experience_notes: 'Had two Aspins for 10 years. Works from home.', status: 'pending', admin_notes: '', valid_id_type: 'philsys', id_label: 'PhilSys National ID', id_verification_status: 'unverified', created_at: '2026-10-12T09:10:00Z' },
  { pet: 'luna', applicant_name: 'Paolo Cruz', applicant_email: 'paolo.cruz@example.com', applicant_phone: '0917 222 3344', address: 'Salcedo Village, Makati', residence_type: 'condo', experience_notes: 'First cat, has researched care basics.', status: 'pending', admin_notes: '', valid_id_type: 'drivers_license', id_label: "Driver's license", id_verification_status: 'unverified', created_at: '2026-10-12T07:30:00Z' },
  { pet: 'mochi', applicant_name: 'Liza Mendoza', applicant_email: 'liza.m@example.com', applicant_phone: '0919 111 2233', address: 'Guadalupe Nuevo, Makati', residence_type: 'apartment', experience_notes: 'Currently has one senior cat.', status: 'pending', admin_notes: '', valid_id_type: 'passport', id_label: 'Passport', id_verification_status: 'verified', created_at: '2026-10-11T12:00:00Z' },
  { pet: 'kulot', applicant_name: 'Ramon Garcia', applicant_email: 'ramon.g@example.com', applicant_phone: '0920 333 4455', address: 'Palanan, Makati', residence_type: 'townhouse', experience_notes: 'Grew up with dogs.', status: 'pending', admin_notes: '', valid_id_type: 'umid', id_label: 'UMID', id_verification_status: 'unverified', created_at: '2026-10-10T10:00:00Z' },
  { pet: 'choco', applicant_name: 'Ben Villanueva', applicant_email: 'ben.v@example.com', applicant_phone: '0921 444 5566', address: 'San Lorenzo, Makati', residence_type: 'condo', experience_notes: 'Owned a Shih Tzu before.', status: 'approved', admin_notes: 'Home visit done.', valid_id_type: 'postal', id_label: 'Postal ID', id_verification_status: 'verified', created_at: '2026-10-08T10:00:00Z' },
];

const SERVICES = [
  { title: 'Free anti-rabies vaccination', description: 'Yearly anti-rabies shot for pets of Makati residents.', service_type: 'free', pet_type: 'both', availability_schedule: 'Every Saturday, 8 AM – 12 PM', location: 'Makati Veterinary Office', contact_info: '[Contact number]', how_to_avail: 'walk_in' },
  { title: 'Low-cost spay and neuter', description: 'Subsidized surgery with a post-op check-up included.', service_type: 'discounted', pet_type: 'both', availability_schedule: 'Tue and Thu, by appointment', location: 'Makati Veterinary Office', contact_info: '[Contact number]', how_to_avail: 'appointment' },
  { title: 'Free deworming', description: 'Deworming tablets for puppies, kittens and adults.', service_type: 'free', pet_type: 'both', availability_schedule: 'Every Saturday, 8 AM – 12 PM', location: 'Barangay health centers', contact_info: '[Contact number]', how_to_avail: 'walk_in' },
  { title: 'Pet microchipping', description: 'Permanent ID chip registered to your address.', service_type: 'discounted', pet_type: 'both', availability_schedule: 'Wednesdays, by appointment', location: 'Makati Veterinary Office', contact_info: '[Contact number]', how_to_avail: 'appointment' },
  { title: 'Vet consultation', description: 'General check-up with a licensed city veterinarian.', service_type: 'discounted', pet_type: 'both', availability_schedule: 'Mon to Fri, 9 AM – 4 PM', location: 'Makati Veterinary Office', contact_info: '[Contact number]', how_to_avail: 'appointment' },
  { title: 'Free pet registration', description: 'Register your dog with the city and get a pet tag.', service_type: 'free', pet_type: 'dog', availability_schedule: 'Mon to Fri, 8 AM – 5 PM', location: 'Makati City Hall, Bldg. II', contact_info: '[Contact number]', how_to_avail: 'walk_in' },
];

const NEWSLETTERS = [
  { title: 'Adoption Day comes to Washington SyCip Park', summary: 'What to expect on October 25, which pets will be there and how to prepare your home before applying.', body: 'Adoption Day is back on October 25 at Washington SyCip Park.\n\nShelter staff will bring dogs and cats that are vaccinated and ready for a home. Bring a valid ID if you plan to apply on the day, and think about who at home will care for your new pet day to day.\n\nSee you at the park.', published_at: '2026-10-01T08:00:00Z' },
  { title: 'Paws Fun Run registration is open', summary: 'Sign-ups for the October run are live, with new volunteer roles for employees.', body: 'Registration for the Paws Fun Run 2026 is now open.\n\nManulife employees can sign up as volunteers and earn volunteer hours.', published_at: '2026-09-02T08:00:00Z' },
  { title: 'Vaccination drive recap', summary: 'City vets and volunteers vaccinated pets across barangays in one weekend.', body: 'Thank you to everyone who brought their pets and to the volunteers who helped with registration and handling.', published_at: '2026-08-05T08:00:00Z' },
  { title: "Meet this month's adoptees", summary: 'Six dogs and cats found homes, and their families shared first-week photos.', body: 'Six pets went home with new families this month. Here is how they are settling in.', published_at: '2026-07-03T08:00:00Z' },
  { title: 'November shelter wishlist', summary: 'Supplies the shelter needs this month.', body: 'Draft: list the food, litter and medicine the shelter needs.', published_at: null },
];

const POLICIES = [
  { user: 'ana', pet_name: 'Mango', species: 'dog', breed: 'Aspin', age_years: 2, policy_status: 'active', created_at: '2026-05-01T08:00:00Z' },
  { user: 'ana', pet_name: 'Luna', species: 'cat', breed: 'Puspin', age_years: 1, policy_status: 'pending', created_at: '2026-09-20T08:00:00Z' },
  { user: 'ana', pet_name: 'Brownie', species: 'dog', breed: 'Beagle', age_years: 9, policy_status: 'expired', created_at: '2025-03-01T08:00:00Z' },
];

async function insert(db, table, row) {
  const cols = Object.keys(row);
  const params = cols.map((_, i) => `$${i + 1}`);
  const sql = `INSERT INTO ${table} (${cols.join(', ')}) VALUES (${params.join(', ')}) RETURNING id`;
  const { rows } = await db.query(sql, cols.map((c) => row[c]));
  return rows[0].id;
}

/* eslint-disable no-await-in-loop */
async function seed(db) {
  const ids = { users: {}, events: {}, roles: {}, pets: {} };

  for (const { key, password, ...u } of USERS) {
    ids.users[key] = await insert(db, 'users', { ...u, password_hash: await bcrypt.hash(password, ROUNDS) });
  }
  const admin = ids.users.admin;

  for (const { user, ...v } of VOLUNTEERS) await insert(db, 'volunteers', { ...v, user_id: ids.users[user] });
  for (const { key, ...e } of EVENTS) ids.events[key] = await insert(db, 'events', { ...e, created_by_user_id: admin });
  for (const { key, event, ...r } of VOLUNTEER_ROLES) ids.roles[key] = await insert(db, 'volunteer_roles', { ...r, event_id: ids.events[event] });
  for (const { role, user, ...a } of ASSIGNMENTS) await insert(db, 'volunteer_assignments', { ...a, volunteer_role_id: ids.roles[role], user_id: ids.users[user] });
  for (const { event, user, ...r } of REGISTRATIONS) await insert(db, 'event_registrations', { ...r, event_id: ids.events[event], user_id: ids.users[user] });

  for (const { key, medical, ...p } of PETS) {
    ids.pets[key] = await insert(db, 'pets', { ...p, photo_url: '' });
    await insert(db, 'pet_medical_info', { ...medical, pet_id: ids.pets[key] });
  }

  for (const { pet, id_label, ...a } of APPLICATIONS) {
    const verified = a.id_verification_status === 'verified';
    await insert(db, 'adoption_applications', {
      ...a,
      pet_id: ids.pets[pet],
      valid_id_image: sampleIdImage(a.applicant_name, id_label),
      valid_id_file_name: `${a.applicant_name.toLowerCase().replace(/\s+/g, '-')}-id.svg`,
      id_terms_accepted: true,
      privacy_consent: true,
      consent_at: a.created_at,
      terms_version: '2026-09',
      id_verified_by_user_id: verified ? admin : null,
      id_verified_at: verified ? a.created_at : null,
    });
  }

  for (const s of SERVICES) await insert(db, 'services', { ...s, created_by_user_id: admin });
  for (const n of NEWSLETTERS) await insert(db, 'newsletters', { ...n, author_user_id: admin });
  for (const { user, ...p } of POLICIES) await insert(db, 'pet_insurance_policies', { ...p, user_id: ids.users[user] });

  return ids;
}

module.exports = { seed, sampleIdImage, USERS };
