const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const config = require('./config');
const { authenticate } = require('./middleware/auth');
const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');
const routes = require('./routes');

/**
 * Build the Express app around a database handle.
 * Tests pass their own in-memory db; server.js passes the real one.
 */
function createApp({ db }) {
  const app = express();
  app.locals.db = db;

  app.disable('x-powered-by');
  app.use(helmet());
  app.use(cors({ origin: config.corsOrigin, credentials: false }));
  app.use(express.json({ limit: config.bodyLimit }));
  if (!config.isTest) app.use(morgan('dev'));

  app.use('/api', authenticate, routes);
  app.use(notFoundHandler);
  app.use(errorHandler);
  return app;
}

module.exports = { createApp };
