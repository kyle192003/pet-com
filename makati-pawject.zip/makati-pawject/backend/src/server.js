const config = require('./config');
const { createDb, applySchema } = require('./db');
const { seed } = require('./db/seed');
const { createApp } = require('./app');

async function start() {
  const db = createDb({ url: config.databaseUrl, ssl: config.databaseSsl });

  if (db.memory) {
    // No DATABASE_URL: build a fresh in-memory database with sample data
    await applySchema(db);
    await seed(db);
    console.log('Using in-memory PostgreSQL with sample data (resets on restart). Set DATABASE_URL to use a real database.');
  } else {
    await db.query('SELECT 1');
    console.log('Connected to PostgreSQL.');
  }

  const app = createApp({ db });
  app.listen(config.port, () => {
    console.log(`The Makati Pawject API running at http://localhost:${config.port}/api`);
  });
}

start().catch((err) => {
  console.error('Failed to start the server:', err.message);
  process.exit(1);
});
