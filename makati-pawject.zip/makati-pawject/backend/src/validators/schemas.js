const { z } = require('zod');

const text = (label, max = 500) => z.string({ required_error: `${label} is required.` }).trim().min(1, `${label} is required.`).max(max);
const optionalText = (max = 5000) => z.string().trim().max(max).optional().default('');
const dateStr = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use a date like 2026-10-17.');
const timeStr = z.string().regex(/^\d{2}:\d{2}$/, 'Use a time like 08:30.');
const phone = z.string().trim().regex(/^[0-9+\s-]{10,15}$/, 'Enter a mobile number, like 0917 123 4567.');
const age = z.coerce.number({ invalid_type_error: 'Enter an age in years.' }).min(0, 'Age cannot be negative.').max(40);

// ID photo sent as a data URL: JPG, PNG or WEBP (SVG allowed only for seeded samples)
const MAX_ID_BYTES = 5 * 1024 * 1024;
const idImage = z
  .string({ required_error: 'Upload a valid ID to submit your application.' })
  .regex(/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/, 'Upload a JPG, PNG or WEBP photo of your ID.')
  .refine((v) => Math.floor((v.length - v.indexOf(',') - 1) * 0.75) <= MAX_ID_BYTES, 'Upload an ID photo under 5 MB.');

const login = z.object({
  email: z.string().trim().email('Enter a valid email.'),
  password: z.string().min(1, 'Enter your password.'),
});

const register = z.object({
  full_name: text('Full name', 120),
  username: text('Username', 40).regex(/^[a-zA-Z0-9._-]+$/, 'Use letters, numbers, dots, dashes or underscores.'),
  email: z.string().trim().email('Enter a valid email, like you@example.com.'),
  password: z.string().min(8, 'Use at least 8 characters.').max(100),
  mobile_number: phone,
  address: text('Address', 300),
  wants_to_volunteer: z.boolean().optional().default(false),
  preferred_pet_type: z.enum(['dog', 'cat', 'both']).optional().default('both'),
  skills: optionalText(300),
  availability_notes: optionalText(300),
});

const EVENT_TYPES = ['fun_run', 'adoption_day', 'volunteer', 'recreational'];
const eventBody = z.object({
  title: text('Title', 150),
  short_description: optionalText(300),
  description: optionalText(5000),
  event_type: z.enum(EVENT_TYPES, { errorMap: () => ({ message: 'Choose an event type.' }) }),
  date: dateStr,
  start_time: timeStr,
  end_time: timeStr,
  location: text('Location', 200),
  max_attendees: z.coerce.number().int().min(0).optional().default(0),
  sponsor: optionalText(100),
  is_active: z.boolean().optional().default(true),
  is_volunteer_event: z.boolean().optional().default(false),
  is_hours_eligible: z.boolean().optional().default(false),
});

const eventQuery = z.object({
  type: z.enum(EVENT_TYPES).optional().or(z.literal('')),
  from: dateStr.optional().or(z.literal('')),
  to: dateStr.optional().or(z.literal('')),
  location: z.string().optional(),
  volunteerOnly: z.enum(['true', 'false']).optional(),
  hoursEligibleOnly: z.enum(['true', 'false']).optional(),
  includeInactive: z.enum(['true', 'false']).optional(),
});

const eventRegistration = z.object({
  role_at_event: z.enum(['volunteer', 'participant'], { errorMap: () => ({ message: 'Choose volunteer or participant.' }) }),
});

const petBody = z.object({
  name: text('Name', 60),
  species: z.enum(['dog', 'cat'], { errorMap: () => ({ message: 'Choose dog or cat.' }) }),
  breed: text('Breed', 80),
  age_years: age,
  gender: z.enum(['male', 'female']),
  size: z.enum(['small', 'medium', 'large']),
  description: text('Short bio', 300),
  temperament: optionalText(2000),
  photo_url: z.string().trim().url('Enter a full photo URL, or leave it empty.').optional().or(z.literal('')).default(''),
  status: z.enum(['available', 'reserved', 'adopted', 'archived']).optional().default('available'),
  rescued_location: optionalText(150),
  medical: z
    .object({ vaccinated: z.boolean(), neutered_spayed: z.boolean(), notes: optionalText(1000) })
    .optional(),
});

const petQuery = z.object({
  species: z.enum(['dog', 'cat']).optional().or(z.literal('')),
  size: z.enum(['small', 'medium', 'large']).optional().or(z.literal('')),
  status: z.enum(['available', 'reserved', 'adopted', 'archived']).optional().or(z.literal('')),
  age: z.enum(['under1', '1to5', 'over5']).optional().or(z.literal('')),
  includeArchived: z.enum(['true', 'false']).optional(),
});

const application = z.object({
  pet_id: z.coerce.number().int().positive('Choose a pet.'),
  applicant_name: text('Full name', 120),
  applicant_email: z.string().trim().email('Enter a valid email.'),
  applicant_phone: phone,
  address: text('Address', 300),
  residence_type: z.enum(['house', 'condo', 'apartment', 'townhouse']),
  experience_notes: optionalText(2000),
  agreed_to_terms: z.literal(true, { errorMap: () => ({ message: 'Agree to the adoption terms to continue.' }) }),
  valid_id_type: text('ID type', 40),
  valid_id_image: idImage,
  valid_id_file_name: optionalText(200),
  id_terms_accepted: z.literal(true, { errorMap: () => ({ message: 'Agree to the Terms and Conditions to upload your ID.' }) }),
  privacy_consent: z.literal(true, { errorMap: () => ({ message: 'Give your consent under the Data Privacy Act to upload your ID.' }) }),
  terms_version: text('Terms version', 20),
});

const applicationUpdate = z
  .object({
    status: z.enum(['pending', 'approved', 'rejected']).optional(),
    admin_notes: z.string().max(2000).optional(),
  })
  .refine((v) => v.status !== undefined || v.admin_notes !== undefined, 'Send a status or admin notes.');

const idVerification = z.object({
  id_verification_status: z.enum(['unverified', 'verified', 'mismatch']),
});

const serviceBody = z.object({
  title: text('Title', 150),
  description: text('Description', 2000),
  service_type: z.enum(['free', 'discounted']),
  pet_type: z.enum(['dog', 'cat', 'both']),
  availability_schedule: text('Schedule', 200),
  location: text('Location', 200),
  contact_info: optionalText(200),
  how_to_avail: z.enum(['walk_in', 'appointment']).optional().default('walk_in'),
});

const newsletterBody = z.object({
  title: text('Title', 200),
  summary: text('Summary', 500),
  body: text('Body', 20000),
  publish: z.boolean().optional().default(false),
});

const policyBody = z.object({
  pet_name: text("Pet's name", 60),
  species: z.enum(['dog', 'cat']),
  breed: text('Breed', 80),
  age_years: age,
});

module.exports = {
  login,
  register,
  eventBody,
  eventQuery,
  eventRegistration,
  petBody,
  petQuery,
  application,
  applicationUpdate,
  idVerification,
  serviceBody,
  newsletterBody,
  policyBody,
  MAX_ID_BYTES,
};
