const { Router } = require('express');
const { requireAuth, requireRole } = require('../middleware/auth');
const volunteers = require('../services/volunteers.service');
const events = require('../services/events.service');
const { idParam } = require('../utils/params');

const router = Router();
const db = (req) => req.app.locals.db;

// GET /api/volunteers/opportunities?hoursEligibleOnly=true
router.get('/opportunities', async (req, res) => {
  res.json(await events.list(db(req), { volunteerOnly: 'true', hoursEligibleOnly: req.query.hoursEligibleOnly }));
});

// POST /api/volunteers/roles/:roleId/signup
router.post('/roles/:roleId/signup', requireAuth, async (req, res) => {
  res.status(201).json(await volunteers.signUp(db(req), idParam(req, 'roleId'), req.user.id));
});

// GET /api/volunteers/assignments/me
router.get('/assignments/me', requireAuth, async (req, res) => {
  res.json(await volunteers.myAssignments(db(req), req.user.id));
});

// GET /api/volunteers/me/summary
router.get('/me/summary', requireAuth, async (req, res) => {
  res.json(await volunteers.summary(db(req), req.user.id));
});

// GET /api/volunteers (admin)
router.get('/', requireRole('admin'), async (req, res) => {
  res.json(await volunteers.list(db(req)));
});

module.exports = router;
