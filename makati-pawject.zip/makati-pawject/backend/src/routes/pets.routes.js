const { Router } = require('express');
const validate = require('../middleware/validate');
const { requireRole } = require('../middleware/auth');
const schemas = require('../validators/schemas');
const pets = require('../services/pets.service');
const { idParam } = require('../utils/params');

const router = Router();
const db = (req) => req.app.locals.db;

// GET /api/pets?species=&size=&age=&status=&includeArchived=
router.get('/', validate(schemas.petQuery, 'query'), async (req, res) => {
  const q = { ...req.validatedQuery };
  if (req.user?.role !== 'admin') {
    delete q.includeArchived;
    if (q.status === 'archived') q.status = '';
  }
  res.json(await pets.list(db(req), q));
});

// GET /api/pets/:id (includes medical info)
router.get('/:id', async (req, res) => {
  const pet = await pets.get(db(req), idParam(req));
  if (pet.status === 'archived' && req.user?.role !== 'admin') {
    return res.status(404).json({ error: { message: 'This pet is no longer listed.' } });
  }
  return res.json(pet);
});

router.post('/', requireRole('admin'), validate(schemas.petBody), async (req, res) => {
  res.status(201).json(await pets.create(db(req), req.body));
});

router.put('/:id', requireRole('admin'), validate(schemas.petBody), async (req, res) => {
  res.json(await pets.update(db(req), idParam(req), req.body));
});

// PATCH /api/pets/:id/archive (admin): hides the pet from public lists
router.patch('/:id/archive', requireRole('admin'), async (req, res) => {
  res.json(await pets.archive(db(req), idParam(req)));
});

module.exports = router;
