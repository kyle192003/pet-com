const { Router } = require('express');
const validate = require('../middleware/validate');
const { requireRole } = require('../middleware/auth');
const schemas = require('../validators/schemas');
const services = require('../services/services.service');
const { idParam } = require('../utils/params');

const router = Router();
const db = (req) => req.app.locals.db;

// GET /api/services?type=free|discounted&petType=dog|cat
router.get('/', async (req, res) => {
  const type = ['free', 'discounted'].includes(req.query.type) ? req.query.type : undefined;
  const petType = ['dog', 'cat'].includes(req.query.petType) ? req.query.petType : undefined;
  res.json(await services.list(db(req), { type, petType }));
});

router.get('/:id', async (req, res) => {
  res.json(await services.get(db(req), idParam(req)));
});

router.post('/', requireRole('admin'), validate(schemas.serviceBody), async (req, res) => {
  res.status(201).json(await services.create(db(req), req.body, req.user.id));
});

router.put('/:id', requireRole('admin'), validate(schemas.serviceBody), async (req, res) => {
  res.json(await services.update(db(req), idParam(req), req.body));
});

router.delete('/:id', requireRole('admin'), async (req, res) => {
  await services.remove(db(req), idParam(req));
  res.status(204).end();
});

module.exports = router;
