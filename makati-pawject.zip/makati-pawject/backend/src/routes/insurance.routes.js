const { Router } = require('express');
const validate = require('../middleware/validate');
const { requireRole } = require('../middleware/auth');
const schemas = require('../validators/schemas');
const insurance = require('../services/insurance.service');

const router = Router();
const onlyEmployees = requireRole('employee');

// GET /api/insurance/policies/me (Manulife employees only)
router.get('/policies/me', onlyEmployees, async (req, res) => {
  res.json(await insurance.listMine(req.app.locals.db, req.user.id));
});

// POST /api/insurance/policies  { pet_name, species, breed, age_years }
router.post('/policies', onlyEmployees, validate(schemas.policyBody), async (req, res) => {
  res.status(201).json(await insurance.enroll(req.app.locals.db, req.body, req.user.id));
});

module.exports = router;
