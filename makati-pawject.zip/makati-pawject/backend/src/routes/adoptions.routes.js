const { Router } = require('express');
const validate = require('../middleware/validate');
const { requireRole } = require('../middleware/auth');
const schemas = require('../validators/schemas');
const adoptions = require('../services/adoptions.service');
const { idParam } = require('../utils/params');

const router = Router();
const db = (req) => req.app.locals.db;

// POST /api/adoptions (logged-in Makatizens and employees)
// Requires a valid ID photo, ID-upload terms and Data Privacy Act consent.
router.post('/', requireRole('makatizen', 'employee'), validate(schemas.application), async (req, res) => {
  res.status(201).json(await adoptions.submit(db(req), req.body, req.user.id));
});

// GET /api/adoptions/me (the applicant's own applications, without ID images)
router.get('/me', requireRole('makatizen', 'employee'), async (req, res) => {
  res.json(await adoptions.listMine(db(req), req.user.id));
});

// GET /api/adoptions?status= (admin)
router.get('/', requireRole('admin'), async (req, res) => {
  const { status } = req.query;
  res.json(await adoptions.list(db(req), { status: ['pending', 'approved', 'rejected'].includes(status) ? status : undefined }));
});

router.get('/:id', requireRole('admin'), async (req, res) => {
  res.json(await adoptions.get(db(req), idParam(req)));
});

// GET /api/adoptions/:id/id-image (admin only, never cached)
router.get('/:id/id-image', requireRole('admin'), async (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json(await adoptions.getIdImage(db(req), idParam(req)));
});

// PATCH /api/adoptions/:id/id-verification  { id_verification_status } (admin)
router.patch('/:id/id-verification', requireRole('admin'), validate(schemas.idVerification), async (req, res) => {
  res.json(await adoptions.setIdVerification(db(req), idParam(req), req.body.id_verification_status, req.user.id));
});

// PATCH /api/adoptions/:id  { status?, admin_notes? } (admin)
router.patch('/:id', requireRole('admin'), validate(schemas.applicationUpdate), async (req, res) => {
  res.json(await adoptions.update(db(req), idParam(req), req.body));
});

module.exports = router;
