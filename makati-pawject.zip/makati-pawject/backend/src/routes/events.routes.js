const { Router } = require('express');
const validate = require('../middleware/validate');
const { requireAuth, requireRole } = require('../middleware/auth');
const schemas = require('../validators/schemas');
const events = require('../services/events.service');
const { idParam } = require('../utils/params');

const router = Router();
const db = (req) => req.app.locals.db;

// GET /api/events?type=&from=&to=&location=&volunteerOnly=&hoursEligibleOnly=&includeInactive=
router.get('/', validate(schemas.eventQuery, 'query'), async (req, res) => {
  const q = { ...req.validatedQuery };
  if (req.user?.role !== 'admin') delete q.includeInactive; // only admins see inactive events
  res.json(await events.list(db(req), q));
});

// GET /api/events/registrations/me
router.get('/registrations/me', requireAuth, async (req, res) => {
  res.json(await events.myRegistrations(db(req), req.user.id));
});

// GET /api/events/:id
router.get('/:id', async (req, res) => {
  const event = await events.get(db(req), idParam(req));
  if (!event.is_active && req.user?.role !== 'admin') {
    return res.status(404).json({ error: { message: 'This event no longer exists.' } });
  }
  return res.json(event);
});

// POST /api/events (admin)
router.post('/', requireRole('admin'), validate(schemas.eventBody), async (req, res) => {
  res.status(201).json(await events.create(db(req), req.body, req.user.id));
});

// PUT /api/events/:id (admin)
router.put('/:id', requireRole('admin'), validate(schemas.eventBody), async (req, res) => {
  res.json(await events.update(db(req), idParam(req), req.body));
});

// DELETE /api/events/:id (admin)
router.delete('/:id', requireRole('admin'), async (req, res) => {
  await events.remove(db(req), idParam(req));
  res.status(204).end();
});

// POST /api/events/:id/register  { role_at_event }
router.post('/:id/register', requireAuth, validate(schemas.eventRegistration), async (req, res) => {
  res.status(201).json(await events.register(db(req), idParam(req), req.user.id, req.body.role_at_event));
});

module.exports = router;
