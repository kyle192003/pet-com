const { Router } = require('express');

const router = Router();

router.get('/health', (req, res) => res.json({ ok: true, database: req.app.locals.db.memory ? 'in-memory' : 'postgresql' }));
router.use('/auth', require('./auth.routes'));
router.use('/events', require('./events.routes'));
router.use('/volunteers', require('./volunteers.routes'));
router.use('/pets', require('./pets.routes'));
router.use('/adoptions', require('./adoptions.routes'));
router.use('/services', require('./services.routes'));
router.use('/newsletters', require('./newsletters.routes'));
router.use('/insurance', require('./insurance.routes'));
router.use('/admin', require('./admin.routes'));

module.exports = router;
