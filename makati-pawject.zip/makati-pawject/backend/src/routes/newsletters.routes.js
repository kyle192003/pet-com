const { Router } = require('express');
const validate = require('../middleware/validate');
const { requireRole } = require('../middleware/auth');
const schemas = require('../validators/schemas');
const newsletters = require('../services/newsletters.service');
const { idParam } = require('../utils/params');

const router = Router();
const db = (req) => req.app.locals.db;
const isAdmin = (req) => req.user?.role === 'admin';

// GET /api/newsletters?includeDrafts=true (drafts for admins only)
router.get('/', async (req, res) => {
  res.json(await newsletters.list(db(req), { includeDrafts: isAdmin(req) && req.query.includeDrafts === 'true' }));
});

router.get('/:id', async (req, res) => {
  res.json(await newsletters.get(db(req), idParam(req), { includeDrafts: isAdmin(req) }));
});

// { title, summary, body, publish }
router.post('/', requireRole('admin'), validate(schemas.newsletterBody), async (req, res) => {
  res.status(201).json(await newsletters.create(db(req), req.body, req.user.id));
});

router.put('/:id', requireRole('admin'), validate(schemas.newsletterBody), async (req, res) => {
  res.json(await newsletters.update(db(req), idParam(req), req.body));
});

router.delete('/:id', requireRole('admin'), async (req, res) => {
  await newsletters.remove(db(req), idParam(req));
  res.status(204).end();
});

module.exports = router;
