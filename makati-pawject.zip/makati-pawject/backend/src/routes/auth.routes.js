const { Router } = require('express');
const validate = require('../middleware/validate');
const { requireAuth } = require('../middleware/auth');
const schemas = require('../validators/schemas');
const auth = require('../services/auth.service');

const router = Router();

// POST /api/auth/login  { email, password } -> { token, user }
router.post('/login', validate(schemas.login), async (req, res) => {
  res.json(await auth.login(req.app.locals.db, req.body));
});

// POST /api/auth/register -> 201 { token, user }
router.post('/register', validate(schemas.register), async (req, res) => {
  res.status(201).json(await auth.register(req.app.locals.db, req.body));
});

// GET /api/auth/me -> user
router.get('/me', requireAuth, (req, res) => {
  res.json(req.user);
});

module.exports = router;
