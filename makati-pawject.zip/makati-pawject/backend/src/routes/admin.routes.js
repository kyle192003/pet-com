const { Router } = require('express');
const { requireRole } = require('../middleware/auth');
const admin = require('../services/admin.service');

const router = Router();

// GET /api/admin/stats (dashboard counts)
router.get('/stats', requireRole('admin'), async (req, res) => {
  res.json(await admin.stats(req.app.locals.db));
});

module.exports = router;
