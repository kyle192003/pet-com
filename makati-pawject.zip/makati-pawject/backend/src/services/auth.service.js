const bcrypt = require('bcryptjs');
const { conflict, unauthorized } = require('../utils/httpError');
const mappers = require('../utils/mappers');
const { signToken } = require('../middleware/auth');

const ROUNDS = Number(process.env.BCRYPT_ROUNDS) || 10;

async function login(db, { email, password }) {
  const row = await db.one('SELECT * FROM users WHERE lower(email) = lower($1)', [email]);
  // Same message for unknown email and wrong password
  if (!row || !(await bcrypt.compare(password, row.password_hash))) {
    throw unauthorized('Email or password is incorrect.');
  }
  const user = mappers.user(row);
  return { token: signToken(user), user };
}

// Public sign-up always creates a Makatizen account
async function register(db, data) {
  if (await db.one('SELECT id FROM users WHERE lower(email) = lower($1)', [data.email])) {
    throw conflict('An account with this email already exists. Log in instead.');
  }
  if (await db.one('SELECT id FROM users WHERE lower(username) = lower($1)', [data.username])) {
    throw conflict('This username is taken. Try another one.');
  }
  const passwordHash = await bcrypt.hash(data.password, ROUNDS);
  const row = await db.one(
    `INSERT INTO users (role, full_name, email, username, password_hash, mobile_number, address)
     VALUES ('makatizen', $1, $2, $3, $4, $5, $6) RETURNING *`,
    [data.full_name, data.email, data.username, passwordHash, data.mobile_number, data.address],
  );
  if (data.wants_to_volunteer) {
    await db.query(
      `INSERT INTO volunteers (user_id, preferred_pet_type, skills, availability_notes) VALUES ($1, $2, $3, $4)`,
      [row.id, data.preferred_pet_type, data.skills, data.availability_notes],
    );
  }
  const user = mappers.user(row);
  return { token: signToken(user), user };
}

module.exports = { login, register };
