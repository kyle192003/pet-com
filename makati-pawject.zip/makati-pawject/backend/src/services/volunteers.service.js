const { notFound, conflict } = require('../utils/httpError');
const mappers = require('../utils/mappers');

const GOAL_HOURS = Number(process.env.VOLUNTEER_GOAL_HOURS) || 40; // [placeholder] yearly goal

async function signUp(db, roleId, userId) {
  const role = await db.one('SELECT * FROM volunteer_roles WHERE id = $1', [roleId]);
  if (!role) throw notFound('This volunteer role no longer exists.');
  const taken = await db.one('SELECT id FROM volunteer_assignments WHERE volunteer_role_id = $1 AND user_id = $2', [roleId, userId]);
  if (taken) throw conflict("You're already signed up for this role.");
  // Atomic: only decrements when a slot is left
  const updated = await db.one(
    'UPDATE volunteer_roles SET slots_available = slots_available - 1 WHERE id = $1 AND slots_available > 0 RETURNING *',
    [roleId],
  );
  if (!updated) throw conflict('This role is full. Pick another role.');
  await db.query(`INSERT INTO volunteer_assignments (volunteer_role_id, user_id, status) VALUES ($1, $2, 'assigned')`, [roleId, userId]);
  return mappers.volunteerRole(updated);
}

async function myAssignments(db, userId) {
  const rows = await db.many(
    `SELECT a.id, a.volunteer_role_id, a.status, a.hours_earned, r.event_id, r.role_name
     FROM volunteer_assignments a JOIN volunteer_roles r ON r.id = a.volunteer_role_id
     WHERE a.user_id = $1 ORDER BY a.id`,
    [userId],
  );
  return rows.map((r) => ({ ...r, hours_earned: mappers.toNum(r.hours_earned) }));
}

async function summary(db, userId) {
  const volunteer = await db.one('SELECT total_volunteer_hours FROM volunteers WHERE user_id = $1', [userId]);
  const mine = await myAssignments(db, userId);
  return {
    total_hours: mappers.toNum(volunteer?.total_volunteer_hours) || 0,
    completed: mine.filter((a) => a.status === 'completed').length,
    upcoming: mine.filter((a) => a.status === 'assigned').length,
    goal_hours: GOAL_HOURS,
  };
}

async function list(db) {
  const rows = await db.many(
    `SELECT v.*, u.full_name, u.email FROM volunteers v JOIN users u ON u.id = v.user_id ORDER BY v.id`,
  );
  return rows.map((r) => ({ ...r, total_volunteer_hours: mappers.toNum(r.total_volunteer_hours) }));
}

module.exports = { signUp, myAssignments, summary, list };
