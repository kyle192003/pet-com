const { notFound } = require('../utils/httpError');
const mappers = require('../utils/mappers');

// Newest first, drafts (no published_at) on top for admins
const ORDER = 'ORDER BY (published_at IS NULL) DESC, published_at DESC, id DESC';

async function list(db, { includeDrafts = false } = {}) {
  const rows = await db.many(`SELECT * FROM newsletters ${includeDrafts ? '' : 'WHERE published_at IS NOT NULL'} ${ORDER}`);
  return rows.map(mappers.newsletter);
}

// Drafts are only visible to admins
async function get(db, id, { includeDrafts = false } = {}) {
  const row = await db.one('SELECT * FROM newsletters WHERE id = $1', [id]);
  if (!row || (!row.published_at && !includeDrafts)) throw notFound('This newsletter no longer exists.');
  return mappers.newsletter(row);
}

async function create(db, { title, summary, body, publish }, userId) {
  const row = await db.one(
    `INSERT INTO newsletters (title, summary, body, published_at, author_user_id) VALUES ($1, $2, $3, ${publish ? 'NOW()' : 'NULL'}, $4) RETURNING *`,
    [title, summary, body, userId],
  );
  return mappers.newsletter(row);
}

async function update(db, id, { title, summary, body, publish }) {
  const current = await get(db, id, { includeDrafts: true });
  let publishedSql = 'published_at';
  if (publish && !current.published_at) publishedSql = 'NOW()';
  if (publish === false) publishedSql = 'NULL';
  const row = await db.one(
    `UPDATE newsletters SET title = $1, summary = $2, body = $3, published_at = ${publishedSql} WHERE id = $4 RETURNING *`,
    [title, summary, body, id],
  );
  return mappers.newsletter(row);
}

async function remove(db, id) {
  const row = await db.one('DELETE FROM newsletters WHERE id = $1 RETURNING id', [id]);
  if (!row) throw notFound('This newsletter no longer exists.');
}

module.exports = { list, get, create, update, remove };
