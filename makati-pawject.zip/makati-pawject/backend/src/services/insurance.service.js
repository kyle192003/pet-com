const mappers = require('../utils/mappers');

async function listMine(db, userId) {
  const rows = await db.many('SELECT * FROM pet_insurance_policies WHERE user_id = $1 ORDER BY created_at DESC', [userId]);
  return rows.map(mappers.policy);
}

async function enroll(db, data, userId) {
  const row = await db.one(
    `INSERT INTO pet_insurance_policies (user_id, pet_name, species, breed, age_years, policy_status)
     VALUES ($1, $2, $3, $4, $5, 'pending') RETURNING *`,
    [userId, data.pet_name, data.species, data.breed, data.age_years],
  );
  return mappers.policy(row);
}

module.exports = { listMine, enroll };
