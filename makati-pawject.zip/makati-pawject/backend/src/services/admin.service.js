async function stats(db) {
  const count = async (sql) => (await db.one(sql)).n;
  return {
    activeEvents: await count('SELECT COUNT(*)::int AS n FROM events WHERE is_active = TRUE'),
    pendingApplications: await count("SELECT COUNT(*)::int AS n FROM adoption_applications WHERE status = 'pending'"),
    volunteers: await count('SELECT COUNT(*)::int AS n FROM volunteers'),
    services: await count('SELECT COUNT(*)::int AS n FROM services'),
    availablePets: await count("SELECT COUNT(*)::int AS n FROM pets WHERE status = 'available'"),
  };
}

module.exports = { stats };
