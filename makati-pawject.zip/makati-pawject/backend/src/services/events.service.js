const { notFound, conflict } = require('../utils/httpError');
const mappers = require('../utils/mappers');

// Adds volunteer_roles, counts and slots left to each event
async function withExtras(db, rows) {
  if (!rows.length) return [];
  const ids = rows.map((r) => r.id);
  const inList = ids.map((_, i) => `$${i + 1}`).join(', ');
  const roles = await db.many(`SELECT * FROM volunteer_roles WHERE event_id IN (${inList}) ORDER BY id`, ids);
  const counts = await db.many(
    `SELECT event_id, role_at_event, COUNT(*)::int AS n FROM event_registrations
     WHERE status <> 'cancelled' AND event_id IN (${inList}) GROUP BY event_id, role_at_event`,
    ids,
  );
  return rows.map((row) => {
    const eventRoles = roles.filter((r) => r.event_id === row.id).map(mappers.volunteerRole);
    const count = (role) => counts.find((c) => c.event_id === row.id && c.role_at_event === role)?.n || 0;
    return {
      ...mappers.event(row),
      volunteer_roles: eventRoles,
      volunteer_slots_left: eventRoles.reduce((n, r) => n + r.slots_available, 0),
      volunteer_count: count('volunteer'),
      participant_count: count('participant'),
    };
  });
}

async function list(db, f = {}) {
  const where = [];
  const params = [];
  const add = (sql, value) => {
    params.push(value);
    where.push(sql.replace('?', `$${params.length}`));
  };
  if (f.includeInactive !== 'true') where.push('is_active = TRUE');
  if (f.type) add('event_type = ?', f.type);
  if (f.from) add('date >= ?::date', f.from);
  if (f.to) add('date <= ?::date', f.to);
  if (f.location) add('location = ?', f.location);
  if (f.volunteerOnly === 'true') where.push('is_volunteer_event = TRUE');
  if (f.hoursEligibleOnly === 'true') where.push('is_hours_eligible = TRUE');
  const sql = `SELECT * FROM events ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY date ASC, start_time ASC`;
  return withExtras(db, await db.many(sql, params));
}

async function get(db, id) {
  const row = await db.one('SELECT * FROM events WHERE id = $1', [id]);
  if (!row) throw notFound('This event no longer exists.');
  const [event] = await withExtras(db, [row]);
  return event;
}

const FIELDS = ['title', 'short_description', 'description', 'event_type', 'date', 'start_time', 'end_time', 'location', 'max_attendees', 'sponsor', 'is_active', 'is_volunteer_event', 'is_hours_eligible'];

async function create(db, data, userId) {
  const cols = [...FIELDS, 'created_by_user_id'];
  const values = [...FIELDS.map((f) => data[f]), userId];
  const row = await db.one(
    `INSERT INTO events (${cols.join(', ')}) VALUES (${cols.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *`,
    values,
  );
  return get(db, row.id);
}

async function update(db, id, data) {
  const sets = FIELDS.map((f, i) => `${f} = $${i + 1}`).join(', ');
  const row = await db.one(`UPDATE events SET ${sets} WHERE id = $${FIELDS.length + 1} RETURNING id`, [...FIELDS.map((f) => data[f]), id]);
  if (!row) throw notFound('This event no longer exists.');
  return get(db, id);
}

async function remove(db, id) {
  const row = await db.one('DELETE FROM events WHERE id = $1 RETURNING id', [id]);
  if (!row) throw notFound('This event no longer exists.');
}

async function register(db, eventId, userId, roleAtEvent) {
  const event = await get(db, eventId);
  if (!event.is_active) throw conflict('This event is no longer open for registration.');
  if (roleAtEvent === 'volunteer' && !event.is_volunteer_event) throw conflict("This event doesn't need volunteers.");
  const existing = await db.one(
    `SELECT role_at_event FROM event_registrations WHERE event_id = $1 AND user_id = $2 AND status <> 'cancelled'`,
    [eventId, userId],
  );
  if (existing) throw conflict(`You're already registered as a ${existing.role_at_event}.`);
  const total = event.volunteer_count + event.participant_count;
  if (event.max_attendees && total >= event.max_attendees) throw conflict('This event is full.');
  await db.query(
    `INSERT INTO event_registrations (event_id, user_id, role_at_event, status) VALUES ($1, $2, $3, 'confirmed')`,
    [eventId, userId, roleAtEvent],
  );
  return get(db, eventId);
}

async function myRegistrations(db, userId) {
  const rows = await db.many(
    `SELECT id, event_id, role_at_event, status FROM event_registrations WHERE user_id = $1 AND status <> 'cancelled' ORDER BY id`,
    [userId],
  );
  return rows;
}

module.exports = { list, get, create, update, remove, register, myRegistrations };
