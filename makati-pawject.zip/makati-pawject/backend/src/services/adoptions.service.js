const { notFound, conflict } = require('../utils/httpError');
const mappers = require('../utils/mappers');

// All columns except the ID image itself
const COLUMNS = `a.id, a.pet_id, a.user_id, a.applicant_name, a.applicant_email, a.applicant_phone, a.address,
  a.residence_type, a.experience_notes, a.status, a.admin_notes, a.valid_id_type, a.valid_id_file_name,
  (a.valid_id_image IS NOT NULL) AS has_valid_id, a.id_terms_accepted, a.privacy_consent, a.consent_at,
  a.terms_version, a.id_verification_status, a.id_verified_by_user_id, a.id_verified_at, a.created_at,
  p.name AS pet_name, p.species AS pet_species`;

async function get(db, id) {
  const row = await db.one(`SELECT ${COLUMNS} FROM adoption_applications a JOIN pets p ON p.id = a.pet_id WHERE a.id = $1`, [id]);
  if (!row) throw notFound('This application no longer exists.');
  return mappers.application(row);
}

async function list(db, { status } = {}) {
  const params = [];
  let where = '';
  if (status) {
    params.push(status);
    where = 'WHERE a.status = $1';
  }
  const rows = await db.many(
    `SELECT ${COLUMNS} FROM adoption_applications a JOIN pets p ON p.id = a.pet_id ${where} ORDER BY a.created_at DESC`,
    params,
  );
  return rows.map(mappers.application);
}

async function listMine(db, userId) {
  const rows = await db.many(
    `SELECT ${COLUMNS} FROM adoption_applications a JOIN pets p ON p.id = a.pet_id WHERE a.user_id = $1 ORDER BY a.created_at DESC`,
    [userId],
  );
  return rows.map(mappers.application);
}

async function submit(db, data, userId) {
  const pet = await db.one('SELECT id, name, status FROM pets WHERE id = $1', [data.pet_id]);
  if (!pet) throw notFound('This pet is no longer listed.');
  if (pet.status !== 'available') throw conflict(`${pet.name} isn't available for adoption right now.`);
  if (userId) {
    const dup = await db.one(`SELECT id FROM adoption_applications WHERE pet_id = $1 AND user_id = $2 AND status = 'pending'`, [pet.id, userId]);
    if (dup) throw conflict(`You already have a pending application for ${pet.name}.`);
  }
  const row = await db.one(
    `INSERT INTO adoption_applications
      (pet_id, user_id, applicant_name, applicant_email, applicant_phone, address, residence_type, experience_notes,
       valid_id_type, valid_id_image, valid_id_file_name, id_terms_accepted, privacy_consent, consent_at, terms_version)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, NOW(), $14) RETURNING id`,
    [
      pet.id, userId || null, data.applicant_name, data.applicant_email, data.applicant_phone, data.address,
      data.residence_type, data.experience_notes, data.valid_id_type, data.valid_id_image, data.valid_id_file_name,
      data.id_terms_accepted, data.privacy_consent, data.terms_version,
    ],
  );
  return get(db, row.id);
}

async function getIdImage(db, id) {
  const row = await db.one('SELECT valid_id_image, valid_id_file_name, valid_id_type FROM adoption_applications WHERE id = $1', [id]);
  if (!row) throw notFound('This application no longer exists.');
  return { data_url: row.valid_id_image, file_name: row.valid_id_file_name, id_type: row.valid_id_type };
}

async function setIdVerification(db, id, status, adminId) {
  const app = await get(db, id);
  if (app.status !== 'pending') throw conflict('Only pending applications can be re-checked.');
  const reset = status === 'unverified';
  await db.query(
    `UPDATE adoption_applications SET id_verification_status = $1, id_verified_by_user_id = $2, id_verified_at = ${reset ? 'NULL' : 'NOW()'} WHERE id = $3`,
    [status, reset ? null : adminId, id],
  );
  return get(db, id);
}

// Approving needs a verified ID and marks the pet as adopted
async function update(db, id, { status, admin_notes }) {
  const app = await get(db, id);
  if (status === 'approved' && app.status !== 'approved') {
    if (app.id_verification_status !== 'verified') throw conflict("Verify the applicant's ID before approving.");
    const pet = await db.one('SELECT status FROM pets WHERE id = $1', [app.pet_id]);
    if (pet && pet.status === 'adopted') throw conflict(`${app.pet_name} has already been adopted.`);
  }
  await db.query('UPDATE adoption_applications SET status = COALESCE($1, status), admin_notes = COALESCE($2, admin_notes) WHERE id = $3', [
    status ?? null, admin_notes ?? null, id,
  ]);
  if (status === 'approved' && app.status !== 'approved') {
    await db.query(`UPDATE pets SET status = 'adopted' WHERE id = $1`, [app.pet_id]);
  }
  return get(db, id);
}

module.exports = { get, list, listMine, submit, getIdImage, setIdVerification, update };
