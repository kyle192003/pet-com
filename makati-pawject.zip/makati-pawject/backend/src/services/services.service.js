const { notFound } = require('../utils/httpError');
const mappers = require('../utils/mappers');

const FIELDS = ['title', 'description', 'service_type', 'pet_type', 'availability_schedule', 'location', 'contact_info', 'how_to_avail'];

async function list(db, { type, petType } = {}) {
  const where = [];
  const params = [];
  if (type) {
    params.push(type);
    where.push(`service_type = $${params.length}`);
  }
  if (petType) {
    params.push(petType);
    where.push(`(pet_type = $${params.length} OR pet_type = 'both')`);
  }
  const rows = await db.many(`SELECT * FROM services ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY id`, params);
  return rows.map(mappers.service);
}

async function get(db, id) {
  const row = await db.one('SELECT * FROM services WHERE id = $1', [id]);
  if (!row) throw notFound('This service no longer exists.');
  return mappers.service(row);
}

async function create(db, data, userId) {
  const cols = [...FIELDS, 'created_by_user_id'];
  const row = await db.one(
    `INSERT INTO services (${cols.join(', ')}) VALUES (${cols.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *`,
    [...FIELDS.map((f) => data[f]), userId],
  );
  return mappers.service(row);
}

async function update(db, id, data) {
  const sets = FIELDS.map((f, i) => `${f} = $${i + 1}`).join(', ');
  const row = await db.one(`UPDATE services SET ${sets} WHERE id = $${FIELDS.length + 1} RETURNING *`, [...FIELDS.map((f) => data[f]), id]);
  if (!row) throw notFound('This service no longer exists.');
  return mappers.service(row);
}

async function remove(db, id) {
  const row = await db.one('DELETE FROM services WHERE id = $1 RETURNING id', [id]);
  if (!row) throw notFound('This service no longer exists.');
}

module.exports = { list, get, create, update, remove };
