const { notFound } = require('../utils/httpError');
const mappers = require('../utils/mappers');

const AGE_SQL = {
  under1: 'age_years < 1',
  '1to5': 'age_years >= 1 AND age_years <= 5',
  over5: 'age_years > 5',
};

async function attachMedical(db, rows) {
  if (!rows.length) return [];
  const ids = rows.map((r) => r.id);
  const med = await db.many(`SELECT * FROM pet_medical_info WHERE pet_id IN (${ids.map((_, i) => `$${i + 1}`).join(', ')})`, ids);
  return rows.map((row) => ({ ...mappers.pet(row), medical: mappers.medical(med.find((m) => m.pet_id === row.id)) }));
}

async function list(db, f = {}) {
  const where = [];
  const params = [];
  const add = (col, value) => {
    params.push(value);
    where.push(`${col} = $${params.length}`);
  };
  if (f.includeArchived !== 'true') where.push("status <> 'archived'");
  if (f.species) add('species', f.species);
  if (f.size) add('size', f.size);
  if (f.status) add('status', f.status);
  if (f.age && AGE_SQL[f.age]) where.push(AGE_SQL[f.age]);
  const sql = `SELECT * FROM pets ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY date_listed DESC, id DESC`;
  return attachMedical(db, await db.many(sql, params));
}

async function get(db, id) {
  const row = await db.one('SELECT * FROM pets WHERE id = $1', [id]);
  if (!row) throw notFound('This pet is no longer listed.');
  const [pet] = await attachMedical(db, [row]);
  return pet;
}

const FIELDS = ['name', 'species', 'breed', 'age_years', 'gender', 'size', 'description', 'temperament', 'photo_url', 'status', 'rescued_location'];

async function saveMedical(db, petId, medical) {
  if (!medical) return;
  const existing = await db.one('SELECT id FROM pet_medical_info WHERE pet_id = $1', [petId]);
  if (existing) {
    await db.query('UPDATE pet_medical_info SET vaccinated = $1, neutered_spayed = $2, notes = $3 WHERE pet_id = $4', [
      medical.vaccinated, medical.neutered_spayed, medical.notes, petId,
    ]);
  } else {
    await db.query('INSERT INTO pet_medical_info (pet_id, vaccinated, neutered_spayed, notes) VALUES ($1, $2, $3, $4)', [
      petId, medical.vaccinated, medical.neutered_spayed, medical.notes,
    ]);
  }
}

async function create(db, data) {
  const row = await db.one(
    `INSERT INTO pets (${FIELDS.join(', ')}) VALUES (${FIELDS.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING id`,
    FIELDS.map((f) => data[f]),
  );
  await saveMedical(db, row.id, data.medical);
  return get(db, row.id);
}

async function update(db, id, data) {
  const sets = FIELDS.map((f, i) => `${f} = $${i + 1}`).join(', ');
  const row = await db.one(`UPDATE pets SET ${sets} WHERE id = $${FIELDS.length + 1} RETURNING id`, [...FIELDS.map((f) => data[f]), id]);
  if (!row) throw notFound('This pet is no longer listed.');
  await saveMedical(db, id, data.medical);
  return get(db, id);
}

async function archive(db, id) {
  const row = await db.one(`UPDATE pets SET status = 'archived' WHERE id = $1 RETURNING id`, [id]);
  if (!row) throw notFound('This pet is no longer listed.');
  return get(db, id);
}

module.exports = { list, get, create, update, archive };
