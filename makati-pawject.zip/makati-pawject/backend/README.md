# The Makati Pawject – Backend (Express JSON API + PostgreSQL)

REST API for The Makati Pawject frontend: auth, events, volunteering, pets,
adoption applications with ID verification, services, newsletters, pet
insurance and admin stats.

> **Team note:** if your team already has a `backend/` folder, don't copy this
> over it. Compare and merge, or keep this as a reference implementation.

Stack: Node 20+, Express 5, PostgreSQL (`pg`), JWT auth (`jsonwebtoken`),
bcrypt password hashing (`bcryptjs`), request validation (`zod`), Jest +
Supertest.

## Run it

```bash
cd backend
npm install
npm run dev        # http://localhost:5000/api
```

With no `DATABASE_URL`, the server uses a built-in **in-memory PostgreSQL**
(pg-mem) filled with sample data. Nothing to install; data resets when the
server restarts.

### Use a real PostgreSQL (local or Render)

```bash
cp .env.example .env
# set DATABASE_URL, e.g. postgresql://postgres:postgres@localhost:5432/manupets
npm run db:seed    # creates tables and sample data (drops existing tables!)
npm run dev
```

For **Render PostgreSQL**, use its External Database URL and set
`DATABASE_SSL=true`. `npm run db:migrate` creates tables without sample data.
Set a long random `JWT_SECRET` in production.

## Tests (Jest + Supertest)

```bash
npm test                  # 78 tests on the in-memory database
npm run test:coverage     # with coverage (~98% of lines)
```

To run the same tests against a real PostgreSQL, point
`TEST_DATABASE_URL` at a **throwaway** database (tables are dropped and
recreated for every test):

```bash
TEST_DATABASE_URL=postgresql://user:pass@localhost:5432/manupets_test npm test
```

Every test gets a fresh, seeded database. Files in `tests/`:
`auth`, `events`, `volunteers`, `pets`, `adoptions`, `services`,
`newsletters`, `insurance`, `admin`, plus `unit/` tests for the mappers and
validators.

## Folder structure

```
backend/
├── src/
│   ├── server.js            # starts the server (in-memory DB if no DATABASE_URL)
│   ├── app.js               # Express app factory: createApp({ db })
│   ├── config.js            # reads .env
│   ├── db/
│   │   ├── schema.sql       # all tables
│   │   ├── seed.js          # sample data (demo accounts, pets, events…)
│   │   ├── migrate.js       # npm run db:migrate / db:seed
│   │   └── index.js         # createDb(): pg Pool or pg-mem
│   ├── middleware/          # auth (JWT, roles), validate (zod), errorHandler
│   ├── routes/              # one router per resource
│   ├── services/            # SQL + business rules
│   ├── validators/schemas.js
│   └── utils/               # httpError, mappers, params
└── tests/                   # Jest + Supertest
```

## API

Base URL: `http://localhost:5000/api`. Send `Authorization: Bearer <token>`
after logging in. All bodies are JSON. Errors look like:

```json
{ "error": { "message": "Enter a valid email.", "fields": { "email": "Enter a valid email." } } }
```

| Method | Path | Who | Notes |
| --- | --- | --- | --- |
| GET | `/health` | anyone | `{ ok, database }` |
| POST | `/auth/login` | anyone | `{ email, password }` → `{ token, user }` |
| POST | `/auth/register` | anyone | creates a Makatizen (+ volunteer record if `wants_to_volunteer`) |
| GET | `/auth/me` | logged in | current user |
| GET | `/events` | anyone | `type, from, to, location, volunteerOnly, hoursEligibleOnly, includeInactive (admin)` |
| GET | `/events/:id` | anyone | includes `volunteer_roles`, counts, `volunteer_slots_left` |
| POST / PUT / DELETE | `/events`, `/events/:id` | admin | |
| POST | `/events/:id/register` | logged in | `{ role_at_event: volunteer \| participant }`; no duplicates, respects `max_attendees` |
| GET | `/events/registrations/me` | logged in | |
| GET | `/volunteers/opportunities` | anyone | `hoursEligibleOnly` |
| POST | `/volunteers/roles/:roleId/signup` | logged in | takes one slot atomically |
| GET | `/volunteers/assignments/me`, `/volunteers/me/summary` | logged in | |
| GET | `/volunteers` | admin | |
| GET | `/pets`, `/pets/:id` | anyone | `species, size, age (under1 \| 1to5 \| over5), status`; includes `medical` |
| POST / PUT | `/pets`, `/pets/:id` | admin | optional `medical: { vaccinated, neutered_spayed, notes }` |
| PATCH | `/pets/:id/archive` | admin | hides the pet from public lists |
| POST | `/adoptions` | Makatizen, employee | needs `valid_id_image` (JPG/PNG/WEBP data URL ≤ 5 MB), `id_terms_accepted`, `privacy_consent`, `agreed_to_terms` |
| GET | `/adoptions/me` | Makatizen, employee | own applications |
| GET | `/adoptions`, `/adoptions/:id` | admin | never includes the ID image |
| GET | `/adoptions/:id/id-image` | admin | `{ data_url, file_name, id_type }`, `Cache-Control: no-store` |
| PATCH | `/adoptions/:id/id-verification` | admin | `{ id_verification_status: unverified \| verified \| mismatch }` |
| PATCH | `/adoptions/:id` | admin | `{ status?, admin_notes? }`; **approve requires a verified ID** and marks the pet adopted |
| GET | `/services` | anyone | `type (free \| discounted), petType (dog \| cat)` |
| POST / PUT / DELETE | `/services`, `/services/:id` | admin | |
| GET | `/newsletters`, `/newsletters/:id` | anyone | drafts only for admins (`includeDrafts=true`) |
| POST / PUT / DELETE | `/newsletters`, `/newsletters/:id` | admin | `{ title, summary, body, publish }` |
| GET | `/insurance/policies/me` | employee | |
| POST | `/insurance/policies` | employee | `{ pet_name, species, breed, age_years }` → pending policy |
| GET | `/admin/stats` | admin | dashboard counts |

## Security notes

- Passwords are hashed with bcrypt; the hash is never returned.
- Public sign-up always creates a `makatizen`; admins and employees are
  created in the database (see `seed.js`).
- ID photos are stored in `adoption_applications.valid_id_image` and only
  returned by the admin-only `id-image` endpoint with `no-store`. For
  production, consider moving them to private, encrypted object storage,
  logging who views each ID, and deleting them after the retention period in
  the privacy notice (Data Privacy Act of 2012).
- `helmet` sets security headers; CORS allows only `CORS_ORIGIN`.
