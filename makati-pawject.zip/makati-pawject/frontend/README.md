# The Makati Pawject – Frontend (React + Vite + Tailwind CSS)

Makati LGU x Manulife pet initiative: adoption, events, volunteering, animal
services, newsletters and pet insurance for Manulife employees.

Uses React 19, React Router 7, Vite 8 (with @vitejs/plugin-react 6) and
Tailwind CSS 4. Data comes from The Makati Pawject JSON API in `../backend`.

## Run it

Start the backend first (see `../backend/README.md`), then:

```bash
cd frontend
npm install
cp .env.example .env    # optional: only if the API isn't at http://localhost:5000/api
npm run dev             # http://localhost:5173
```

If the backend isn't running, the app shows a "We can't reach the server"
screen with a Try again button.

Demo logins (seeded by the backend, also shown on the login page):

| Role | Email | Password |
| --- | --- | --- |
| Admin (Makati Gov) | admin@makati.gov.ph | admin123 |
| Manulife employee | ana.reyes@manulife.com | employee123 |
| Makatizen | juan@example.com | makatizen123 |

## Tests (Jest + React Testing Library)

```bash
npm test                 # run all tests
npm run test:coverage    # with a coverage report
```

Tests live in `tests/`:

- `tests/utils/`: date and text helpers, safe storage
- `tests/api/http.test.js`: the fetch wrapper (token, query params, errors, 401 handling)
- `tests/data/store.test.js`: loading, login/logout, selectors and actions (API mocked)
- `tests/components/`: buttons and form fields, pet/event/service cards, login form,
  ID upload consent gate, adoption form validation and submission, navbar logout

Jest uses Babel (`babel.config.cjs`) only for tests; Vite doesn't need it.
`src/env.js` (the only file that reads `import.meta.env`) is swapped for
`tests/envStub.js` in tests.

## How data flows

```
component → data/store.js action → api/*.api.js → api/http.js (fetch) → Express API
                 ↑                                                          │
                 └──────────── refresh() reloads the changed data ──────────┘
```

- `src/api/`: one file per resource, matching the backend routes
- `src/data/store.js`: caches server data. Read it with `useStore()` and the
  `select*()` helpers; change it with actions like `createEvent()`
- The logged-in user's token is kept in localStorage via `utils/safeStorage.js`,
  which never crashes if the browser blocks storage

## Styling

Tailwind CSS v4 via `@tailwindcss/vite`. Brand tokens are in
`src/assets/styles/main.css` under `@theme`:

| Class | Color | Use |
| --- | --- | --- |
| `bg-brand` / `text-brand` | #008657 | Buttons, headers |
| `brand-dark` | #00663f | Hover, text on light green |
| `brand-bright` | #00a86b | Decoration, focus ring |
| `brand-tint` | #e6fff3 | Soft backgrounds |
| `text-muted` | black 66% | Secondary text |
| `border-line` | black 12% | Dividers |

Only white, black and green are used. The app name, The Makati Pawject, lives in
`APP_NAME` in `src/config.js`.

## Folder structure

```
frontend/
├── index.html                  # Vite needs this at the root (not in public/)
├── public/favicon.svg
├── src/
│   ├── assets/styles/          # main.css (Tailwind + theme), components.css
│   ├── components/
│   │   ├── common/             # Navbar, Footer, Button, Card, FormField, PageHeader,
│   │   │                       # Modal, DataTable, Feedback, Icons, Illustrations,
│   │   │                       # ErrorBoundary, ServerStatus
│   │   ├── auth/               # LoginForm, RegisterForm
│   │   ├── dashboard/          # AdminDashboard, EmployeeDashboard, MakatizenDashboard
│   │   ├── events/             # EventsList (+EventCard), EventDetail
│   │   ├── volunteers/         # VolunteerOpportunities
│   │   ├── services/           # ServicesList (+ServiceCard)
│   │   ├── pets/               # PetsList (+PetCard), PetDetail
│   │   ├── adoptions/          # AdoptionForm, IdUpload, IdPrivacyNotice (RA 10173)
│   │   ├── newsletters/        # NewsletterList, NewsletterDetail
│   │   ├── insurance/          # PetInsurancePage
│   │   └── admin/              # CrudManager, ManageEvents, ManagePets, ReviewApplications,
│   │                           # IdVerification, ManageServices, ManageNewsletters
│   ├── pages/                  # route-level pages
│   ├── api/                    # http.js + auth, events, pets, adoptions, services,
│   │                           # volunteers, newsletters, insurance, admin (.api.js)
│   ├── data/store.js           # API data cache
│   ├── hooks/                  # useAuth, useUserRole, useFetch
│   ├── router/AppRouter.jsx    # routes + role guards
│   ├── context/AuthContext.jsx
│   ├── utils/                  # format.js, cx.js, safeStorage.js
│   ├── config.js, env.js
│   ├── App.jsx
│   └── index.jsx
├── tests/                      # Jest tests
├── jest.config.cjs, babel.config.cjs
└── package.json
```

## Valid ID upload and Data Privacy Act consent

1. The applicant reads a short summary and can open the full Terms and
   Conditions and Privacy Notice (Data Privacy Act of 2012, RA 10173).
2. The upload box stays locked until both consent boxes are checked.
3. They choose the ID type and upload a JPG, PNG or WEBP photo (up to 5 MB).
4. Admins view the ID in Review Applications (fetched from an admin-only
   endpoint) and mark it verified or not matching. The server refuses to
   approve until the ID is verified.

The notice text in `src/components/adoptions/IdPrivacyNotice.jsx` is a
template: have the Makati LGU Data Protection Officer or legal team review it
and fill in every `[bracketed]` value.

## Troubleshooting

- **Odd React errors after updating** (e.g. "destroy is not a function"):
  delete `node_modules` and `package-lock.json`, then `npm install`.
- **Blank page**: the app now shows an error screen instead. If you still see
  white, open DevTools (F12) → Console and share the red error.
- **"We can't reach the server"**: start the backend, and check `VITE_API_URL`.
