// The only file that reads Vite's import.meta.env (Jest swaps it for a stub).
export const API_URL = (import.meta.env.VITE_API_URL || 'http://localhost:5000/api').replace(/\/$/, '');
export const IS_DEV = Boolean(import.meta.env.DEV);
