// fetch wrapper for the Express JSON API (baseURL from VITE_API_URL)
import { API_URL, TOKEN_KEY } from '../config';
import safeStorage from '../utils/safeStorage';

export const getToken = () => safeStorage.get(TOKEN_KEY);
export const setToken = (token) => (token ? safeStorage.set(TOKEN_KEY, token) : safeStorage.remove(TOKEN_KEY));

// Called when the server says the session is no longer valid
let onUnauthorized = () => {};
export const setUnauthorizedHandler = (fn) => {
  onUnauthorized = fn;
};

export class ApiError extends Error {
  constructor(message, status, fields) {
    super(message);
    this.status = status;
    this.fields = fields;
  }
}

function buildUrl(path, params) {
  const url = new URL(`${API_URL}${path}`);
  Object.entries(params || {}).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '' && value !== false) url.searchParams.set(key, String(value));
  });
  return url.toString();
}

export async function request(method, path, { body, params } = {}) {
  const headers = { Accept: 'application/json' };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body !== undefined) headers['Content-Type'] = 'application/json';

  let res;
  try {
    res = await fetch(buildUrl(path, params), {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new ApiError(`Can't reach the server at ${API_URL}. Check that the backend is running.`, 0);
  }

  if (res.status === 204) return null;
  const data = await res.json().catch(() => null);

  if (!res.ok) {
    if (res.status === 401 && token) onUnauthorized();
    const message = data?.error?.message || `Request failed (${res.status}). Try again.`;
    throw new ApiError(message, res.status, data?.error?.fields);
  }
  return data;
}

const http = {
  get: (path, params) => request('GET', path, { params }),
  post: (path, body) => request('POST', path, { body }),
  put: (path, body) => request('PUT', path, { body }),
  patch: (path, body) => request('PATCH', path, { body }),
  delete: (path) => request('DELETE', path),
};

export default http;
