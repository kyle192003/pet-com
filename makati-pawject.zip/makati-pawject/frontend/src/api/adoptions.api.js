import http from './http';

export const submitApplication = (data) => http.post('/adoptions', data);
export const myApplications = () => http.get('/adoptions/me');
export const listApplications = (status) => http.get('/adoptions', { status });
export const getIdImage = (id) => http.get(`/adoptions/${id}/id-image`);
export const setIdVerification = (id, status) => http.patch(`/adoptions/${id}/id-verification`, { id_verification_status: status });
export const updateApplication = (id, data) => http.patch(`/adoptions/${id}`, data);
