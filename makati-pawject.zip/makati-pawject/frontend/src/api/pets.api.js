import http from './http';

// filters: { species, size, age, status, includeArchived }
export const listPets = (filters) => http.get('/pets', filters);
export const getPet = (id) => http.get(`/pets/${id}`);
export const createPet = (data) => http.post('/pets', data);
export const updatePet = (id, data) => http.put(`/pets/${id}`, data);
export const archivePet = (id) => http.patch(`/pets/${id}/archive`);
