import http from './http';

export const listServices = (filters) => http.get('/services', filters);
export const createService = (data) => http.post('/services', data);
export const updateService = (id, data) => http.put(`/services/${id}`, data);
export const deleteService = (id) => http.delete(`/services/${id}`);
