import http from './http';

// filters: { type, from, to, location, volunteerOnly, hoursEligibleOnly, includeInactive }
export const listEvents = (filters) => http.get('/events', filters);
export const getEvent = (id) => http.get(`/events/${id}`);
export const createEvent = (data) => http.post('/events', data);
export const updateEvent = (id, data) => http.put(`/events/${id}`, data);
export const deleteEvent = (id) => http.delete(`/events/${id}`);
export const registerForEvent = (id, roleAtEvent) => http.post(`/events/${id}/register`, { role_at_event: roleAtEvent });
export const myRegistrations = () => http.get('/events/registrations/me');
