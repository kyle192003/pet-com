import http from './http';

export const listNewsletters = (includeDrafts) => http.get('/newsletters', { includeDrafts });
export const getNewsletter = (id) => http.get(`/newsletters/${id}`);
export const createNewsletter = (data) => http.post('/newsletters', data);
export const updateNewsletter = (id, data) => http.put(`/newsletters/${id}`, data);
export const deleteNewsletter = (id) => http.delete(`/newsletters/${id}`);
