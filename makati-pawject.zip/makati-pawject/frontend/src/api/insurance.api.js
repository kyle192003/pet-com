import http from './http';

export const myPolicies = () => http.get('/insurance/policies/me');
export const enrollPet = (data) => http.post('/insurance/policies', data);
