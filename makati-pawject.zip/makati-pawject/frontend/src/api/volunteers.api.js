import http from './http';

export const listOpportunities = (hoursEligibleOnly) => http.get('/volunteers/opportunities', { hoursEligibleOnly });
export const signUpForRole = (roleId) => http.post(`/volunteers/roles/${roleId}/signup`);
export const myAssignments = () => http.get('/volunteers/assignments/me');
export const mySummary = () => http.get('/volunteers/me/summary');
export const listVolunteers = () => http.get('/volunteers');
