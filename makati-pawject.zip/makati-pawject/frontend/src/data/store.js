// Client-side cache of data from The Makati Pawject API.
//
// Read:   const state = useStore();  then  useMemo(() => selectPets(state, filters), [state, ...])
// Write:  await an action, e.g. await createEvent(values). Actions call the API,
//         then refresh the affected data. They throw an Error with the server's
//         message when something isn't allowed; components show it.
import { useSyncExternalStore } from 'react';
import * as authApi from '../api/auth.api';
import * as eventsApi from '../api/events.api';
import * as volunteersApi from '../api/volunteers.api';
import * as petsApi from '../api/pets.api';
import * as adoptionsApi from '../api/adoptions.api';
import * as servicesApi from '../api/services.api';
import * as newslettersApi from '../api/newsletters.api';
import * as insuranceApi from '../api/insurance.api';
import * as adminApi from '../api/admin.api';
import { getToken, setToken, setUnauthorizedHandler } from '../api/http';

const EMPTY_SUMMARY = { total_hours: 0, completed: 0, upcoming: 0, goal_hours: 40 };

const PRIVATE = {
  applications: [],
  myRegistrations: [],
  myAssignments: [],
  volunteerSummary: EMPTY_SUMMARY,
  myPolicies: [],
  adminStats: null,
};

const initialState = () => ({
  status: 'idle', // idle | loading | ready | error
  loaded: false, // true after the first successful load
  error: null,
  user: null,
  events: [],
  pets: [],
  services: [],
  newsletters: [],
  ...PRIVATE,
});

let state = initialState();
const listeners = new Set();

const subscribe = (listener) => {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
};

export const getState = () => state;

function update(patch) {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
}

export function useStore() {
  return useSyncExternalStore(subscribe, getState, getState);
}

// For tests
export function resetStore() {
  state = initialState();
  listeners.forEach((l) => l());
}

// ============================================================
// Loading from the API
// ============================================================
const role = () => state.user?.role;

// Each key knows how to fetch its slice for the current user
const LOADERS = {
  events: () => eventsApi.listEvents({ includeInactive: role() === 'admin' }),
  pets: () => petsApi.listPets({ includeArchived: role() === 'admin' }),
  services: () => servicesApi.listServices(),
  newsletters: () => newslettersApi.listNewsletters(role() === 'admin'),
  applications: () => (role() === 'admin' ? adoptionsApi.listApplications() : []),
  adminStats: () => (role() === 'admin' ? adminApi.getStats() : null),
  myRegistrations: () => (state.user ? eventsApi.myRegistrations() : []),
  myAssignments: () => (state.user ? volunteersApi.myAssignments() : []),
  volunteerSummary: () => (state.user && role() !== 'admin' ? volunteersApi.mySummary() : EMPTY_SUMMARY),
  myPolicies: () => (role() === 'employee' ? insuranceApi.myPolicies() : []),
};

export async function refresh(keys = Object.keys(LOADERS)) {
  const results = await Promise.all(keys.map((k) => LOADERS[k]()));
  const patch = {};
  keys.forEach((k, i) => {
    patch[k] = results[i];
  });
  update(patch);
}

export async function loadAll() {
  update({ status: 'loading', error: null });
  try {
    await refresh();
    update({ status: 'ready', loaded: true });
  } catch (err) {
    update({ status: 'error', error: err });
  }
}

// Called once on startup: restores the session from the saved token
export async function bootstrap() {
  if (getToken()) {
    try {
      update({ user: await authApi.getMe() });
    } catch (err) {
      if (err.status === 401 || err.status === 404) setToken(null);
      else {
        update({ status: 'error', error: err });
        return;
      }
    }
  }
  await loadAll();
}

// If the server rejects our token mid-session, log out locally
setUnauthorizedHandler(() => {
  setToken(null);
  update({ user: null, ...PRIVATE });
});

// ============================================================
// Auth
// ============================================================
export const DEMO_ACCOUNTS = [
  { label: 'Admin (Makati Gov)', email: 'admin@makati.gov.ph', password: 'admin123' },
  { label: 'Manulife employee', email: 'ana.reyes@manulife.com', password: 'employee123' },
  { label: 'Makatizen', email: 'juan@example.com', password: 'makatizen123' },
];

export const currentUser = (s = state) => s.user;

async function startSession({ token, user }) {
  setToken(token);
  update({ user });
  await loadAll();
  return user;
}

export async function login(email, password) {
  return startSession(await authApi.login(email, password));
}

export async function register(data) {
  return startSession(await authApi.register(data));
}

export async function logout() {
  setToken(null);
  update({ user: null, ...PRIVATE });
  await loadAll();
}

// ============================================================
// Selectors (pure: filter what's already in the cache)
// ============================================================
export function selectEvents(s, f = {}) {
  let list = s.events.filter((e) => f.includeInactive || e.is_active);
  if (f.type) list = list.filter((e) => e.event_type === f.type);
  if (f.from) list = list.filter((e) => e.date >= f.from);
  if (f.to) list = list.filter((e) => e.date <= f.to);
  if (f.location) list = list.filter((e) => e.location === f.location);
  if (f.volunteerOnly) list = list.filter((e) => e.is_volunteer_event);
  if (f.hoursEligibleOnly) list = list.filter((e) => e.is_hours_eligible);
  return list.slice().sort((a, b) => a.date.localeCompare(b.date));
}

export const selectEvent = (s, id) => s.events.find((e) => e.id === Number(id)) || null;
export const selectMyRegistrations = (s) => s.myRegistrations;
export const selectMyAssignments = (s) => s.myAssignments;
export const selectVolunteerSummary = (s) => s.volunteerSummary || EMPTY_SUMMARY;

const AGE_GROUPS = {
  under1: (y) => y < 1,
  '1to5': (y) => y >= 1 && y <= 5,
  over5: (y) => y > 5,
};

export function selectPets(s, f = {}) {
  let list = s.pets.filter((p) => f.includeArchived || p.status !== 'archived');
  if (f.species) list = list.filter((p) => p.species === f.species);
  if (f.size) list = list.filter((p) => p.size === f.size);
  if (f.status) list = list.filter((p) => p.status === f.status);
  if (f.age && AGE_GROUPS[f.age]) list = list.filter((p) => AGE_GROUPS[f.age](p.age_years));
  return list;
}

export const selectPet = (s, id) => s.pets.find((p) => p.id === Number(id)) || null;

export function selectApplications(s, status) {
  return status ? s.applications.filter((a) => a.status === status) : s.applications;
}

export function selectServices(s, f = {}) {
  let list = s.services;
  if (f.type) list = list.filter((x) => x.service_type === f.type);
  if (f.petType) list = list.filter((x) => x.pet_type === f.petType || x.pet_type === 'both');
  return list;
}

export function selectNewsletters(s, { includeDrafts = false } = {}) {
  return s.newsletters.filter((n) => includeDrafts || n.published_at);
}

export const selectNewsletter = (s, id) => s.newsletters.find((n) => n.id === Number(id)) || null;
export const selectMyPolicies = (s) => s.myPolicies;

export function selectAdminStats(s) {
  return s.adminStats || { activeEvents: 0, pendingApplications: 0, volunteers: 0, services: 0 };
}

// ============================================================
// Actions
// ============================================================
export async function createEvent(data) {
  const event = await eventsApi.createEvent(data);
  await refresh(['events', 'adminStats']);
  return event;
}

export async function updateEvent(id, data) {
  await eventsApi.updateEvent(id, data);
  await refresh(['events', 'adminStats']);
}

export async function deleteEvent(id) {
  await eventsApi.deleteEvent(id);
  await refresh(['events', 'adminStats']);
}

export async function registerForEvent(eventId, roleAtEvent) {
  await eventsApi.registerForEvent(eventId, roleAtEvent);
  await refresh(['events', 'myRegistrations']);
}

export async function signUpForRole(roleId) {
  const role = await volunteersApi.signUpForRole(roleId);
  await refresh(['events', 'myAssignments', 'volunteerSummary']);
  return role;
}

export async function createPet(data) {
  const pet = await petsApi.createPet(data);
  await refresh(['pets', 'adminStats']);
  return pet;
}

export async function updatePet(id, data) {
  await petsApi.updatePet(id, data);
  await refresh(['pets', 'adminStats']);
}

export async function archivePet(id) {
  await petsApi.archivePet(id);
  await refresh(['pets', 'adminStats']);
}

export async function submitApplication(data) {
  return adoptionsApi.submitApplication(data);
}

export const getIdImage = (applicationId) => adoptionsApi.getIdImage(applicationId);

export async function setIdVerification(id, status) {
  await adoptionsApi.setIdVerification(id, status);
  await refresh(['applications']);
}

// Approving needs a verified ID (checked by the server) and marks the pet adopted
export async function updateApplication(id, data) {
  const app = await adoptionsApi.updateApplication(id, data);
  await refresh(['applications', 'pets', 'adminStats']);
  return app;
}

export async function createService(data) {
  await servicesApi.createService(data);
  await refresh(['services', 'adminStats']);
}

export async function updateService(id, data) {
  await servicesApi.updateService(id, data);
  await refresh(['services']);
}

export async function deleteService(id) {
  await servicesApi.deleteService(id);
  await refresh(['services', 'adminStats']);
}

export async function createNewsletter(data) {
  await newslettersApi.createNewsletter(data);
  await refresh(['newsletters']);
}

export async function updateNewsletter(id, data) {
  await newslettersApi.updateNewsletter(id, data);
  await refresh(['newsletters']);
}

export async function deleteNewsletter(id) {
  await newslettersApi.deleteNewsletter(id);
  await refresh(['newsletters']);
}

export async function enrollPet(data) {
  const policy = await insuranceApi.enrollPet(data);
  await refresh(['myPolicies']);
  return policy;
}
