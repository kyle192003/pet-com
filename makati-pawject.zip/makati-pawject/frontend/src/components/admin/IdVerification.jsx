import { useEffect, useState } from 'react';
import { Tag } from '../common/Card';
import Button from '../common/Button';
import Icon from '../common/Icons';
import Modal from '../common/Modal';
import { ID_TYPES } from '../adoptions/IdUpload';
import { setIdVerification, getIdImage } from '../../data/store';
import { fmtShortDate } from '../../utils/format';

export const ID_STATUS = {
  unverified: { label: 'ID not verified', tone: 'outline' },
  verified: { label: 'ID verified', tone: 'solid' },
  mismatch: { label: "ID doesn't match", tone: 'dark' },
};

const idTypeLabel = (value) => ID_TYPES.find((t) => t.value === value)?.label || 'ID';

// Shows the applicant's uploaded ID so the admin can check it against the application
export default function IdVerification({ application, onMessage }) {
  const [zoom, setZoom] = useState(false);
  const [image, setImage] = useState({ loading: true, dataUrl: null, fileName: '', error: '' });
  const [busy, setBusy] = useState(false);
  const status = application.id_verification_status || 'unverified';
  const locked = application.status !== 'pending';

  // The ID photo is fetched separately and only for admins (GET /adoptions/:id/id-image)
  useEffect(() => {
    let active = true;
    setImage({ loading: true, dataUrl: null, fileName: '', error: '' });
    getIdImage(application.id)
      .then((res) => active && setImage({ loading: false, dataUrl: res.data_url, fileName: res.file_name, error: '' }))
      .catch((err) => active && setImage({ loading: false, dataUrl: null, fileName: '', error: err.message }));
    return () => {
      active = false;
    };
  }, [application.id]);

  const mark = async (value, text) => {
    setBusy(true);
    try {
      await setIdVerification(application.id, value);
      onMessage?.({ tone: 'success', text });
    } catch (err) {
      onMessage?.({ tone: 'error', text: err.message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <section aria-label="ID verification" className="flex flex-col gap-3 rounded-[14px] bg-brand-tint p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="flex items-center gap-2 text-base font-bold">
          <span className="text-brand"><Icon name="idcard" size={20} /></span>
          {idTypeLabel(application.valid_id_type)}
        </h3>
        <Tag tone={ID_STATUS[status].tone}>{ID_STATUS[status].label}</Tag>
      </div>

      {image.loading && <p className="text-sm font-semibold text-muted">Loading ID photo…</p>}
      {image.error && <p className="text-sm font-semibold">{image.error}</p>}
      {!image.loading && image.dataUrl ? (
        <>
          <button
            type="button"
            onClick={() => setZoom(true)}
            className="group relative cursor-zoom-in overflow-hidden rounded-xl border border-black/15 bg-white"
            aria-label="View ID at full size"
          >
            <img src={image.dataUrl} alt={`Uploaded ID of ${application.applicant_name}`} className="max-h-56 w-full object-contain" />
            <span className="absolute right-2 bottom-2 flex items-center gap-1.5 rounded-full bg-black px-3 py-1 text-[13px] font-bold text-white">
              <Icon name="expand" size={14} />
              Full size
            </span>
          </button>
          <p className="text-[13px] leading-snug text-muted">
            Check that the name matches <b className="text-black">{application.applicant_name}</b>, the photo is clear and the ID
            isn't expired. Don't download or share this image.
          </p>
          {application.privacy_consent && (
            <p className="flex items-start gap-2 text-[13px] leading-snug">
              <span className="text-brand"><Icon name="shield" size={16} /></span>
              Consent under the Data Privacy Act of 2012 given {fmtShortDate(application.consent_at)} (terms v{application.terms_version}).
            </p>
          )}

          {!locked && (
            <div className="flex flex-wrap gap-2">
              {status !== 'verified' && (
                <Button size="sm" disabled={busy} onClick={() => mark('verified', "ID verified. You can now approve this application.")}>
                  <Icon name="check" size={16} />
                  Mark ID as verified
                </Button>
              )}
              {status !== 'mismatch' && (
                <Button size="sm" variant="danger" disabled={busy} onClick={() => mark('mismatch', "ID marked as not matching. Contact the applicant or reject.")}>
                  ID doesn't match
                </Button>
              )}
              {status !== 'unverified' && (
                <Button size="sm" variant="ghost" disabled={busy} onClick={() => mark('unverified', 'ID check reset.')}>
                  Undo
                </Button>
              )}
            </div>
          )}
        </>
      ) : (
        !image.loading &&
        !image.error && (
        <p className="flex items-center gap-2 text-sm font-semibold">
          <Icon name="alert" size={18} />
          No ID uploaded. Ask the applicant to submit one before approving.
        </p>
        )
      )}

      <Modal open={zoom} onClose={() => setZoom(false)} title={`${application.applicant_name}: ${idTypeLabel(application.valid_id_type)}`} width="max-w-240">
        <img src={image.dataUrl} alt={`Uploaded ID of ${application.applicant_name}, full size`} className="w-full rounded-xl object-contain" />
        <p className="text-sm text-muted">File: {image.fileName || application.valid_id_file_name}</p>
      </Modal>
    </section>
  );
}
