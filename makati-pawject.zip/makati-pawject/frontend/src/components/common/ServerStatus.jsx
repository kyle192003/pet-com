import { useStore, bootstrap, loadAll } from '../../data/store';
import { API_URL } from '../../config';
import { Loading, Notice } from './Feedback';
import { Dog } from './Illustrations';

// Gates the app on the first API load, and shows a banner if a later refresh fails
export default function ServerStatus({ children }) {
  const { status, loaded, error } = useStore();

  if (!loaded && status !== 'error') {
    return (
      <main className="mx-auto flex w-full max-w-7xl flex-1 items-center justify-center px-6 py-20">
        <Loading label="Fetching pets and events…" />
      </main>
    );
  }

  if (!loaded && status === 'error') {
    return (
      <main className="mx-auto flex w-full max-w-xl flex-1 flex-col items-center justify-center gap-4 px-6 py-20 text-center">
        <Dog size={120} stroke="#008657" />
        <h1 className="text-3xl font-extrabold tracking-tight">We can't reach the server</h1>
        <p className="text-muted">{error?.message}</p>
        <p className="text-sm text-muted">
          Start the backend (<code className="font-bold">cd backend</code>, then <code className="font-bold">npm run dev</code>) and check
          that it runs at {API_URL}.
        </p>
        <button type="button" onClick={() => bootstrap()}
          className="min-h-11 cursor-pointer rounded-full border-2 border-brand bg-brand px-5 font-bold text-white hover:bg-brand-dark">
          Try again
        </button>
      </main>
    );
  }

  return (
    <>
      {status === 'error' && (
        <div className="mx-auto w-full max-w-7xl px-6 pt-4 md:px-12">
          <Notice tone="error">
            <span className="flex-1">Couldn't refresh data: {error?.message}</span>
            <button type="button" onClick={() => loadAll()} className="cursor-pointer font-bold text-white underline">
              Retry
            </button>
          </Notice>
        </div>
      )}
      {children}
    </>
  );
}
