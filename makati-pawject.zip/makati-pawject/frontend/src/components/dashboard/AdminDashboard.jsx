import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../common/PageHeader';
import PageContainer from '../common/PageContainer';
import Card, { Tag, IconCircle, DateBlock } from '../common/Card';
import Button from '../common/Button';
import Icon from '../common/Icons';
import DataTable, { RowActions } from '../common/DataTable';
import { Notice } from '../common/Feedback';
import useAuth from '../../hooks/useAuth';
import { useStore, selectEvents, selectApplications, selectAdminStats, updateApplication } from '../../data/store';
import { fmtShortDate, monthShort, dayNum } from '../../utils/format';

const greeting = () => {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
};

export default function AdminDashboard() {
  const { user } = useAuth();
  const state = useStore();
  const events = useMemo(() => selectEvents(state), [state]);
  const pending = useMemo(() => selectApplications(state, 'pending'), [state]);
  const counts = useMemo(() => selectAdminStats(state), [state]);
  const [message, setMessage] = useState(null);

  const decide = async (app, status) => {
    try {
      await updateApplication(app.id, { status });
      setMessage({ tone: 'success', text: `${app.applicant_name}'s application for ${app.pet_name} was ${status}.` });
    } catch (err) {
      setMessage({ tone: 'error', text: err.message });
    }
  };

  const pendingCount = pending.length;
  const name = user?.full_name || 'Admin';

  const stats = [
    { icon: 'calendar', value: counts.activeEvents, label: 'Active events' },
    { icon: 'heart', value: counts.pendingApplications, label: 'Pending adoption applications' },
    { icon: 'users', value: counts.volunteers, label: 'Registered volunteers' },
    { icon: 'stethoscope', value: counts.services, label: 'Animal services offered' },
  ];

  const columns = [
    { key: 'pet_name', label: 'Pet', render: (a) => <b>{a.pet_name}</b> },
    { key: 'applicant_name', label: 'Applicant' },
    { key: 'created_at', label: 'Submitted', render: (a) => <span className="text-muted">{fmtShortDate(a.created_at)}</span> },
    {
      key: 'id_check',
      label: 'ID check',
      render: (a) => (
        <Tag tone={a.id_verification_status === 'verified' ? 'solid' : a.id_verification_status === 'mismatch' ? 'dark' : 'outline'}>
          {a.id_verification_status === 'verified' ? 'Verified' : a.id_verification_status === 'mismatch' ? "Doesn't match" : 'Not verified'}
        </Tag>
      ),
    },
    {
      key: 'actions',
      label: 'Actions',
      align: 'right',
      render: (a) => (
        <RowActions>
          {a.id_verification_status === 'verified' ? (
            <>
              <Button size="sm" variant="ghost" to={`/admin/applications?id=${a.id}`}>View</Button>
              <Button size="sm" onClick={() => decide(a, 'approved')}>Approve</Button>
            </>
          ) : (
            <Button size="sm" to={`/admin/applications?id=${a.id}`}>
              <Icon name="idcard" size={16} />
              Verify ID
            </Button>
          )}
        </RowActions>
      ),
    },
  ];

  return (
    <>
      <PageHeader
        title={`${greeting()}, ${name}`}
        subtitle={
          pendingCount
            ? `${pendingCount} pet${pendingCount === 1 ? ' is' : 's are'} waiting on an adoption decision today.`
            : 'No adoption applications are waiting. Nice work.'
        }
        actions={
          <>
            <Button variant="light" to="/admin/events?new=1">
              <Icon name="plus" size={16} />
              Create new event
            </Button>
            <Button variant="onband" to="/admin/newsletters?new=1">
              Publish newsletter
            </Button>
          </>
        }
      />
      <PageContainer>
        <>
              <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
                {stats.map((s) => (
                  <Card key={s.label} className="flex items-center gap-4.5 px-6 py-5.5">
                    <IconCircle size="lg">
                      <Icon name={s.icon} size={26} />
                    </IconCircle>
                    <div>
                      <b className="mb-1.5 block text-[40px] leading-none font-extrabold tracking-tight">{s.value}</b>
                      <span className="text-[15px] font-semibold">{s.label}</span>
                    </div>
                  </Card>
                ))}
              </div>

              {message && <Notice tone={message.tone}>{message.text}</Notice>}

              <div className="grid items-start gap-6 xl:grid-cols-[2fr_1fr]">
                <Card as="section" className="flex flex-col gap-4 p-6">
                  <div className="flex items-end justify-between gap-4">
                    <h2 className="text-[22px] font-extrabold">Adoption applications to review</h2>
                    <Link to="/admin/applications" className="text-[15px] font-bold">See all</Link>
                  </div>
                  <DataTable columns={columns} rows={pending.slice(0, 5)} empty="No applications waiting for review." />
                </Card>

                <Card as="section" className="flex flex-col gap-2 p-6">
                  <div className="flex items-end justify-between gap-4">
                    <h2 className="text-[22px] font-extrabold">Upcoming events</h2>
                    <Link to="/admin/events" className="text-[15px] font-bold">Manage</Link>
                  </div>
                  <ul>
                    {events.slice(0, 4).map((e) => (
                      <li key={e.id} className="flex items-center gap-3.5 border-b border-line py-3 last:border-b-0">
                        <DateBlock small month={monthShort(e.date)} day={dayNum(e.date)} />
                        <div className="flex flex-col gap-0.5">
                          <Link to={`/events/${e.id}`} className="font-bold text-black no-underline hover:text-brand">{e.title}</Link>
                          <span className="text-sm text-muted">{e.location}</span>
                        </div>
                      </li>
                    ))}
                  </ul>
                </Card>
              </div>
        </>
      </PageContainer>
    </>
  );
}
