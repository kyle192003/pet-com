export { API_URL, IS_DEV } from './env';

// App-wide settings. Change APP_NAME here to rename the app everywhere.
export const APP_NAME = 'The Makati Pawject';
export const APP_PARTNERS = 'Makati LGU x Manulife';

export const TOKEN_KEY = 'manupets_token';

export const ROLES = {
  ADMIN: 'admin',
  EMPLOYEE: 'employee',
  MAKATIZEN: 'makatizen',
};
