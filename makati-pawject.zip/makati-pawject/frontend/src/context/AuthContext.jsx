import { createContext, useEffect, useMemo } from 'react';
import { useStore, bootstrap, login as storeLogin, register as storeRegister, logout as storeLogout } from '../data/store';

export const AuthContext = createContext(null);

const login = ({ email, password }) => storeLogin(email, password);
const register = (data) => storeRegister(data);
const logout = () => storeLogout();

export function AuthProvider({ children }) {
  const state = useStore();

  // Restore the session (if a token is saved) and load data from the API
  useEffect(() => {
    bootstrap();
  }, []);

  const value = useMemo(
    () => ({ user: state.user, isLoggedIn: Boolean(state.user), status: state.status, login, register, logout }),
    [state.user, state.status],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
