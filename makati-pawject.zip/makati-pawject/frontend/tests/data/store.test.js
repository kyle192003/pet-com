import * as store from '../../src/data/store';
import * as authApi from '../../src/api/auth.api';
import * as eventsApi from '../../src/api/events.api';
import * as petsApi from '../../src/api/pets.api';
import * as servicesApi from '../../src/api/services.api';
import * as newslettersApi from '../../src/api/newsletters.api';
import * as adoptionsApi from '../../src/api/adoptions.api';
import * as adminApi from '../../src/api/admin.api';
import * as volunteersApi from '../../src/api/volunteers.api';
import * as insuranceApi from '../../src/api/insurance.api';
import { getToken } from '../../src/api/http';

jest.mock('../../src/api/auth.api');
jest.mock('../../src/api/events.api');
jest.mock('../../src/api/pets.api');
jest.mock('../../src/api/services.api');
jest.mock('../../src/api/newsletters.api');
jest.mock('../../src/api/adoptions.api');
jest.mock('../../src/api/admin.api');
jest.mock('../../src/api/volunteers.api');
jest.mock('../../src/api/insurance.api');

const EVENTS = [
  { id: 1, title: 'Fun Run', event_type: 'fun_run', date: '2026-10-17', location: 'Ayala', is_active: true, is_volunteer_event: true, is_hours_eligible: true },
  { id: 2, title: 'Adoption Day', event_type: 'adoption_day', date: '2026-10-25', location: 'Park', is_active: true, is_volunteer_event: false, is_hours_eligible: false },
  { id: 3, title: 'Old Workshop', event_type: 'recreational', date: '2026-09-01', location: 'Hall', is_active: false, is_volunteer_event: false, is_hours_eligible: false },
];
const PETS = [
  { id: 1, name: 'Mango', species: 'dog', size: 'medium', age_years: 2, status: 'available' },
  { id: 2, name: 'Ube', species: 'cat', size: 'small', age_years: 0.7, status: 'available' },
  { id: 3, name: 'Gone', species: 'dog', size: 'large', age_years: 9, status: 'archived' },
];

beforeEach(() => {
  store.resetStore();
  jest.clearAllMocks();
  eventsApi.listEvents.mockResolvedValue(EVENTS);
  eventsApi.myRegistrations.mockResolvedValue([]);
  petsApi.listPets.mockResolvedValue(PETS);
  servicesApi.listServices.mockResolvedValue([{ id: 1, service_type: 'free', pet_type: 'dog' }, { id: 2, service_type: 'discounted', pet_type: 'both' }]);
  newslettersApi.listNewsletters.mockResolvedValue([{ id: 1, published_at: '2026-10-01T00:00:00Z' }, { id: 2, published_at: null }]);
  adoptionsApi.listApplications.mockResolvedValue([{ id: 7, status: 'pending' }, { id: 8, status: 'approved' }]);
  adminApi.getStats.mockResolvedValue({ activeEvents: 2, pendingApplications: 1, volunteers: 5, services: 2 });
  volunteersApi.myAssignments.mockResolvedValue([]);
  volunteersApi.mySummary.mockResolvedValue({ total_hours: 18.5, completed: 1, upcoming: 0, goal_hours: 40 });
  insuranceApi.myPolicies.mockResolvedValue([{ id: 1, pet_name: 'Mango' }]);
});

describe('loading', () => {
  test('bootstrap without a token loads public data only', async () => {
    await store.bootstrap();
    const s = store.getState();
    expect(s.status).toBe('ready');
    expect(s.loaded).toBe(true);
    expect(s.user).toBeNull();
    expect(s.events).toHaveLength(3);
    expect(eventsApi.listEvents).toHaveBeenCalledWith({ includeInactive: false });
    expect(adoptionsApi.listApplications).not.toHaveBeenCalled();
    expect(insuranceApi.myPolicies).not.toHaveBeenCalled();
  });

  test('a failed load sets an error status', async () => {
    eventsApi.listEvents.mockRejectedValue(new Error("Can't reach the server"));
    await store.loadAll();
    expect(store.getState()).toMatchObject({ status: 'error', loaded: false });
    expect(store.getState().error.message).toMatch(/reach the server/);
  });
});

describe('auth', () => {
  test('admin login saves the token and loads admin data', async () => {
    authApi.login.mockResolvedValue({ token: 'tok', user: { id: 1, role: 'admin', full_name: 'Admin' } });
    await store.login('admin@makati.gov.ph', 'admin123');
    expect(getToken()).toBe('tok');
    expect(eventsApi.listEvents).toHaveBeenLastCalledWith({ includeInactive: true });
    expect(store.getState().applications).toHaveLength(2);
    expect(store.selectAdminStats(store.getState()).volunteers).toBe(5);
  });

  test('employee login loads policies and volunteer summary', async () => {
    authApi.login.mockResolvedValue({ token: 'tok', user: { id: 2, role: 'employee' } });
    await store.login('ana@x.com', 'pw');
    expect(store.selectMyPolicies(store.getState())).toHaveLength(1);
    expect(store.selectVolunteerSummary(store.getState()).total_hours).toBe(18.5);
  });

  test('bootstrap restores a saved session', async () => {
    window.localStorage.setItem('manupets_token', 'saved');
    authApi.getMe.mockResolvedValue({ id: 3, role: 'makatizen' });
    await store.bootstrap();
    expect(store.getState().user.role).toBe('makatizen');
  });

  test('bootstrap drops an expired token', async () => {
    window.localStorage.setItem('manupets_token', 'old');
    authApi.getMe.mockRejectedValue(Object.assign(new Error('expired'), { status: 401 }));
    await store.bootstrap();
    expect(getToken()).toBeNull();
    expect(store.getState().status).toBe('ready');
  });

  test('logout clears the user and private data', async () => {
    authApi.login.mockResolvedValue({ token: 'tok', user: { id: 1, role: 'admin' } });
    await store.login('a', 'b');
    await store.logout();
    expect(getToken()).toBeNull();
    expect(store.getState().user).toBeNull();
    expect(store.getState().applications).toEqual([]);
  });
});

describe('selectors', () => {
  beforeEach(() => store.loadAll());

  test('selectEvents hides inactive events and applies filters', () => {
    const s = store.getState();
    expect(store.selectEvents(s).map((e) => e.id)).toEqual([1, 2]);
    expect(store.selectEvents(s, { includeInactive: true }).map((e) => e.id)).toEqual([3, 1, 2]);
    expect(store.selectEvents(s, { type: 'adoption_day' }).map((e) => e.id)).toEqual([2]);
    expect(store.selectEvents(s, { from: '2026-10-20' }).map((e) => e.id)).toEqual([2]);
    expect(store.selectEvents(s, { hoursEligibleOnly: true }).map((e) => e.id)).toEqual([1]);
  });

  test('selectPets hides archived pets and filters by age group', () => {
    const s = store.getState();
    expect(store.selectPets(s).map((p) => p.name)).toEqual(['Mango', 'Ube']);
    expect(store.selectPets(s, { age: 'under1' }).map((p) => p.name)).toEqual(['Ube']);
    expect(store.selectPets(s, { includeArchived: true })).toHaveLength(3);
    expect(store.selectPet(s, '2').name).toBe('Ube');
    expect(store.selectPet(s, 99)).toBeNull();
  });

  test('services for cats include "both"', () => {
    expect(store.selectServices(store.getState(), { petType: 'cat' }).map((x) => x.id)).toEqual([2]);
  });

  test('newsletters hide drafts unless asked', () => {
    const s = store.getState();
    expect(store.selectNewsletters(s)).toHaveLength(1);
    expect(store.selectNewsletters(s, { includeDrafts: true })).toHaveLength(2);
  });
});

describe('actions refresh the affected data', () => {
  test('createEvent calls the API then reloads events', async () => {
    eventsApi.createEvent.mockResolvedValue({ id: 9 });
    eventsApi.listEvents.mockResolvedValue([...EVENTS, { id: 9, title: 'New', date: '2026-12-01', is_active: true }]);
    await store.createEvent({ title: 'New' });
    expect(eventsApi.createEvent).toHaveBeenCalledWith({ title: 'New' });
    expect(store.getState().events).toHaveLength(4);
  });

  test('server errors reach the caller', async () => {
    adoptionsApi.updateApplication.mockRejectedValue(new Error("Verify the applicant's ID before approving."));
    await expect(store.updateApplication(7, { status: 'approved' })).rejects.toThrow(/Verify the applicant's ID/);
  });

  test('approving refreshes applications, pets and stats', async () => {
    adoptionsApi.updateApplication.mockResolvedValue({ id: 7, status: 'approved' });
    await store.updateApplication(7, { status: 'approved' });
    expect(adoptionsApi.updateApplication).toHaveBeenCalledWith(7, { status: 'approved' });
    expect(petsApi.listPets).toHaveBeenCalled();
  });
});
