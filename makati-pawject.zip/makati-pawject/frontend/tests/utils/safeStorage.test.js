import safeStorage from '../../src/utils/safeStorage';

test('reads and writes localStorage', () => {
  safeStorage.set('k', 1);
  expect(safeStorage.get('k')).toBe('1');
  safeStorage.remove('k');
  expect(safeStorage.get('k')).toBeNull();
});

test('never throws when storage is blocked', () => {
  const spy = jest.spyOn(Storage.prototype, 'getItem').mockImplementation(() => {
    throw new DOMException('blocked', 'SecurityError');
  });
  jest.spyOn(Storage.prototype, 'setItem').mockImplementation(() => {
    throw new DOMException('blocked', 'SecurityError');
  });
  expect(safeStorage.get('k')).toBeNull();
  expect(() => safeStorage.set('k', 'v')).not.toThrow();
  spy.mockRestore();
  jest.restoreAllMocks();
});
