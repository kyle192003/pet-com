import { fmtTime, timeRange, ageLabel, cap, initials, monthShort, dayNum, fmtShortDate } from '../../src/utils/format';
import cx from '../../src/utils/cx';

describe('format helpers', () => {
  test('fmtTime converts 24h to 12h', () => {
    expect(fmtTime('05:30')).toBe('5:30 AM');
    expect(fmtTime('13:00')).toBe('1:00 PM');
    expect(fmtTime('00:15')).toBe('12:15 AM');
    expect(fmtTime('12:00')).toBe('12:00 PM');
    expect(fmtTime('')).toBe('');
  });

  test('timeRange joins two times', () => {
    expect(timeRange('08:00', '12:00')).toBe('8:00 AM – 12:00 PM');
  });

  test('ageLabel shows months under a year', () => {
    expect(ageLabel(0.7)).toBe('8 mos');
    expect(ageLabel(1)).toBe('1 yr');
    expect(ageLabel(4)).toBe('4 yrs');
  });

  test('cap, initials and dates', () => {
    expect(cap('available')).toBe('Available');
    expect(initials('Juan Dela Cruz')).toBe('JD');
    expect(monthShort('2026-10-17')).toBe('OCT');
    expect(dayNum('2026-10-17')).toBe(17);
    expect(fmtShortDate('2026-10-17')).toBe('Oct 17, 2026');
  });

  test('cx skips falsy values', () => {
    expect(cx('a', false && 'b', null, 'c')).toBe('a c');
  });
});
