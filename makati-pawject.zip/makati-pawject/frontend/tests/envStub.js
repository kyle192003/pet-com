export const API_URL = 'http://api.test/api';
export const IS_DEV = true;
