import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { useState } from 'react';
import IdUpload from '../../src/components/adoptions/IdUpload';
import { renderWithRouter } from '../testUtils';

function Harness({ onValue = () => {} }) {
  const [value, setValue] = useState({ idType: '', file: null, agreedTerms: false, privacyConsent: false });
  return (
    <IdUpload
      value={value}
      onChange={(v) => {
        setValue(v);
        onValue(v);
      }}
    />
  );
}

const fileInput = () => document.querySelector('input[type="file"]');
const png = (size = 10) => new File([new Uint8Array(size)], 'my-id.png', { type: 'image/png' });

test('upload stays locked until both consents are checked', async () => {
  renderWithRouter(<Harness />);
  expect(screen.getByText('Upload locked')).toBeInTheDocument();
  expect(fileInput()).toBeDisabled();

  await userEvent.click(screen.getByLabelText(/agree to the Terms and Conditions/));
  expect(fileInput()).toBeDisabled();

  await userEvent.click(screen.getByLabelText(/Data Privacy Act of 2012/));
  expect(fileInput()).toBeEnabled();
  expect(screen.getByText('Upload a photo of your valid ID')).toBeInTheDocument();
});

test('"I agree to both" in the full notice checks both boxes', async () => {
  renderWithRouter(<Harness />);
  await userEvent.click(screen.getByRole('button', { name: /Read the full Terms/ }));
  expect(screen.getByRole('dialog')).toHaveTextContent('Republic Act No. 10173');
  await userEvent.click(screen.getByRole('button', { name: 'I agree to both' }));
  expect(screen.getByLabelText(/agree to the Terms and Conditions/)).toBeChecked();
  expect(screen.getByLabelText(/Data Privacy Act of 2012/)).toBeChecked();
});

test('accepts a PNG and shows a preview', async () => {
  const onValue = jest.fn();
  renderWithRouter(<Harness onValue={onValue} />);
  await userEvent.click(screen.getByRole('button', { name: /Read the full Terms/ }));
  await userEvent.click(screen.getByRole('button', { name: 'I agree to both' }));
  await userEvent.upload(fileInput(), png());
  await waitFor(() => expect(screen.getByText('ID uploaded')).toBeInTheDocument());
  expect(screen.getByAltText('Preview of your uploaded ID')).toBeInTheDocument();
  expect(onValue).toHaveBeenLastCalledWith(expect.objectContaining({ file: expect.objectContaining({ name: 'my-id.png' }) }));
});

test('rejects wrong file types and files over 5 MB', async () => {
  renderWithRouter(<Harness />);
  await userEvent.click(screen.getByRole('button', { name: /Read the full Terms/ }));
  await userEvent.click(screen.getByRole('button', { name: 'I agree to both' }));

  await userEvent.upload(fileInput(), new File(['%PDF'], 'id.pdf', { type: 'application/pdf' }), { applyAccept: false });
  expect(screen.getByText('Upload a JPG, PNG or WEBP photo of your ID.')).toBeInTheDocument();

  await userEvent.upload(fileInput(), png(6 * 1024 * 1024));
  expect(screen.getByText(/Upload one under 5 MB/)).toBeInTheDocument();
});
