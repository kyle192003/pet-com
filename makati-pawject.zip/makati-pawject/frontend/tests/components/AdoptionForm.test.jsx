import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import AdoptionForm from '../../src/components/adoptions/AdoptionForm';
import useAuth from '../../src/hooks/useAuth';
import * as store from '../../src/data/store';
import { renderWithRouter } from '../testUtils';

jest.mock('../../src/hooks/useAuth');
jest.mock('../../src/data/store', () => ({ submitApplication: jest.fn() }));

const pet = { id: 8, name: 'Tiger', species: 'cat', breed: 'Puspin', age_years: 6, gender: 'male', photo_url: '' };
const user = { full_name: 'Juan Dela Cruz', email: 'juan@example.com', mobile_number: '0917 123 4567', address: 'Poblacion, Makati' };

beforeEach(() => {
  useAuth.mockReturnValue({ user });
  store.submitApplication.mockReset();
});

test('pre-fills the applicant from the logged-in user', () => {
  renderWithRouter(<AdoptionForm pet={pet} />);
  expect(screen.getByLabelText('Full name')).toHaveValue('Juan Dela Cruz');
  expect(screen.getByLabelText("Pet you're applying for")).toHaveValue('Tiger · Cat · Puspin');
});

test('will not submit without the ID, consent and terms', async () => {
  renderWithRouter(<AdoptionForm pet={pet} />);
  await userEvent.click(screen.getByRole('button', { name: 'Submit application' }));
  expect(screen.getByRole('alert')).toHaveTextContent('Some details are missing');
  expect(screen.getByText(/Upload a photo of your valid ID so we can verify/)).toBeInTheDocument();
  expect(screen.getByText(/Give your consent under the Data Privacy Act/)).toBeInTheDocument();
  expect(store.submitApplication).not.toHaveBeenCalled();
});

test('submits the ID and consent record', async () => {
  store.submitApplication.mockResolvedValue({ id: 1 });
  renderWithRouter(<AdoptionForm pet={pet} />);
  await userEvent.click(screen.getByRole('button', { name: /Read the full Terms/ }));
  await userEvent.click(screen.getByRole('button', { name: 'I agree to both' }));
  await userEvent.selectOptions(screen.getByLabelText('ID type'), 'philsys');
  await userEvent.upload(document.querySelector('input[type="file"]'), new File([new Uint8Array(20)], 'id.png', { type: 'image/png' }));
  await screen.findByText('ID uploaded');
  await userEvent.click(screen.getByLabelText(/adoption terms and conditions/));
  await userEvent.click(screen.getByRole('button', { name: 'Submit application' }));

  await waitFor(() => expect(store.submitApplication).toHaveBeenCalled());
  const payload = store.submitApplication.mock.calls[0][0];
  expect(payload).toMatchObject({
    pet_id: 8,
    valid_id_type: 'philsys',
    valid_id_file_name: 'id.png',
    id_terms_accepted: true,
    privacy_consent: true,
    agreed_to_terms: true,
    terms_version: '2026-09',
  });
  expect(payload.valid_id_image).toMatch(/^data:image\/png;base64,/);
  expect(await screen.findByText('Application sent for Tiger')).toBeInTheDocument();
});
