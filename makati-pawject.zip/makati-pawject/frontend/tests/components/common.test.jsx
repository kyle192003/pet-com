import { screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { useState } from 'react';
import Button from '../../src/components/common/Button';
import { ChipGroup, TextField } from '../../src/components/common/FormField';
import DataTable from '../../src/components/common/DataTable';
import { renderWithRouter } from '../testUtils';

test('Button renders a link when given "to"', () => {
  renderWithRouter(<Button to="/pets">See pets</Button>);
  expect(screen.getByRole('link', { name: 'See pets' })).toHaveAttribute('href', '/pets');
});

test('Button calls onClick and respects disabled', async () => {
  const onClick = jest.fn();
  const { rerender } = renderWithRouter(<Button onClick={onClick}>Save</Button>);
  await userEvent.click(screen.getByRole('button', { name: 'Save' }));
  expect(onClick).toHaveBeenCalledTimes(1);
  rerender(<Button onClick={onClick} disabled>Save</Button>);
  expect(screen.getByRole('button', { name: 'Save' })).toBeDisabled();
});

test('ChipGroup marks the selected option with aria-pressed', async () => {
  function Demo() {
    const [v, setV] = useState('');
    return <ChipGroup label="Species" value={v} onChange={setV} options={[{ value: '', label: 'All' }, { value: 'dog', label: 'Dogs' }]} />;
  }
  renderWithRouter(<Demo />);
  const dogs = screen.getByRole('button', { name: 'Dogs' });
  expect(dogs).toHaveAttribute('aria-pressed', 'false');
  await userEvent.click(dogs);
  expect(dogs).toHaveAttribute('aria-pressed', 'true');
});

test('TextField links its error message for screen readers', () => {
  renderWithRouter(<TextField id="email" label="Email" error="Enter a valid email." value="" onChange={() => {}} />);
  const input = screen.getByLabelText('Email');
  expect(input).toHaveAttribute('aria-invalid', 'true');
  expect(input).toHaveAttribute('aria-describedby', 'email-error');
  expect(screen.getByText('Enter a valid email.')).toBeInTheDocument();
});

test('DataTable shows an empty message', () => {
  renderWithRouter(<DataTable columns={[{ key: 'name', label: 'Name' }]} rows={[]} empty="No pets yet." />);
  expect(screen.getByText('No pets yet.')).toBeInTheDocument();
});
