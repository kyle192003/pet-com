import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Navbar from '../../src/components/common/Navbar';
import useAuth from '../../src/hooks/useAuth';
import useUserRole from '../../src/hooks/useUserRole';
import { renderWithRouter } from '../testUtils';

jest.mock('../../src/hooks/useAuth');
jest.mock('../../src/hooks/useUserRole');

const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({ ...jest.requireActual('react-router-dom'), useNavigate: () => mockNavigate }));

test('shows role-specific links', () => {
  useAuth.mockReturnValue({ user: { full_name: 'Ana Reyes', role: 'employee' }, logout: jest.fn() });
  useUserRole.mockReturnValue({ role: 'employee' });
  renderWithRouter(<Navbar />);
  expect(screen.getByRole('link', { name: 'Pet insurance' })).toBeInTheDocument();
  expect(screen.queryByRole('link', { name: 'Applications' })).not.toBeInTheDocument();
});

test('logging out clears the return-to page for the next user', async () => {
  const logout = jest.fn().mockResolvedValue();
  useAuth.mockReturnValue({ user: { full_name: 'Juan Dela Cruz', role: 'makatizen' }, logout });
  useUserRole.mockReturnValue({ role: 'makatizen' });
  renderWithRouter(<Navbar />);
  await userEvent.click(screen.getByRole('button', { name: 'Log out' }));
  expect(logout).toHaveBeenCalled();
  await waitFor(() => expect(mockNavigate).toHaveBeenCalledWith('/login', { replace: true, state: null }));
});
