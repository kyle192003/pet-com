import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import LoginForm from '../../src/components/auth/LoginForm';
import useAuth from '../../src/hooks/useAuth';
import { renderWithRouter } from '../testUtils';

jest.mock('../../src/hooks/useAuth');

const mockNavigate = jest.fn();
jest.mock('react-router-dom', () => ({ ...jest.requireActual('react-router-dom'), useNavigate: () => mockNavigate }));

beforeEach(() => mockNavigate.mockReset());

test('asks for both fields before calling the API', async () => {
  const login = jest.fn();
  useAuth.mockReturnValue({ login });
  renderWithRouter(<LoginForm />);
  await userEvent.click(screen.getByRole('button', { name: 'Log in' }));
  expect(screen.getByRole('alert')).toHaveTextContent('Enter your email and password.');
  expect(login).not.toHaveBeenCalled();
});

test('logs in and goes to the dashboard', async () => {
  const login = jest.fn().mockResolvedValue({ id: 1 });
  useAuth.mockReturnValue({ login });
  renderWithRouter(<LoginForm />);
  await userEvent.type(screen.getByLabelText('Email'), 'juan@example.com');
  await userEvent.type(screen.getByLabelText('Password'), 'makatizen123');
  await userEvent.click(screen.getByRole('button', { name: 'Log in' }));
  expect(login).toHaveBeenCalledWith({ email: 'juan@example.com', password: 'makatizen123' });
  await waitFor(() => expect(mockNavigate).toHaveBeenCalledWith('/', { replace: true }));
});

test("shows the server's error message", async () => {
  useAuth.mockReturnValue({ login: jest.fn().mockRejectedValue(new Error('Email or password is incorrect.')) });
  renderWithRouter(<LoginForm />);
  await userEvent.type(screen.getByLabelText('Email'), 'juan@example.com');
  await userEvent.type(screen.getByLabelText('Password'), 'wrong');
  await userEvent.click(screen.getByRole('button', { name: 'Log in' }));
  expect(await screen.findByRole('alert')).toHaveTextContent('Email or password is incorrect.');
});

test('demo account buttons fill the form', async () => {
  useAuth.mockReturnValue({ login: jest.fn() });
  renderWithRouter(<LoginForm />);
  await userEvent.click(screen.getByRole('button', { name: /Admin \(Makati Gov\)/ }));
  expect(screen.getByLabelText('Email')).toHaveValue('admin@makati.gov.ph');
});
