import { screen } from '@testing-library/react';
import { PetCard } from '../../src/components/pets/PetsList';
import { EventCard } from '../../src/components/events/EventsList';
import { ServiceCard } from '../../src/components/services/ServicesList';
import { renderWithRouter } from '../testUtils';

const pet = { id: 5, name: 'Mango', species: 'dog', breed: 'Aspin', age_years: 2, gender: 'male', size: 'medium', description: 'Gentle.', status: 'available', photo_url: '' };

test('available pets link to the adoption form', () => {
  renderWithRouter(<PetCard pet={pet} />);
  expect(screen.getByText('Dog · Aspin · 2 yrs · Male')).toBeInTheDocument();
  expect(screen.getByRole('link', { name: /Apply to adopt/ })).toHaveAttribute('href', '/adopt/5');
});

test('reserved pets show View profile instead', () => {
  renderWithRouter(<PetCard pet={{ ...pet, status: 'reserved' }} />);
  expect(screen.queryByRole('link', { name: /Apply to adopt/ })).not.toBeInTheDocument();
  expect(screen.getByRole('link', { name: 'View profile' })).toHaveAttribute('href', '/pets/5');
});

test('EventCard shows date, time and volunteer slots', () => {
  const event = {
    id: 1, title: 'Paws Fun Run 2026', event_type: 'fun_run', date: '2026-10-17', start_time: '05:30', end_time: '09:00',
    location: 'Ayala Triangle Gardens', short_description: 'Run with your dog.', is_volunteer_event: true, volunteer_slots_left: 12,
  };
  renderWithRouter(<EventCard event={event} />);
  expect(screen.getByText('Sat, Oct 17')).toBeInTheDocument();
  expect(screen.getByText('5:30 AM – 9:00 AM')).toBeInTheDocument();
  expect(screen.getByText('12 volunteer slots left')).toBeInTheDocument();
});

test('ServiceCard shows walk-in vs appointment', () => {
  const base = { id: 1, title: 'Free deworming', description: 'Tablets.', service_type: 'free', pet_type: 'both', availability_schedule: 'Saturdays', location: 'Barangay hall' };
  const { rerender } = renderWithRouter(<ServiceCard service={{ ...base, how_to_avail: 'walk_in' }} />);
  expect(screen.getByText('Walk-in, no booking needed')).toBeInTheDocument();
  rerender(<ServiceCard service={{ ...base, how_to_avail: 'appointment' }} />);
  expect(screen.getByRole('button', { name: 'Book an appointment' })).toBeInTheDocument();
});
