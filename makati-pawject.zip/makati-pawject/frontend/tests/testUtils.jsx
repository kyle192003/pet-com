import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';

// Render a component inside a router
export function renderWithRouter(ui, { route = '/' } = {}) {
  return render(<MemoryRouter initialEntries={[route]}>{ui}</MemoryRouter>);
}

// Build a fake fetch Response
export const jsonResponse = (body, status = 200) => ({
  ok: status >= 200 && status < 300,
  status,
  json: async () => body,
});
