import http, { setToken, setUnauthorizedHandler, ApiError } from '../../src/api/http';
import { jsonResponse } from '../testUtils';

beforeEach(() => {
  global.fetch = jest.fn();
});

test('GET builds the URL with query params and skips empty ones', async () => {
  fetch.mockResolvedValue(jsonResponse([{ id: 1 }]));
  const data = await http.get('/events', { type: 'fun_run', from: '', volunteerOnly: false, includeInactive: true });
  expect(data).toEqual([{ id: 1 }]);
  expect(fetch.mock.calls[0][0]).toBe('http://api.test/api/events?type=fun_run&includeInactive=true');
});

test('sends the saved token and a JSON body', async () => {
  setToken('abc');
  fetch.mockResolvedValue(jsonResponse({ ok: true }, 201));
  await http.post('/pets', { name: 'Mango' });
  const [, options] = fetch.mock.calls[0];
  expect(options.method).toBe('POST');
  expect(options.headers.Authorization).toBe('Bearer abc');
  expect(options.headers['Content-Type']).toBe('application/json');
  expect(JSON.parse(options.body)).toEqual({ name: 'Mango' });
});

test("turns the server's error JSON into an ApiError", async () => {
  fetch.mockResolvedValue(jsonResponse({ error: { message: 'Enter a valid email.', fields: { email: 'Enter a valid email.' } } }, 400));
  await expect(http.post('/auth/login', {})).rejects.toMatchObject({
    message: 'Enter a valid email.',
    status: 400,
    fields: { email: 'Enter a valid email.' },
  });
});

test('explains when the server is unreachable', async () => {
  fetch.mockRejectedValue(new TypeError('Failed to fetch'));
  const err = await http.get('/events').catch((e) => e);
  expect(err).toBeInstanceOf(ApiError);
  expect(err.message).toMatch(/Can't reach the server/);
});

test('204 responses return null', async () => {
  fetch.mockResolvedValue({ ok: true, status: 204, json: async () => null });
  expect(await http.delete('/events/1')).toBeNull();
});

test('a 401 with a token triggers the unauthorized handler', async () => {
  const handler = jest.fn();
  setUnauthorizedHandler(handler);
  setToken('expired');
  fetch.mockResolvedValue(jsonResponse({ error: { message: 'Your session has ended.' } }, 401));
  await expect(http.get('/auth/me')).rejects.toThrow('Your session has ended.');
  expect(handler).toHaveBeenCalled();
});
