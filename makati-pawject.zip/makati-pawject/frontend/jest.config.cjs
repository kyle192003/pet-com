module.exports = {
  testEnvironment: 'jsdom',
  setupFiles: ['<rootDir>/tests/polyfills.cjs'],
  setupFilesAfterEnv: ['<rootDir>/tests/setupTests.js'],
  moduleNameMapper: {
    // Vite's import.meta.env isn't available in Jest
    '^(.*)/env$': '<rootDir>/tests/envStub.js',
    '\\.(css)$': '<rootDir>/tests/styleStub.js',
  },
  testMatch: ['<rootDir>/tests/**/*.test.{js,jsx}'],
  collectCoverageFrom: ['src/**/*.{js,jsx}', '!src/index.jsx', '!src/env.js'],
};
