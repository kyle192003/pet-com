# The Makati Pawject (Makati LGU x Manulife)

```
backend/        Express JSON API + PostgreSQL (in-memory by default)  → see backend/README.md
backend/data/   Sample data as JSON files, one per collection (+ db.json with all of them)
frontend/       React + Vite + Tailwind CSS                            → see frontend/README.md
```

`backend/data/` matches the team repo's `backend/data` folder: `adoptions`, `appointments`,
`eventRegistrations`, `events`, `pets`, `petServices`, `users`, `volunteerAssignments`,
`volunteerRoles`, plus new `newsletters` and `petInsurancePolicies`. Every file is an array of
records using the same conventions as the team's `events.json` (snake_case, `created_by`,
`date_created`, `date_updated`, times like `08:00:00+08:00`, `event_type` `R` or `V`).
`db.json` holds all collections in one file (works with json-server: `npx json-server backend/data/db.json`).

Quick start (two terminals):

```bash
cd backend  && npm install && npm run dev    # http://localhost:5000/api
cd frontend && npm install && npm run dev    # http://localhost:5173
```

Tests: `npm test` in each folder (backend 78 tests, frontend 49 tests).

Log in with `admin@makati.gov.ph` / `admin123`, `ana.reyes@manulife.com` /
`employee123` or `juan@example.com` / `makatizen123`.
