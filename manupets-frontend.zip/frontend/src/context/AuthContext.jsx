import { createContext, useCallback, useMemo } from 'react';
import { useStore, currentUser, publicUser, login as storeLogin, register as storeRegister, logout as storeLogout } from '../data/store';

export const AuthContext = createContext(null);

// Frontend-only auth: checks the sample users in src/data/mockData.js
export function AuthProvider({ children }) {
  const state = useStore();
  const user = useMemo(() => publicUser(currentUser(state)), [state]);

  const login = useCallback(async ({ email, password }) => storeLogin(email, password), []);
  const register = useCallback(async (data) => storeRegister(data), []);
  const logout = useCallback(() => storeLogout(), []);

  const value = useMemo(() => ({ user, isLoggedIn: Boolean(user), login, register, logout }), [user, login, register, logout]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
