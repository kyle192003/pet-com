// App-wide settings. Change APP_NAME here to rename the app everywhere.
export const APP_NAME = 'ManuPets';
export const APP_PARTNERS = 'Makati LGU x Manulife';

export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
// Mock mode is ON unless VITE_USE_MOCK=false is set in .env
export const USE_MOCK = (import.meta.env.VITE_USE_MOCK ?? 'true') !== 'false';

export const TOKEN_KEY = 'manupets_token';
export const USER_KEY = 'manupets_user';

export const ROLES = {
  ADMIN: 'admin',
  EMPLOYEE: 'employee',
  MAKATIZEN: 'makatizen',
};
