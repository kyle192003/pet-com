// App-wide settings. Change APP_NAME here to rename the app everywhere.
export const APP_NAME = 'ManuPets';
export const APP_PARTNERS = 'Makati LGU x Manulife';

export const ROLES = {
  ADMIN: 'admin',
  EMPLOYEE: 'employee',
  MAKATIZEN: 'makatizen',
};
