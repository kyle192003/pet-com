import { useEffect } from 'react';
import { BrowserRouter, useLocation } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import AppRouter from './router/AppRouter';
import Navbar from './components/common/Navbar';
import Footer from './components/common/Footer';

// Login has its own full-screen layout; every other page gets the navbar and footer
function Shell() {
  const { pathname } = useLocation();
  const bare = pathname === '/login';

  useEffect(() => window.scrollTo(0, 0), [pathname]);

  return (
    <div className="flex min-h-full flex-col">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:rounded-full focus:bg-black focus:px-4 focus:py-2 focus:text-white">
        Skip to content
      </a>
      {!bare && <Navbar />}
      <div className="flex flex-1 flex-col">
        <AppRouter />
      </div>
      {!bare && <Footer />}
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Shell />
      </AuthProvider>
    </BrowserRouter>
  );
}
