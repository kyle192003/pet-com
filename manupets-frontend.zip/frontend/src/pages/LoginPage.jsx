import { Navigate } from 'react-router-dom';
import LoginForm from '../components/auth/LoginForm';
import { Brand } from '../components/common/Navbar';
import { PawTrail, PetPair } from '../components/common/Illustrations';
import useAuth from '../hooks/useAuth';
import { APP_PARTNERS } from '../config';

export default function LoginPage() {
  const { isLoggedIn } = useAuth();
  if (isLoggedIn) return <Navigate to="/" replace />;

  return (
    <div className="flex min-h-screen flex-col lg:flex-row">
      <section className="relative flex shrink-0 flex-col overflow-hidden rounded-b-[32px] bg-brand px-6 py-8 text-white lg:w-140 lg:rounded-r-[40px] lg:rounded-bl-none lg:p-12">
        <PawTrail spots={[{ left: 300, top: 90, rotate: 30, size: 34 }, { left: 360, top: 150, rotate: 45, size: 34 }, { left: 390, top: 230, rotate: 20, size: 34 }, { left: 450, top: 290, rotate: 40, size: 34 }]} className="hidden lg:block" />
        <div className="relative">
          <Brand light />
        </div>
        <div className="relative mt-8 flex flex-col gap-5 lg:mt-auto">
          <div className="hidden lg:flex">
            <PetPair dogSize={220} catSize={170} />
          </div>
          <h1 className="text-[34px] leading-[1.05] font-extrabold tracking-tight lg:text-[52px]">
            Every dog and cat in Makati deserves a loving home.
          </h1>
          <p className="max-w-105 text-lg leading-normal">
            Join events, volunteer, adopt a pet and, for Manulife employees, enroll your pet in insurance.
          </p>
        </div>
        <div className="relative mt-8 text-[13px] font-semibold lg:mt-14">{APP_PARTNERS}</div>
      </section>
      <main id="main" className="flex flex-1 items-center justify-center px-6 py-12">
        <LoginForm />
      </main>
    </div>
  );
}
