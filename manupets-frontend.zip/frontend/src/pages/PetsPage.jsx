import { useParams } from 'react-router-dom';
import PageHeader from '../components/common/PageHeader';
import PageContainer from '../components/common/PageContainer';
import PetsList from '../components/pets/PetsList';
import PetDetail from '../components/pets/PetDetail';

// /pets and /pets/:id
export default function PetsPage() {
  const { id } = useParams();
  if (id) return <PetDetail petId={id} />;
  return (
    <>
      <PageHeader title="Meet your next best friend" subtitle="Dogs and cats rescued in Makati, vaccinated and ready for a home." />
      <PageContainer>
        <PetsList />
      </PageContainer>
    </>
  );
}
