import { useMemo } from 'react';
import { useParams } from 'react-router-dom';
import PageHeader from '../components/common/PageHeader';
import PageContainer from '../components/common/PageContainer';
import AdoptionForm from '../components/adoptions/AdoptionForm';
import Button from '../components/common/Button';
import { EmptyState } from '../components/common/Feedback';
import { useStore, selectPet } from '../data/store';

// /adopt/:petId
export default function AdoptionPage() {
  const { petId } = useParams();
  const state = useStore();
  const pet = useMemo(() => selectPet(state, petId), [state, petId]);

  if (!pet) {
    return (
      <PageContainer>
        <EmptyState title="This pet is no longer listed" action={<Button to="/pets">See available pets</Button>} />
      </PageContainer>
    );
  }

  return (
    <>
      <PageHeader
        title={pet.status === 'available' ? `Adopt ${pet.name}` : `${pet.name} isn't available`}
        subtitle={
          pet.status === 'available'
            ? "Tell us about you and your home. We'll get back to you within [X] working days."
            : `${pet.name} is ${pet.status}. There are other pets waiting for a home.`
        }
        crumbs={[{ label: 'Pets for adoption', to: '/pets' }, { label: pet.name, to: `/pets/${pet.id}` }, { label: 'Apply' }]}
      />
      <PageContainer>
        {pet.status === 'available' ? <AdoptionForm pet={pet} /> : <Button to="/pets" className="self-start">See available pets</Button>}
      </PageContainer>
    </>
  );
}
