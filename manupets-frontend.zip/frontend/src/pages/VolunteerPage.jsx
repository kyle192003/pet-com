import PageHeader from '../components/common/PageHeader';
import PageContainer from '../components/common/PageContainer';
import VolunteerOpportunities from '../components/volunteers/VolunteerOpportunities';

export default function VolunteerPage() {
  return (
    <>
      <PageHeader title="Lend a hand at the shelter" subtitle="Help at city pet events. Eligible events count toward your Manulife volunteer hours." />
      <PageContainer className="gap-5">
        <VolunteerOpportunities />
      </PageContainer>
    </>
  );
}
