import { Navigate } from 'react-router-dom';
import PageHeader from '../components/common/PageHeader';
import PageContainer from '../components/common/PageContainer';
import RegisterForm from '../components/auth/RegisterForm';
import useAuth from '../hooks/useAuth';

export default function RegisterPage() {
  const { isLoggedIn } = useAuth();
  if (isLoggedIn) return <Navigate to="/" replace />;
  return (
    <>
      <PageHeader title="Join the ManuPets family" subtitle="Create your Makatizen account to adopt, join pet events and book free animal services." />
      <PageContainer className="items-center">
        <RegisterForm />
      </PageContainer>
    </>
  );
}
