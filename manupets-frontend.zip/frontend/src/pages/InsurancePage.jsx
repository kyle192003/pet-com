import PageHeader from '../components/common/PageHeader';
import PageContainer from '../components/common/PageContainer';
import PetInsurancePage from '../components/insurance/PetInsurancePage';
import { Tag } from '../components/common/Card';
import Icon from '../components/common/Icons';

// /insurance (Manulife employees only, guarded in AppRouter)
export default function InsurancePage() {
  return (
    <>
      <PageHeader
        title="Pet insurance for your dog or cat"
        subtitle="A simple plan that helps cover vet bills, available to Manulife employees in Makati."
        tags={
          <Tag tone="onband">
            <Icon name="shield" size={14} />
            Manulife employees only
          </Tag>
        }
      />
      <PageContainer>
        <PetInsurancePage />
      </PageContainer>
    </>
  );
}
