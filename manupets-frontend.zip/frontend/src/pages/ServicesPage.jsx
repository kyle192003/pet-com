import PageHeader from '../components/common/PageHeader';
import PageContainer from '../components/common/PageContainer';
import ServicesList from '../components/services/ServicesList';

export default function ServicesPage() {
  return (
    <>
      <PageHeader title="Care for your dog or cat" subtitle="Free and discounted animal welfare services for Makati residents." />
      <PageContainer>
        <ServicesList />
      </PageContainer>
    </>
  );
}
