import { useParams } from 'react-router-dom';
import PageHeader from '../components/common/PageHeader';
import PageContainer from '../components/common/PageContainer';
import EventsList from '../components/events/EventsList';
import EventDetail from '../components/events/EventDetail';

// /events and /events/:id
export default function EventsPage() {
  const { id } = useParams();
  if (id) return <EventDetail eventId={id} />;
  return (
    <>
      <PageHeader title="Events for pets and their people" subtitle="Fun runs, adoption days and volunteer drives around Makati." />
      <PageContainer>
        <EventsList />
      </PageContainer>
    </>
  );
}
