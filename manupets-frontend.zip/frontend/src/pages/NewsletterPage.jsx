import { useParams } from 'react-router-dom';
import PageHeader from '../components/common/PageHeader';
import PageContainer from '../components/common/PageContainer';
import NewsletterList from '../components/newsletters/NewsletterList';
import NewsletterDetail from '../components/newsletters/NewsletterDetail';

// /newsletters and /newsletters/:id
export default function NewsletterPage() {
  const { id } = useParams();
  if (id) return <NewsletterDetail newsletterId={id} />;
  return (
    <>
      <PageHeader title="News from the shelter" subtitle="Past events and updates from the Makati LGU and Manulife pet programs." />
      <PageContainer>
        <NewsletterList />
      </PageContainer>
    </>
  );
}
