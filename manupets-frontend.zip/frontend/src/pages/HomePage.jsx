import useUserRole from '../hooks/useUserRole';
import AdminDashboard from '../components/dashboard/AdminDashboard';
import EmployeeDashboard from '../components/dashboard/EmployeeDashboard';
import MakatizenDashboard from '../components/dashboard/MakatizenDashboard';

// "/" shows the dashboard for the logged-in role (the router sends guests to /login)
export default function HomePage() {
  const { isAdmin, isEmployee } = useUserRole();
  if (isAdmin) return <AdminDashboard />;
  if (isEmployee) return <EmployeeDashboard />;
  return <MakatizenDashboard />;
}
