import PageContainer from '../components/common/PageContainer';
import Button from '../components/common/Button';
import { Dog } from '../components/common/Illustrations';

export default function NotFoundPage() {
  return (
    <PageContainer className="items-center py-20 text-center">
      <Dog size={140} stroke="#008657" />
      <h1 className="text-4xl font-extrabold tracking-tight">This page ran off somewhere</h1>
      <p className="max-w-110 text-muted">The link may be old or mistyped. Head back home and we'll help you find what you need.</p>
      <Button to="/">Go to home</Button>
    </PageContainer>
  );
}
