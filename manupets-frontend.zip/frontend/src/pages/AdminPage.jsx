import { Navigate, useParams } from 'react-router-dom';
import ManageEvents from '../components/admin/ManageEvents';
import ManagePets from '../components/admin/ManagePets';
import ReviewApplications from '../components/admin/ReviewApplications';
import ManageServices from '../components/admin/ManageServices';
import ManageNewsletters from '../components/admin/ManageNewsletters';

const SECTIONS = {
  events: ManageEvents,
  pets: ManagePets,
  applications: ReviewApplications,
  services: ManageServices,
  newsletters: ManageNewsletters,
};

// /admin/:section (admin only, guarded in AppRouter)
export default function AdminPage() {
  const { section } = useParams();
  const Section = SECTIONS[section];
  if (!Section) return <Navigate to="/" replace />;
  return <Section key={section} />;
}
