import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import PageHeader from '../common/PageHeader';
import PageContainer from '../common/PageContainer';
import Card, { Tag, Meta } from '../common/Card';
import Button from '../common/Button';
import Icon, { EVENT_TYPE_ICON } from '../common/Icons';
import { PetPhoto } from '../common/Illustrations';
import { Loading, ErrorMessage, Notice } from '../common/Feedback';
import useFetch from '../../hooks/useFetch';
import useAuth from '../../hooks/useAuth';
import { getEvent, registerForEvent, getMyRegistrations } from '../../api/events.api';
import { EVENT_TYPES, fmtLongDate, timeRange } from '../../utils/format';

export default function EventDetail({ eventId }) {
  const { isLoggedIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { data: event, loading, error, reload, setData } = useFetch(() => getEvent(eventId), [eventId]);
  const mine = useFetch(() => getMyRegistrations(), [eventId, isLoggedIn]);
  const [message, setMessage] = useState(null);
  const [busy, setBusy] = useState(false);

  if (loading) return <PageContainer><Loading label="Loading event…" /></PageContainer>;
  if (error) return <PageContainer><ErrorMessage error={error} onRetry={reload} /></PageContainer>;

  const myReg = (mine.data || []).find((r) => r.event_id === event.id);

  const register = async (role) => {
    if (!isLoggedIn) {
      navigate('/login', { state: { from: location.pathname } });
      return;
    }
    setBusy(true);
    setMessage(null);
    try {
      const updated = await registerForEvent(event.id, role);
      setData(updated);
      await mine.reload();
      setMessage({ tone: 'success', text: `You're registered as a ${role}. See you on ${fmtLongDate(event.date)}!` });
    } catch (err) {
      setMessage({ tone: 'error', text: err.message });
    } finally {
      setBusy(false);
    }
  };

  const mapUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${event.location}, Makati`)}`;

  return (
    <>
      <PageHeader
        title={event.title}
        crumbs={[{ label: 'Events', to: '/events' }, { label: event.title }]}
        tags={
          <>
            <Tag tone="onband">
              <Icon name={EVENT_TYPE_ICON[event.event_type]} size={14} />
              {EVENT_TYPES[event.event_type]}
            </Tag>
            {event.sponsor && (
              <Tag tone="dark">
                <Icon name="heart" size={14} />
                Sponsored by {event.sponsor}
              </Tag>
            )}
          </>
        }
      />
      <PageContainer>
        <div className="grid items-start gap-10 lg:grid-cols-[1.6fr_1fr]">
          <article className="flex max-w-170 flex-col gap-5.5">
            <PetPhoto height={320} alt={`${event.title} photo`} className="rounded-[22px]" />
            <h2 className="text-[26px] font-extrabold tracking-tight">About this event</h2>
            <p className="whitespace-pre-line text-[17px] leading-relaxed">{event.description}</p>

            {event.volunteer_roles.length > 0 && (
              <section className="flex flex-col gap-1">
                <h3 className="text-[19px] font-bold">Volunteer roles</h3>
                <ul>
                  {event.volunteer_roles.map((r) => (
                    <li key={r.id} className="flex justify-between gap-4 border-b border-line py-3">
                      <span>
                        <b className="font-semibold">{r.role_name}</b>
                        <span className="block text-sm text-muted">{r.description}</span>
                      </span>
                      <span className="shrink-0 text-muted">
                        {r.slots_available > 0 ? `${r.slots_available} slots left` : 'Full'}
                      </span>
                    </li>
                  ))}
                </ul>
              </section>
            )}
          </article>

          <Card as="aside" className="flex flex-col gap-4.5 p-6.5 lg:sticky lg:top-24">
            <div className="flex flex-col gap-3">
              <Meta icon={<Icon name="calendar" />}>{fmtLongDate(event.date)}</Meta>
              <Meta icon={<Icon name="clock" />}>{timeRange(event.start_time, event.end_time)}</Meta>
              <Meta icon={<Icon name="pin" />}>
                {event.location}, Makati ·{' '}
                <a href={mapUrl} target="_blank" rel="noreferrer">
                  Open map
                </a>
              </Meta>
              <Meta icon={<Icon name="users" />}>
                <b>{event.volunteer_count}</b> volunteers and <b>{event.participant_count}</b> participants registered
              </Meta>
            </div>
            <div className="h-px bg-line" />

            {message && <Notice tone={message.tone}>{message.text}</Notice>}

            {myReg ? (
              <Notice>
                <Icon name="check" />
                You're registered as a {myReg.role_at_event}.
              </Notice>
            ) : (
              <>
                {event.is_volunteer_event && (
                  <Button full disabled={busy} onClick={() => register('volunteer')}>
                    Register as volunteer
                  </Button>
                )}
                <Button full variant="ghost" disabled={busy} onClick={() => register('participant')}>
                  Register as participant
                </Button>
              </>
            )}
            {event.is_hours_eligible && (
              <p className="text-sm leading-snug text-muted">
                Volunteer hours from this event count toward Manulife's Benevity program.
              </p>
            )}
          </Card>
        </div>
      </PageContainer>
    </>
  );
}
