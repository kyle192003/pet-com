import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Card, { Tag, Meta } from '../common/Card';
import Icon, { EVENT_TYPE_ICON } from '../common/Icons';
import { TextField, SelectField, ChipGroup } from '../common/FormField';
import { EmptyState } from '../common/Feedback';
import Button from '../common/Button';
import { useStore, selectEvents } from '../../data/store';
import { EVENT_TYPES, fmtDate, timeRange } from '../../utils/format';

export function EventCard({ event }) {
  const volunteerText =
    event.is_volunteer_event && event.volunteer_slots_left > 0
      ? `${event.volunteer_slots_left} volunteer slots left`
      : 'General attendance';
  return (
    <Card as="article" className="flex flex-col gap-3.5 p-5.5">
      <Tag>
        <Icon name={EVENT_TYPE_ICON[event.event_type]} size={14} />
        {EVENT_TYPES[event.event_type]}
      </Tag>
      <h3 className="text-[19px] font-bold leading-snug">
        <Link to={`/events/${event.id}`} className="text-black no-underline hover:text-brand">
          {event.title}
        </Link>
      </h3>
      <div className="flex flex-col gap-2">
        <Meta icon={<Icon name="calendar" />}>{fmtDate(event.date)}</Meta>
        <Meta icon={<Icon name="clock" />}>{timeRange(event.start_time, event.end_time)}</Meta>
        <Meta icon={<Icon name="pin" />}>{event.location}</Meta>
      </div>
      <p className="flex-1 text-[15px] leading-snug text-muted">{event.short_description}</p>
      <div className="flex items-center justify-between gap-3 border-t border-line pt-3.5">
        <Tag tone={event.is_volunteer_event ? 'solid' : 'outline'}>{volunteerText}</Tag>
        <Link to={`/events/${event.id}`} className="text-[15px] font-bold">
          View event
        </Link>
      </div>
    </Card>
  );
}

const TYPE_OPTIONS = [
  { value: '', label: 'All' },
  { value: 'fun_run', label: 'Fun run' },
  { value: 'adoption_day', label: 'Adoption day' },
  { value: 'volunteer', label: 'Volunteer' },
];

export default function EventsList() {
  const [filters, setFilters] = useState({ from: '', to: '', type: '', location: '' });
  const set = (key) => (value) => setFilters((f) => ({ ...f, [key]: value }));

  const state = useStore();
  const data = useMemo(() => selectEvents(state, filters), [state, filters]);

  const locations = useMemo(() => {
    const names = [...new Set(selectEvents(state).map((e) => e.location))].sort();
    return [{ value: '', label: 'All locations' }, ...names.map((n) => ({ value: n, label: n }))];
  }, [state]);

  const hasFilters = Object.values(filters).some(Boolean);

  return (
    <div className="flex flex-col gap-5">
      <Card as="section" aria-label="Filter events" className="flex flex-wrap items-end gap-7 p-5.5">
        <div className="grid w-full grid-cols-2 gap-3 sm:w-auto">
          <TextField id="ev-from" type="date" label="From" value={filters.from} onChange={(e) => set('from')(e.target.value)} className="min-w-0 sm:w-42.5" />
          <TextField id="ev-to" type="date" label="To" value={filters.to} onChange={(e) => set('to')(e.target.value)} className="min-w-0 sm:w-42.5" />
        </div>
        <ChipGroup label="Event type" options={TYPE_OPTIONS} value={filters.type} onChange={set('type')} />
        <SelectField id="ev-loc" label="Location" options={locations} value={filters.location}
          onChange={(e) => set('location')(e.target.value)} className="w-full sm:w-60" />
        {hasFilters && (
          <Button variant="ghost" size="sm" onClick={() => setFilters({ from: '', to: '', type: '', location: '' })}>
            Clear filters
          </Button>
        )}
      </Card>

      {data.length ? (
        <>
          <p className="text-[15px] text-muted" aria-live="polite">
            Showing {data.length} event{data.length === 1 ? '' : 's'}
          </p>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {data.map((e) => (
              <EventCard key={e.id} event={e} />
            ))}
          </div>
        </>
      ) : (
        <EmptyState title="No events match these filters">Try a wider date range or another event type.</EmptyState>
      )}
    </div>
  );
}
