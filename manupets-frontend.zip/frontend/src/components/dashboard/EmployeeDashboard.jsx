import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import PageContainer from '../common/PageContainer';
import Card, { Tag, Meta, DateBlock } from '../common/Card';
import Button from '../common/Button';
import Icon from '../common/Icons';
import SectionHeader from '../common/SectionHeader';
import { Dog, Cat, PawTrail } from '../common/Illustrations';
import useAuth from '../../hooks/useAuth';
import { useStore, selectEvents, selectVolunteerSummary, selectMyPolicies } from '../../data/store';
import { EVENT_TYPES, fmtDate, timeRange, monthShort, dayNum } from '../../utils/format';

function insuranceSummary(policies = []) {
  if (!policies.length) return "You haven't enrolled a pet yet. Coverage takes a few minutes to set up.";
  const active = policies.filter((p) => p.policy_status === 'active').map((p) => p.pet_name);
  const pending = policies.filter((p) => p.policy_status === 'pending').map((p) => p.pet_name);
  const parts = [];
  if (active.length) parts.push(`${active.join(' and ')} ${active.length > 1 ? 'are' : 'is'} covered.`);
  if (pending.length) parts.push(`${pending.join(' and ')}'s enrollment is pending review.`);
  return parts.join(' ') || 'None of your policies are active right now.';
}

export default function EmployeeDashboard() {
  const { user } = useAuth();
  const state = useStore();
  const data = useMemo(
    () => ({ events: selectEvents(state), hours: selectVolunteerSummary(state), policies: selectMyPolicies(state) }),
    [state],
  );

  const firstName = user?.full_name?.split(' ')[0] || 'there';
  const featured = data.events.filter((e) => e.is_hours_eligible).slice(0, 3);
  const upcoming = data.events.filter((e) => !e.is_hours_eligible).slice(0, 3);
  const pct = Math.min(100, Math.round((data.hours.total_hours / data.hours.goal_hours) * 100));

  return (
    <>
      <header className="relative grid items-center gap-10 overflow-hidden rounded-b-3xl bg-brand px-6 pt-11 pb-12 text-white md:px-12 lg:grid-cols-[1.4fr_1fr] lg:rounded-b-[32px]">
        <PawTrail spots={[{ left: 612, top: 150, rotate: 40 }, { left: 640, top: 205, rotate: 60 }, { left: 608, top: 252, rotate: 45 }]} className="hidden lg:block" />
        <div className="relative z-[1]">
          <h1 className="text-3xl leading-[1.06] font-extrabold tracking-tight sm:text-4xl lg:text-[46px]">
            Hi {firstName}, the shelter dogs are ready for their walk.
          </h1>
          <p className="mt-3 max-w-150 text-lg">
            Volunteer at city pet events, track your hours and manage your pet's insurance in one place.
          </p>
        </div>
        <section aria-label="My volunteer hours" className="relative z-[1] mt-12 flex flex-col gap-3.5 rounded-[22px] bg-white p-6.5 text-black lg:mt-0">
          <span className="absolute -top-15.5 right-4.5 flex">
            <Dog size={84} />
          </span>
          <span className="text-[15px] font-bold">My volunteer hours, {new Date().getFullYear()}</span>
          <>
              <div className="flex items-baseline gap-2.5">
                <b className="text-[56px] leading-none font-extrabold text-brand">{data.hours.total_hours}</b>
                <span className="font-semibold">hours logged</span>
              </div>
              <div className="h-2.5 overflow-hidden rounded-full bg-brand-tint" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label="Progress to yearly goal">
                <div className="h-full bg-brand" style={{ width: `${pct}%` }} />
              </div>
              <span className="text-sm text-muted">
                {data.hours.completed} completed · {data.hours.upcoming} upcoming · goal {data.hours.goal_hours} hours
              </span>
          </>
        </section>
      </header>

      <PageContainer>
        <>
              <section className="flex flex-col gap-4.5">
                <SectionHeader title="Featured volunteer events" linkTo="/volunteer" linkLabel="All volunteer events" />
                <div className="grid gap-5 md:grid-cols-3">
                  {featured.map((e) => (
                    <Card as="article" key={e.id} className="flex flex-col gap-3 p-5.5">
                      <Tag tone="solid">
                        <Icon name="star" size={14} />
                        Benevity hours eligible
                      </Tag>
                      <h3 className="text-[19px] font-bold">{e.title}</h3>
                      <div className="flex flex-1 flex-col gap-2">
                        <Meta icon={<Icon name="calendar" />}>{fmtDate(e.date)}, {timeRange(e.start_time, e.end_time)}</Meta>
                        <Meta icon={<Icon name="pin" />}>{e.location}</Meta>
                      </div>
                      <div className="flex items-center justify-between gap-3">
                        <span className="text-sm font-semibold text-muted">{e.volunteer_slots_left} volunteer slots left</span>
                        <Button size="sm" to="/volunteer">Sign up</Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </section>

              <div className="grid items-start gap-6 lg:grid-cols-[1fr_1.6fr]">
                <Card as="section" tone="dark" className="relative flex flex-col gap-4 overflow-hidden p-7">
                  <span className="text-brand-bright">
                    <Icon name="shield" size={36} />
                  </span>
                  <h2 className="text-[26px] font-extrabold text-white">Pet insurance</h2>
                  <p className="relative z-[1] max-w-72 text-base leading-normal">{insuranceSummary(data.policies)}</p>
                  <Button to="/insurance" className="relative z-[1] self-start">View my policies</Button>
                  <span className="absolute -right-2.5 -bottom-4.5 flex opacity-90">
                    <Cat size={120} stroke="#00a86b" fill="#000000" />
                  </span>
                </Card>

                <Card as="section" className="flex flex-col gap-2 p-6">
                  <div className="flex items-end justify-between gap-4">
                    <h2 className="text-[22px] font-extrabold">Upcoming events</h2>
                    <Link to="/events" className="text-[15px] font-bold">See all</Link>
                  </div>
                  <ul>
                    {upcoming.map((e) => (
                      <li key={e.id} className="flex items-center gap-3.5 border-b border-line py-3 last:border-b-0">
                        <DateBlock small month={monthShort(e.date)} day={dayNum(e.date)} />
                        <div className="flex flex-1 flex-col gap-0.5">
                          <Link to={`/events/${e.id}`} className="font-bold text-black no-underline hover:text-brand">{e.title}</Link>
                          <span className="text-sm text-muted">{timeRange(e.start_time, e.end_time)} · {e.location}</span>
                        </div>
                        <Tag>{EVENT_TYPES[e.event_type]}</Tag>
                      </li>
                    ))}
                  </ul>
                </Card>
              </div>
        </>
      </PageContainer>
    </>
  );
}
