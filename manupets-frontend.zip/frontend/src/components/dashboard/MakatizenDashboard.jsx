import { Link } from 'react-router-dom';
import PageHeader from '../common/PageHeader';
import PageContainer from '../common/PageContainer';
import Card, { Tag, DateBlock } from '../common/Card';
import Button from '../common/Button';
import SectionHeader from '../common/SectionHeader';
import { Loading, ErrorMessage } from '../common/Feedback';
import { PetCard } from '../pets/PetsList';
import { ServiceCard } from '../services/ServicesList';
import useFetch from '../../hooks/useFetch';
import useAuth from '../../hooks/useAuth';
import { getPets } from '../../api/pets.api';
import { getEvents } from '../../api/events.api';
import { getServices } from '../../api/services.api';
import { EVENT_TYPES, timeRange, monthShort, dayNum } from '../../utils/format';

export default function MakatizenDashboard() {
  const { user } = useAuth();
  const { data, loading, error, reload } = useFetch(async () => {
    const [pets, events, services] = await Promise.all([
      getPets({ status: 'available' }),
      getEvents(),
      getServices({ type: 'free' }),
    ]);
    return { pets, events, services };
  }, []);

  const firstName = user?.full_name?.split(' ')[0] || 'there';

  return (
    <>
      <PageHeader
        title={`Magandang araw, ${firstName}`}
        subtitle="Find a pet to adopt, join a pet event or book a free check-up for your dog or cat."
        actions={<Button variant="light" to="/pets">Browse pets</Button>}
      />
      <PageContainer className="gap-11">
        <ErrorMessage error={error} onRetry={reload} />
        {loading ? (
          <Loading label="Loading your dashboard…" />
        ) : (
          data && (
            <>
              <section className="flex flex-col gap-4.5">
                <SectionHeader title="Pets available for adoption" linkTo="/pets" linkLabel="See all pets" />
                <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
                  {data.pets.slice(0, 4).map((p) => (
                    <PetCard key={p.id} pet={p} />
                  ))}
                </div>
              </section>

              <section className="flex flex-col gap-4.5">
                <SectionHeader title="Upcoming events" linkTo="/events" linkLabel="See all events" />
                <div className="grid gap-5 md:grid-cols-3">
                  {data.events.slice(0, 3).map((e) => (
                    <Card as="article" key={e.id} className="flex items-center gap-4 p-4.5">
                      <DateBlock month={monthShort(e.date)} day={dayNum(e.date)} />
                      <div className="flex flex-col gap-1.5">
                        <Tag>{EVENT_TYPES[e.event_type]}</Tag>
                        <h3 className="text-[19px] font-bold leading-snug">
                          <Link to={`/events/${e.id}`} className="text-black no-underline hover:text-brand">{e.title}</Link>
                        </h3>
                        <span className="text-sm text-muted">{timeRange(e.start_time, e.end_time)} · {e.location}</span>
                      </div>
                    </Card>
                  ))}
                </div>
              </section>

              <section className="flex flex-col gap-4.5">
                <SectionHeader title="Free animal services" linkTo="/services" linkLabel="See all services" />
                <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                  {data.services.slice(0, 3).map((s) => (
                    <ServiceCard key={s.id} service={s} />
                  ))}
                </div>
              </section>
            </>
          )
        )}
      </PageContainer>
    </>
  );
}
