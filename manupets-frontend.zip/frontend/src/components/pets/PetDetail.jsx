import { Link } from 'react-router-dom';
import PageContainer from '../common/PageContainer';
import { Tag } from '../common/Card';
import Button from '../common/Button';
import Icon from '../common/Icons';
import { PetPhoto } from '../common/Illustrations';
import { Loading, ErrorMessage } from '../common/Feedback';
import useFetch from '../../hooks/useFetch';
import { getPet } from '../../api/pets.api';
import { ageLabel, cap, fmtShortDate } from '../../utils/format';

export default function PetDetail({ petId }) {
  const { data: pet, loading, error, reload } = useFetch(() => getPet(petId), [petId]);

  if (loading) return <PageContainer><Loading label="Loading pet profile…" /></PageContainer>;
  if (error) return <PageContainer><ErrorMessage error={error} onRetry={reload} /></PageContainer>;

  const facts = [
    ['Species', cap(pet.species)],
    ['Breed', pet.breed],
    ['Age', ageLabel(pet.age_years)],
    ['Size', cap(pet.size)],
    ['Gender', cap(pet.gender)],
    ['Listed', fmtShortDate(pet.date_listed)],
  ];
  const medical = pet.medical
    ? [
        ['Vaccinated', pet.medical.vaccinated],
        ['Neutered or spayed', pet.medical.neutered_spayed],
      ]
    : [];

  return (
    <PageContainer>
      <nav aria-label="Breadcrumb" className="text-sm">
        <Link to="/pets">Pets for adoption</Link> / <span aria-current="page">{pet.name}</span>
      </nav>
      <div className="grid items-start gap-12 lg:grid-cols-[1.1fr_1fr]">
        <div className="flex flex-col gap-3">
          <PetPhoto species={pet.species} photoUrl={pet.photo_url} alt={pet.name} height={460} className="rounded-[22px]" />
        </div>

        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2.5">
            <Tag tone={pet.status === 'available' ? 'tint' : 'dark'}>{cap(pet.status)}</Tag>
            <h1 className="text-5xl leading-none font-extrabold tracking-tight md:text-[56px]">{pet.name}</h1>
            {pet.rescued_location && <p className="text-[17px] text-muted">Rescued in {pet.rescued_location} · ID #P-{pet.id}</p>}
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {facts.map(([label, value]) => (
              <div key={label} className="flex flex-col gap-1 rounded-[14px] border border-black/15 px-4 py-3.5">
                <span className="text-[13px] font-semibold text-muted">{label}</span>
                <b className="text-[17px]">{value}</b>
              </div>
            ))}
          </div>

          <section className="flex flex-col gap-2">
            <h2 className="text-[19px] font-bold">Temperament</h2>
            <p className="text-base leading-relaxed">{pet.temperament || pet.description}</p>
          </section>

          {pet.medical && (
            <section className="flex flex-col gap-2.5">
              <h2 className="text-[19px] font-bold">Medical info</h2>
              <ul className="flex flex-wrap gap-6">
                {medical.map(([label, ok]) => (
                  <li key={label} className="flex items-center gap-2.5 text-base">
                    <span className={ok ? 'text-brand' : 'text-black'}>
                      <Icon name={ok ? 'check' : 'x'} size={20} />
                    </span>
                    {ok ? label : `Not yet ${label.toLowerCase()}`}
                  </li>
                ))}
              </ul>
              {pet.medical.notes && <p className="text-[15px] text-muted">Notes: {pet.medical.notes}</p>}
            </section>
          )}

          <div className="flex flex-wrap gap-3">
            {pet.status === 'available' ? (
              <Button size="lg" to={`/adopt/${pet.id}`}>
                <Icon name="heart" size={18} />
                Apply for adoption
              </Button>
            ) : (
              <p className="font-semibold">{pet.name} is {pet.status}. Browse other pets looking for a home.</p>
            )}
            <Button size="lg" variant="ghost" to="/pets">
              See other pets
            </Button>
          </div>
        </div>
      </div>
    </PageContainer>
  );
}
