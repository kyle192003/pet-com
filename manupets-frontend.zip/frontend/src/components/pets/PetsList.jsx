import { useState } from 'react';
import { Link } from 'react-router-dom';
import Card, { Tag } from '../common/Card';
import Button from '../common/Button';
import Icon from '../common/Icons';
import { PetPhoto } from '../common/Illustrations';
import { ChipGroup, SelectField } from '../common/FormField';
import { Loading, ErrorMessage, EmptyState } from '../common/Feedback';
import useFetch from '../../hooks/useFetch';
import { getPets } from '../../api/pets.api';
import { ageLabel, cap } from '../../utils/format';

const STATUS_TONE = { available: 'tint', reserved: 'dark', adopted: 'outline' };

export function PetCard({ pet }) {
  return (
    <Card as="article" className="flex flex-col overflow-hidden">
      <PetPhoto species={pet.species} photoUrl={pet.photo_url} alt={`${pet.name}`} height={200} />
      <div className="flex flex-1 flex-col gap-2.5 p-4.5">
        <div className="flex items-center justify-between gap-2">
          <h3 className="text-[19px] font-bold">
            <Link to={`/pets/${pet.id}`} className="text-black no-underline hover:text-brand">
              {pet.name}
            </Link>
          </h3>
          <Tag tone={STATUS_TONE[pet.status]}>{cap(pet.status)}</Tag>
        </div>
        <div className="text-sm text-muted">
          {cap(pet.species)} · {pet.breed} · {ageLabel(pet.age_years)} · {cap(pet.gender)}
        </div>
        <p className="flex-1 text-[15px] leading-snug">{pet.description}</p>
        {pet.status === 'available' ? (
          <Button full to={`/adopt/${pet.id}`}>
            <Icon name="heart" size={16} />
            Apply to adopt
          </Button>
        ) : (
          <Button full variant="ghost" to={`/pets/${pet.id}`}>
            View profile
          </Button>
        )}
      </div>
    </Card>
  );
}

export default function PetsList() {
  const [filters, setFilters] = useState({ species: '', size: '', age: '', status: 'available' });
  const set = (key) => (value) => setFilters((f) => ({ ...f, [key]: value }));
  const { data, loading, error, reload } = useFetch(
    () => getPets(filters),
    [filters.species, filters.size, filters.age, filters.status],
  );

  return (
    <div className="flex flex-col gap-8">
      <Card as="section" aria-label="Filter pets" className="flex flex-wrap items-end gap-8 p-5.5">
        <ChipGroup label="Species" value={filters.species} onChange={set('species')}
          options={[{ value: '', label: 'All' }, { value: 'dog', label: 'Dogs' }, { value: 'cat', label: 'Cats' }]} />
        <ChipGroup label="Size" value={filters.size} onChange={set('size')}
          options={[{ value: '', label: 'Any' }, { value: 'small', label: 'Small' }, { value: 'medium', label: 'Medium' }, { value: 'large', label: 'Large' }]} />
        <SelectField id="pt-age" label="Age" value={filters.age} onChange={(e) => set('age')(e.target.value)} className="w-full sm:w-45"
          options={[{ value: '', label: 'Any age' }, { value: 'under1', label: 'Under 1 year' }, { value: '1to5', label: '1 to 5 years' }, { value: 'over5', label: 'Over 5 years' }]} />
        <SelectField id="pt-status" label="Status" value={filters.status} onChange={(e) => set('status')(e.target.value)} className="w-full sm:w-45"
          options={[{ value: 'available', label: 'Available' }, { value: 'reserved', label: 'Reserved' }, { value: '', label: 'All' }]} />
      </Card>

      <ErrorMessage error={error} onRetry={reload} />
      {loading ? (
        <Loading label="Fetching pets…" />
      ) : data?.length ? (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {data.map((p) => (
            <PetCard key={p.id} pet={p} />
          ))}
        </div>
      ) : (
        !error && <EmptyState title="No pets match these filters">Try another size or age, or show all pets.</EmptyState>
      )}
    </div>
  );
}
