import { useId, useRef, useState } from 'react';
import Button from '../common/Button';
import Icon from '../common/Icons';
import Modal from '../common/Modal';
import { Checkbox, SelectField } from '../common/FormField';
import IdPrivacyNotice, { ID_NOTICE_SUMMARY } from './IdPrivacyNotice';
import cx from '../../utils/cx';

export const ID_TYPES = [
  { value: '', label: 'Choose your ID type' },
  { value: 'philsys', label: 'PhilSys National ID' },
  { value: 'passport', label: 'Passport' },
  { value: 'drivers_license', label: "Driver's license" },
  { value: 'umid', label: 'UMID' },
  { value: 'postal', label: 'Postal ID' },
  { value: 'voters', label: "Voter's ID" },
  { value: 'prc', label: 'PRC ID' },
  { value: 'other', label: 'Other government-issued ID' },
];

const ACCEPTED = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_MB = 5;

const formatSize = (bytes) => (bytes > 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)} MB` : `${Math.round(bytes / 1024)} KB`);

// Value shape:
// { idType, file: { name, size, dataUrl } | null, agreedTerms, privacyConsent }
export default function IdUpload({ value, onChange, errors = {} }) {
  const inputId = useId();
  const inputRef = useRef(null);
  const [showTerms, setShowTerms] = useState(false);
  const [fileError, setFileError] = useState('');
  const [dragging, setDragging] = useState(false);

  const consented = value.agreedTerms && value.privacyConsent;
  const set = (patch) => onChange({ ...value, ...patch });

  const readFile = (file) => {
    setFileError('');
    if (!file) return;
    if (!ACCEPTED.includes(file.type)) {
      setFileError('Upload a JPG, PNG or WEBP photo of your ID.');
      return;
    }
    if (file.size > MAX_MB * 1024 * 1024) {
      setFileError(`This photo is ${formatSize(file.size)}. Upload one under ${MAX_MB} MB.`);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => set({ file: { name: file.name, size: file.size, dataUrl: reader.result } });
    reader.onerror = () => setFileError("This photo couldn't be read. Try another file.");
    reader.readAsDataURL(file);
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    if (consented) readFile(e.dataTransfer.files?.[0]);
  };

  const removeFile = () => {
    set({ file: null });
    if (inputRef.current) inputRef.current.value = '';
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Step 1: consent */}
      <div className="flex flex-col gap-4 rounded-card border-2 border-black p-5">
        <div className="flex items-start gap-3">
          <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-brand-tint text-brand">
            <Icon name="shield" size={22} />
          </span>
          <div className="flex flex-col gap-1">
            <h3 className="text-[17px] font-bold">Before you upload your ID</h3>
            <p className="text-sm text-muted">Protected under the Data Privacy Act of 2012 (RA 10173)</p>
          </div>
        </div>

        <ul className="flex flex-col gap-2 text-[15px] leading-snug">
          {ID_NOTICE_SUMMARY.map((line) => (
            <li key={line} className="flex gap-2.5">
              <span className="mt-0.5 text-brand">
                <Icon name="check" size={16} />
              </span>
              {line}
            </li>
          ))}
        </ul>

        <button type="button" onClick={() => setShowTerms(true)} className="cursor-pointer self-start text-[15px] font-bold text-brand underline">
          Read the full Terms and Conditions and Privacy Notice
        </button>

        <div className="flex flex-col gap-3 border-t border-line pt-4">
          <div className="flex flex-col gap-1">
            <Checkbox id={`${inputId}-terms`} checked={value.agreedTerms} onChange={(e) => set({ agreedTerms: e.target.checked })}
              label="I have read and agree to the Terms and Conditions for uploading my ID." />
            {errors.agreedTerms && <span className="pl-8 text-[13px] font-bold">{errors.agreedTerms}</span>}
          </div>
          <div className="flex flex-col gap-1">
            <Checkbox id={`${inputId}-privacy`} checked={value.privacyConsent} onChange={(e) => set({ privacyConsent: e.target.checked })}
              label="I consent to the collection and processing of my personal information, including my ID, for this adoption application, in accordance with the Data Privacy Act of 2012 (RA 10173)." />
            {errors.privacyConsent && <span className="pl-8 text-[13px] font-bold">{errors.privacyConsent}</span>}
          </div>
        </div>
      </div>

      {/* Step 2: upload (locked until both boxes are checked) */}
      <fieldset disabled={!consented} className={cx('flex flex-col gap-4', !consented && 'opacity-60')}>
        <legend className="sr-only">Upload your valid ID</legend>
        <SelectField id={`${inputId}-type`} label="ID type" options={ID_TYPES} value={value.idType}
          onChange={(e) => set({ idType: e.target.value })} error={errors.idType} className="sm:max-w-80" />

        {value.file ? (
          <div className="flex flex-col gap-4 rounded-card border border-black/15 p-4 sm:flex-row sm:items-center">
            <img src={value.file.dataUrl} alt="Preview of your uploaded ID" className="h-32 w-full rounded-xl bg-brand-tint object-contain sm:w-52" />
            <div className="flex flex-1 flex-col gap-1">
              <span className="flex items-center gap-2 font-bold">
                <span className="text-brand"><Icon name="check" size={18} /></span>
                ID uploaded
              </span>
              <span className="text-sm break-all text-muted">{value.file.name} · {formatSize(value.file.size)}</span>
              <span className="text-sm text-muted">Make sure your photo, full name and address are readable.</span>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="ghost" onClick={() => inputRef.current?.click()}>Replace</Button>
              <Button size="sm" variant="danger" onClick={removeFile}>Remove</Button>
            </div>
          </div>
        ) : (
          <label
            htmlFor={`${inputId}-file`}
            onDragOver={(e) => { e.preventDefault(); if (consented) setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={onDrop}
            className={cx(
              'flex flex-col items-center gap-2 rounded-card border-2 border-dashed px-6 py-9 text-center',
              consented ? 'cursor-pointer hover:border-brand hover:bg-brand-tint' : 'cursor-not-allowed',
              dragging ? 'border-brand bg-brand-tint' : 'border-line-strong',
              errors.file && 'border-black',
            )}
          >
            <span className="flex size-12 items-center justify-center rounded-full bg-brand-tint text-brand">
              <Icon name={consented ? 'upload' : 'lock'} size={24} />
            </span>
            {consented ? (
              <>
                <span className="font-bold">Upload a photo of your valid ID</span>
                <span className="text-sm text-muted">Drag it here or click to choose. JPG, PNG or WEBP, up to {MAX_MB} MB.</span>
              </>
            ) : (
              <>
                <span className="font-bold">Upload locked</span>
                <span className="text-sm text-muted">Check both boxes above to upload your ID.</span>
              </>
            )}
          </label>
        )}
        <input
          ref={inputRef}
          id={`${inputId}-file`}
          type="file"
          accept={ACCEPTED.join(',')}
          className="sr-only"
          onChange={(e) => readFile(e.target.files?.[0])}
        />
        {(fileError || errors.file) && <span className="text-[13px] font-bold">{fileError || errors.file}</span>}
      </fieldset>

      <Modal open={showTerms} onClose={() => setShowTerms(false)} title="Terms and Conditions and Privacy Notice" width="max-w-200">
        <IdPrivacyNotice />
        <div className="sticky -bottom-7 -mx-7 -mb-7 flex flex-wrap justify-end gap-3 border-t border-line bg-white px-7 py-4">
          <Button variant="ghost" onClick={() => setShowTerms(false)}>Close</Button>
          <Button
            onClick={() => {
              onChange({ ...value, agreedTerms: true, privacyConsent: true });
              setShowTerms(false);
            }}
          >
            I agree to both
          </Button>
        </div>
      </Modal>
    </div>
  );
}
