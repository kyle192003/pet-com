// Terms and Conditions for ID upload + Privacy Notice under the
// Data Privacy Act of 2012 (Republic Act No. 10173).
//
// TEMPLATE: have the Makati LGU Data Protection Officer or legal team review
// this text and fill in every [bracketed] value before going live.

export const ID_TERMS_VERSION = '2026-09';

// Short version shown above the upload box
export const ID_NOTICE_SUMMARY = [
  'Your ID is used only to confirm your identity for this adoption application.',
  'Only authorized Makati LGU adoption officers can view it.',
  'It is kept for [retention period] after your application is closed, then deleted.',
  'You can ask to see, correct or delete your data at any time.',
];

function Section({ title, children }) {
  return (
    <section className="flex flex-col gap-2">
      <h3 className="text-base font-bold">{title}</h3>
      <div className="flex flex-col gap-2 text-[15px] leading-relaxed">{children}</div>
    </section>
  );
}

// Full text shown in the "Read the full terms" modal
export default function IdPrivacyNotice() {
  return (
    <div className="flex flex-col gap-5">
      <p className="text-sm text-muted">Version {ID_TERMS_VERSION}. Last updated [date].</p>

      <h2 className="text-xl font-extrabold">Part 1: Terms and Conditions for ID upload</h2>

      <Section title="1. Why we ask for an ID">
        <p>
          To protect the animals in our care, the Makati City adoption program needs to confirm that every applicant is a
          real person and that the name and address on the application match a valid government-issued ID.
        </p>
      </Section>

      <Section title="2. What you agree to">
        <ul className="list-disc space-y-1.5 pl-5">
          <li>The ID you upload is your own, valid and not expired.</li>
          <li>The details in your application are true and match your ID.</li>
          <li>You will not upload another person's ID or an edited image.</li>
          <li>Submitting false information may lead to your application being rejected and future applications being declined.</li>
          <li>An adoption officer may contact you to confirm your identity or ask for a clearer photo.</li>
        </ul>
      </Section>

      <Section title="3. Accepted IDs">
        <p>
          Any valid government-issued photo ID, such as the PhilSys National ID, passport, driver's license, UMID, postal
          ID, voter's ID or PRC ID. The photo, full name and address (if shown) must be clear and readable.
        </p>
      </Section>

      <h2 className="pt-2 text-xl font-extrabold">Part 2: Privacy Notice (Data Privacy Act of 2012)</h2>

      <Section title="4. Who is collecting your data">
        <p>
          The [Makati City office in charge of the adoption program], as personal information controller, together with
          Manulife as program partner, in line with Republic Act No. 10173, the Data Privacy Act of 2012, and its
          Implementing Rules and Regulations.
        </p>
      </Section>

      <Section title="5. What we collect">
        <ul className="list-disc space-y-1.5 pl-5">
          <li>An image of your valid ID and the ID type</li>
          <li>Your full name, email, mobile number and address</li>
          <li>Your answers about your home and pet experience</li>
          <li>The date and time you gave consent</li>
        </ul>
        <p>
          Government-issued ID numbers are sensitive personal information under the law, so we handle your ID with extra
          care.
        </p>
      </Section>

      <Section title="6. How we use it">
        <p>
          Only to verify your identity, assess your adoption application, contact you about it and keep records required
          by the program. We do not sell your data or use your ID for marketing.
        </p>
      </Section>

      <Section title="7. Who can see it">
        <p>
          Only authorized adoption officers and admins of the program. We do not share your ID with anyone else unless the
          law requires it.
        </p>
      </Section>

      <Section title="8. How long we keep it">
        <p>
          Your ID image is kept for [retention period] after your application is approved, rejected or withdrawn, and is
          then securely deleted.
        </p>
      </Section>

      <Section title="9. How we protect it">
        <p>
          We use organizational, physical and technical safeguards, such as restricted access and secure storage, to
          protect your data from loss, misuse and unauthorized access.
        </p>
      </Section>

      <Section title="10. Your rights">
        <p>Under the Data Privacy Act of 2012, you have the right to:</p>
        <ul className="list-disc space-y-1.5 pl-5">
          <li>be informed about how your data is processed</li>
          <li>access your personal data</li>
          <li>object to processing</li>
          <li>have your data corrected</li>
          <li>have your data erased or blocked</li>
          <li>get a copy of your data (data portability)</li>
          <li>claim damages, and file a complaint with the National Privacy Commission</li>
        </ul>
      </Section>

      <Section title="11. Withdrawing consent">
        <p>
          You can withdraw your consent at any time by contacting us. We will then stop processing your ID and delete it,
          but we will no longer be able to continue your adoption application.
        </p>
      </Section>

      <Section title="12. Contact our Data Protection Officer">
        <p>
          [DPO name], [office address], [email address], [phone number].
        </p>
      </Section>
    </div>
  );
}
