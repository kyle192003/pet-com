import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Card from '../common/Card';
import Button from '../common/Button';
import { TextField, TextAreaField, ChipGroup, Checkbox } from '../common/FormField';
import { PetPhoto } from '../common/Illustrations';
import { Notice } from '../common/Feedback';
import useAuth from '../../hooks/useAuth';
import IdUpload, { ID_TYPES } from './IdUpload';
import { ID_TERMS_VERSION } from './IdPrivacyNotice';
import { submitApplication } from '../../data/store';
import { ageLabel, cap } from '../../utils/format';

const RESIDENCES = [
  { value: 'house', label: 'House' },
  { value: 'condo', label: 'Condo' },
  { value: 'apartment', label: 'Apartment' },
  { value: 'townhouse', label: 'Townhouse' },
];

function validate(f) {
  const e = {};
  if (!f.applicant_name.trim()) e.applicant_name = 'Enter your full name.';
  if (!/^\S+@\S+\.\S+$/.test(f.applicant_email)) e.applicant_email = 'Enter a valid email.';
  if (!/^[0-9+\s-]{10,15}$/.test(f.applicant_phone)) e.applicant_phone = 'Enter a mobile number, like 0917 123 4567.';
  if (!f.address.trim()) e.address = 'Enter your home address.';
  if (!f.agreed_to_terms) e.agreed_to_terms = 'Agree to the adoption terms to continue.';
  return e;
}

function validateId(id) {
  const e = {};
  if (!id.agreedTerms) e.agreedTerms = 'Agree to the Terms and Conditions to upload your ID.';
  if (!id.privacyConsent) e.privacyConsent = 'Give your consent under the Data Privacy Act to upload your ID.';
  if (!id.idType) e.idType = 'Choose the type of ID you are uploading.';
  if (!id.file) e.file = 'Upload a photo of your valid ID so we can verify your identity.';
  return e;
}

export default function AdoptionForm({ pet }) {
  const { user } = useAuth();
  const [form, setForm] = useState({
    applicant_name: '',
    applicant_email: '',
    applicant_phone: '',
    address: '',
    residence_type: 'house',
    experience_notes: '',
    agreed_to_terms: false,
  });
  const [idInfo, setIdInfo] = useState({ idType: '', file: null, agreedTerms: false, privacyConsent: false });
  const [errors, setErrors] = useState({});
  const [idErrors, setIdErrors] = useState({});
  const [status, setStatus] = useState('idle'); // idle | done
  const [serverError, setServerError] = useState('');

  // Pre-fill from the logged-in user
  useEffect(() => {
    if (!user) return;
    setForm((f) => ({
      ...f,
      applicant_name: f.applicant_name || user.full_name || '',
      applicant_email: f.applicant_email || user.email || '',
      applicant_phone: f.applicant_phone || user.mobile_number || '',
      address: f.address || user.address || '',
    }));
  }, [user]);

  const update = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((f) => ({ ...f, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const found = validate(form);
    const foundId = validateId(idInfo);
    setErrors(found);
    setIdErrors(foundId);
    if (Object.keys(found).length || Object.keys(foundId).length) {
      setServerError('Some details are missing. Check the highlighted fields.');
      return;
    }
    setServerError('');
    try {
      submitApplication({
        ...form,
        pet_id: pet.id,
        valid_id_type: idInfo.idType,
        valid_id_image: idInfo.file.dataUrl,
        valid_id_file_name: idInfo.file.name,
        id_terms_accepted: true,
        privacy_consent: true,
        consent_at: new Date().toISOString(),
        terms_version: ID_TERMS_VERSION,
      });
      setStatus('done');
    } catch (err) {
      setServerError(err.message);
    }
  };

  const steps = [
    'An adoption officer verifies your ID and reviews your application',
    'A shelter officer calls you for a short interview',
    `You visit ${pet.name} at the shelter`,
    `Sign the adoption agreement and take ${pet.name} home`,
  ];

  const summary = (
    <aside className="flex flex-col gap-5">
      <Card className="overflow-hidden">
        <PetPhoto species={pet.species} photoUrl={pet.photo_url} alt={pet.name} height={200} />
        <div className="flex flex-col gap-1 p-4.5">
          <h3 className="text-[19px] font-bold">{pet.name}</h3>
          <span className="text-sm text-muted">
            {cap(pet.species)} · {pet.breed} · {ageLabel(pet.age_years)} · {cap(pet.gender)}
          </span>
        </div>
      </Card>
      <Card as="section" className="flex flex-col gap-4 p-5.5">
        <h3 className="text-[19px] font-bold">What happens next</h3>
        <ol className="flex flex-col gap-3.5">
          {steps.map((s, i) => (
            <li key={s} className="flex items-start gap-3.5 text-[15px] leading-snug">
              <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-black text-sm font-bold text-white">{i + 1}</span>
              <span className="pt-0.5">{s}</span>
            </li>
          ))}
        </ol>
      </Card>
    </aside>
  );

  if (status === 'done') {
    return (
      <div className="grid items-start gap-8 lg:grid-cols-[1.7fr_1fr]">
        <Card className="flex flex-col items-start gap-4 p-8">
          <h2 className="text-[26px] font-extrabold tracking-tight">Application sent for {pet.name}</h2>
          <p className="text-base leading-relaxed">
            Thanks, {form.applicant_name.split(' ')[0]}. Your{' '}
            {ID_TYPES.find((t) => t.value === idInfo.idType)?.label || 'ID'} was received. We'll contact you at {form.applicant_email} or{' '}
            {form.applicant_phone} once an adoption officer has verified your ID and reviewed your application.
          </p>
          <div className="flex flex-wrap gap-3">
            <Button to="/pets">Browse more pets</Button>
            <Button variant="ghost" to="/">Go to home</Button>
          </div>
        </Card>
        {summary}
      </div>
    );
  }

  const field = (name, label, props = {}) => (
    <TextField id={`ad-${name}`} name={name} label={label} value={form[name]} onChange={update} error={errors[name]} {...props} />
  );

  return (
    <div className="grid items-start gap-8 lg:grid-cols-[1.7fr_1fr]">
      <Card as="form" onSubmit={handleSubmit} noValidate className="flex flex-col gap-7 p-6 md:p-8">
        {serverError && <Notice tone="error">{serverError}</Notice>}

        <section className="flex flex-col gap-4">
          <h2 className="text-[22px] font-extrabold">Pet</h2>
          <TextField id="ad-pet" label="Pet you're applying for" readOnly
            value={`${pet.name} · ${cap(pet.species)} · ${pet.breed}`} hint="Selected from the pet's page" />
        </section>

        <section className="flex flex-col gap-4">
          <h2 className="text-[22px] font-extrabold">About you</h2>
          <div className="grid gap-4.5 sm:grid-cols-2">
            {field('applicant_name', 'Full name', { autoComplete: 'name' })}
            {field('applicant_email', 'Email', { type: 'email', autoComplete: 'email' })}
            {field('applicant_phone', 'Mobile', { type: 'tel', autoComplete: 'tel' })}
            {field('address', 'Address', { autoComplete: 'street-address' })}
          </div>
        </section>

        <section className="flex flex-col gap-4">
          <div className="flex flex-col gap-1">
            <h2 className="text-[22px] font-extrabold">Valid ID</h2>
            <p className="text-[15px] text-muted">
              An adoption officer checks your ID before approving. Upload a clear photo of one valid government-issued ID.
            </p>
          </div>
          <IdUpload value={idInfo} onChange={setIdInfo} errors={idErrors} />
        </section>

        <section className="flex flex-col gap-4">
          <h2 className="text-[22px] font-extrabold">Your home</h2>
          <ChipGroup label="Type of residence" options={RESIDENCES} value={form.residence_type}
            onChange={(v) => setForm((f) => ({ ...f, residence_type: v }))} />
        </section>

        <section className="flex flex-col gap-4">
          <h2 className="text-[22px] font-extrabold">Experience</h2>
          <TextAreaField id="ad-exp" name="experience_notes" label="Previous pet experience"
            placeholder="Tell us about pets you've owned or cared for" value={form.experience_notes} onChange={update} />
        </section>

        <div className="flex flex-col gap-1.5">
          <Checkbox id="ad-terms" name="agreed_to_terms" checked={form.agreed_to_terms} onChange={update}
            className="rounded-[14px] bg-brand-tint p-4.5"
            label={<>I agree to the <a href="#terms">adoption terms and conditions</a>, including a home visit and follow-up checks.</>} />
          {errors.agreed_to_terms && <span className="text-[13px] font-bold">{errors.agreed_to_terms}</span>}
        </div>

        <div className="flex justify-end gap-3">
          <Button variant="ghost" to={`/pets/${pet.id}`}>Cancel</Button>
          <Button type="submit">Submit application</Button>
        </div>
        <p className="text-sm text-muted">
          Changed your mind? <Link to="/pets">Browse other pets</Link>.
        </p>
      </Card>
      {summary}
    </div>
  );
}
