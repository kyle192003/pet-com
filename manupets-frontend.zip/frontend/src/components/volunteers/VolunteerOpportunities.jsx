import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Card, { Tag, Meta, DateBlock } from '../common/Card';
import Button from '../common/Button';
import Icon from '../common/Icons';
import Modal from '../common/Modal';
import { Checkbox } from '../common/FormField';
import { Loading, ErrorMessage, EmptyState, Notice } from '../common/Feedback';
import useFetch from '../../hooks/useFetch';
import useAuth from '../../hooks/useAuth';
import { getOpportunities, signUpForRole, getMyAssignments } from '../../api/volunteers.api';
import { fmtDate, monthShort, dayNum, timeRange } from '../../utils/format';
import cx from '../../utils/cx';

export default function VolunteerOpportunities() {
  const { isLoggedIn } = useAuth();
  const navigate = useNavigate();
  const [eligibleOnly, setEligibleOnly] = useState(false);
  const { data, loading, error, reload } = useFetch(() => getOpportunities({ hoursEligibleOnly: eligibleOnly }), [eligibleOnly]);
  const mine = useFetch(() => getMyAssignments(), [isLoggedIn]);
  const [picking, setPicking] = useState(null); // event being signed up for
  const [message, setMessage] = useState(null);
  const [busy, setBusy] = useState(false);

  const myRoleIds = new Set((mine.data || []).map((a) => a.volunteer_role_id));

  const openSignUp = (event) => {
    if (!isLoggedIn) {
      navigate('/login', { state: { from: '/volunteer' } });
      return;
    }
    setMessage(null);
    setPicking(event);
  };

  const signUp = async (role) => {
    setBusy(true);
    try {
      await signUpForRole(role.id);
      setMessage({ tone: 'success', text: `You're signed up as ${role.role_name} for ${picking.title}.` });
      setPicking(null);
      await Promise.all([reload(), mine.reload()]);
    } catch (err) {
      setMessage({ tone: 'error', text: err.message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex flex-col gap-5">
      <Card className="flex flex-wrap items-center justify-between gap-4 px-5.5 py-4.5">
        <Checkbox id="vol-eligible" checked={eligibleOnly} onChange={(e) => setEligibleOnly(e.target.checked)}
          label={<span className="font-semibold">Only show events eligible for employee volunteer hours</span>} />
        {data && <span className="text-[15px] text-muted">{data.length} upcoming events</span>}
      </Card>

      {message && !picking && <Notice tone={message.tone}>{message.text}</Notice>}
      <ErrorMessage error={error} onRetry={reload} />

      {loading ? (
        <Loading label="Finding volunteer events…" />
      ) : data?.length ? (
        data.map((e) => {
          const signedUp = e.volunteer_roles.some((r) => myRoleIds.has(r.id));
          return (
            <Card as="article" key={e.id} className="flex flex-col gap-6 p-5.5 md:flex-row md:items-center">
              <DateBlock month={monthShort(e.date)} day={dayNum(e.date)} />
              <div className="flex flex-1 flex-col gap-2.5">
                <div className="flex flex-wrap items-center gap-3">
                  <h3 className="text-[19px] font-bold">
                    <Link to={`/events/${e.id}`} className="text-black no-underline hover:text-brand">
                      {e.title}
                    </Link>
                  </h3>
                  {e.is_hours_eligible ? (
                    <Tag tone="solid">
                      <Icon name="check" size={14} />
                      Manulife volunteer hours eligible
                    </Tag>
                  ) : (
                    <Tag tone="outline">Not eligible for volunteer hours</Tag>
                  )}
                </div>
                <div className="flex flex-wrap gap-6">
                  <Meta icon={<Icon name="clock" />}>{fmtDate(e.date)}, {timeRange(e.start_time, e.end_time)}</Meta>
                  <Meta icon={<Icon name="pin" />}>{e.location}</Meta>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-bold">Roles needed:</span>
                  {e.volunteer_roles.map((r) => (
                    <Tag key={r.id} tone="outline">{r.role_name}</Tag>
                  ))}
                </div>
              </div>
              <div className="flex shrink-0 flex-col gap-2 md:items-end">
                {signedUp ? (
                  <Tag tone="tint" className="min-h-11 px-4 text-sm">
                    <Icon name="check" size={16} />
                    You're signed up
                  </Tag>
                ) : (
                  <Button onClick={() => openSignUp(e)} disabled={e.volunteer_slots_left === 0}>
                    {e.volunteer_slots_left === 0 ? 'All roles full' : 'Sign up to volunteer'}
                  </Button>
                )}
                <span className="text-sm text-muted">{e.volunteer_slots_left} volunteer slots left</span>
              </div>
            </Card>
          );
        })
      ) : (
        !error && <EmptyState title="No volunteer events right now">New events are added every month. Check back soon.</EmptyState>
      )}

      <Modal open={Boolean(picking)} onClose={() => setPicking(null)} title={picking ? `Choose a role for ${picking.title}` : ''}>
        {message?.tone === 'error' && <Notice tone="error">{message.text}</Notice>}
        <ul className="flex flex-col gap-3">
          {picking?.volunteer_roles.map((r) => {
            const full = r.slots_available <= 0;
            const taken = myRoleIds.has(r.id);
            return (
              <li key={r.id} className={cx('flex items-center justify-between gap-4 rounded-card border border-black/15 p-4', full && 'opacity-60')}>
                <div>
                  <b>{r.role_name}</b>
                  <p className="text-sm text-muted">{r.description}</p>
                  <p className="mt-1 text-sm font-semibold">{full ? 'Full' : `${r.slots_available} slots left`}</p>
                </div>
                <Button size="sm" disabled={busy || full || taken} onClick={() => signUp(r)}>
                  {taken ? 'Signed up' : 'Choose'}
                </Button>
              </li>
            );
          })}
        </ul>
      </Modal>
    </div>
  );
}
