import { useMemo } from 'react';
import PageHeader from '../common/PageHeader';
import PageContainer from '../common/PageContainer';
import Button from '../common/Button';
import { PetPhoto } from '../common/Illustrations';
import { EmptyState } from '../common/Feedback';
import { useStore, selectNewsletter } from '../../data/store';
import { fmtLongDate } from '../../utils/format';

export default function NewsletterDetail({ newsletterId }) {
  const state = useStore();
  const item = useMemo(() => selectNewsletter(state, newsletterId), [state, newsletterId]);

  if (!item) {
    return (
      <PageContainer>
        <EmptyState title="This newsletter no longer exists" action={<Button to="/newsletters">See all issues</Button>} />
      </PageContainer>
    );
  }

  return (
    <>
      <PageHeader
        title={item.title}
        subtitle={item.published_at ? `Published ${fmtLongDate(item.published_at)}` : 'Draft, not published yet'}
        crumbs={[{ label: 'Newsletter', to: '/newsletters' }, { label: item.title }]}
      />
      <PageContainer className="max-w-4xl">
        <PetPhoto height={300} alt={`${item.title} cover`} className="rounded-[22px]" />
        <p className="text-lg leading-relaxed font-semibold">{item.summary}</p>
        <div className="max-w-[70ch] whitespace-pre-line text-[17px] leading-[1.7]">{item.body}</div>
        <Button variant="ghost" to="/newsletters" className="self-start">
          Back to all issues
        </Button>
      </PageContainer>
    </>
  );
}
