import PageHeader from '../common/PageHeader';
import PageContainer from '../common/PageContainer';
import Button from '../common/Button';
import { PetPhoto } from '../common/Illustrations';
import { Loading, ErrorMessage } from '../common/Feedback';
import useFetch from '../../hooks/useFetch';
import { getNewsletter } from '../../api/newsletters.api';
import { fmtLongDate } from '../../utils/format';

export default function NewsletterDetail({ newsletterId }) {
  const { data: item, loading, error, reload } = useFetch(() => getNewsletter(newsletterId), [newsletterId]);

  if (loading) return <PageContainer><Loading label="Loading newsletter…" /></PageContainer>;
  if (error) return <PageContainer><ErrorMessage error={error} onRetry={reload} /></PageContainer>;

  return (
    <>
      <PageHeader
        title={item.title}
        subtitle={item.published_at ? `Published ${fmtLongDate(item.published_at)}` : 'Draft, not published yet'}
        crumbs={[{ label: 'Newsletter', to: '/newsletters' }, { label: item.title }]}
      />
      <PageContainer className="max-w-4xl">
        <PetPhoto height={300} alt={`${item.title} cover`} className="rounded-[22px]" />
        <p className="text-lg leading-relaxed font-semibold">{item.summary}</p>
        <div className="max-w-[70ch] whitespace-pre-line text-[17px] leading-[1.7]">{item.body}</div>
        <Button variant="ghost" to="/newsletters" className="self-start">
          Back to all issues
        </Button>
      </PageContainer>
    </>
  );
}
