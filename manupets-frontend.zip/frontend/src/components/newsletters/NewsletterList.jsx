import { Link } from 'react-router-dom';
import Card, { Tag } from '../common/Card';
import Button from '../common/Button';
import { PetPhoto } from '../common/Illustrations';
import SectionHeader from '../common/SectionHeader';
import { Loading, ErrorMessage, EmptyState } from '../common/Feedback';
import useFetch from '../../hooks/useFetch';
import { getNewsletters } from '../../api/newsletters.api';
import { fmtDate } from '../../utils/format';

const COVERS = ['dog', 'cat', undefined];
const monthYear = (d) => fmtDate(d, { month: 'long', year: 'numeric' });

export default function NewsletterList() {
  const { data, loading, error, reload } = useFetch(() => getNewsletters(), []);

  if (loading) return <Loading label="Loading newsletters…" />;
  if (error) return <ErrorMessage error={error} onRetry={reload} />;
  if (!data?.length) return <EmptyState title="No newsletters yet">The first issue will appear here once it's published.</EmptyState>;

  const [latest, ...past] = data;

  return (
    <div className="flex flex-col gap-8">
      <Card as="article" className="grid overflow-hidden md:grid-cols-[1.2fr_1fr]">
        <PetPhoto height={340} alt={`${latest.title} cover`} />
        <div className="flex flex-col justify-center gap-3.5 p-7 md:p-9">
          <Tag tone="solid">Latest issue</Tag>
          <span className="text-sm font-semibold text-muted">{monthYear(latest.published_at)}</span>
          <h2 className="text-[28px] leading-tight font-extrabold tracking-tight md:text-[32px]">{latest.title}</h2>
          <p className="text-base leading-relaxed">{latest.summary}</p>
          <Button to={`/newsletters/${latest.id}`} className="self-start">
            Read this issue
          </Button>
        </div>
      </Card>

      {past.length > 0 && (
        <section className="flex flex-col">
          <SectionHeader title="Past issues" />
          {past.map((n, i) => (
            <article key={n.id} className="grid items-center gap-6 border-b border-line py-5 sm:grid-cols-[200px_1fr_auto]">
              <PetPhoto height={120} species={COVERS[i % 3]} alt={`${n.title} cover`} className="rounded-[14px]" />
              <div className="flex flex-col gap-1.5">
                <span className="text-sm font-semibold text-muted">{monthYear(n.published_at)}</span>
                <h3 className="text-[19px] font-bold">
                  <Link to={`/newsletters/${n.id}`} className="text-black no-underline hover:text-brand">
                    {n.title}
                  </Link>
                </h3>
                <p className="text-[15px] leading-snug text-muted">{n.summary}</p>
              </div>
              <Button variant="ghost" size="sm" to={`/newsletters/${n.id}`}>
                Read
              </Button>
            </article>
          ))}
        </section>
      )}
    </div>
  );
}
