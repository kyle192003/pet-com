import CrudManager from './CrudManager';
import { Tag } from '../common/Card';
import { getEvents, createEvent, updateEvent, deleteEvent } from '../../api/events.api';
import { EVENT_TYPES, fmtDate } from '../../utils/format';

const TYPE_OPTIONS = Object.entries(EVENT_TYPES).map(([value, label]) => ({ value, label }));

// 10.1 Admin – Manage Events
export default function ManageEvents() {
  return (
    <CrudManager
      title="Manage events"
      subtitle="Create, edit and remove city pet events."
      entityName="Event"
      createLabel="Create event"
      load={() => getEvents({ includeInactive: true })}
      create={createEvent}
      update={updateEvent}
      remove={deleteEvent}
      filter={{
        label: 'Event type',
        options: [{ value: '', label: 'All types' }, ...TYPE_OPTIONS],
        test: (row, v) => row.event_type === v,
      }}
      columns={[
        { key: 'id', label: 'ID', render: (e) => `E-${e.id}` },
        { key: 'title', label: 'Title', render: (e) => <b>{e.title}</b> },
        { key: 'date', label: 'Date', render: (e) => fmtDate(e.date, { month: 'short', day: 'numeric', year: 'numeric' }) },
        { key: 'event_type', label: 'Event type', render: (e) => EVENT_TYPES[e.event_type] },
        { key: 'is_active', label: 'Status', render: (e) => <Tag tone={e.is_active ? 'solid' : 'outline'}>{e.is_active ? 'Active' : 'Inactive'}</Tag> },
      ]}
      emptyItem={{
        title: '', event_type: 'fun_run', date: '', start_time: '08:00', end_time: '12:00', location: '',
        max_attendees: 100, sponsor: 'Manulife', short_description: '', description: '',
        is_volunteer_event: false, is_hours_eligible: false, is_active: true,
      }}
      fromForm={(v) => ({ ...v, max_attendees: Number(v.max_attendees) || 0 })}
      fields={[
        { name: 'title', label: 'Title', required: true, full: true },
        { name: 'event_type', label: 'Event type', type: 'select', options: TYPE_OPTIONS },
        { name: 'date', label: 'Date', type: 'date', required: true },
        { name: 'start_time', label: 'Start time', type: 'time', required: true },
        { name: 'end_time', label: 'End time', type: 'time', required: true },
        { name: 'location', label: 'Location', required: true },
        { name: 'max_attendees', label: 'Max attendees', type: 'number' },
        { name: 'sponsor', label: 'Sponsor', hint: 'Shows a "Sponsored by" badge' },
        { name: 'short_description', label: 'Short description', full: true, hint: 'Shown on event cards' },
        { name: 'description', label: 'Full description', type: 'textarea', full: true },
        { name: 'is_volunteer_event', label: 'Needs volunteers', type: 'checkbox' },
        { name: 'is_hours_eligible', label: 'Counts toward Manulife volunteer hours', type: 'checkbox' },
        { name: 'is_active', label: 'Active (visible to users)', type: 'checkbox', full: true },
      ]}
    />
  );
}
