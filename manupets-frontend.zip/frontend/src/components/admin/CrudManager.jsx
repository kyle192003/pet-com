import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import PageHeader from '../common/PageHeader';
import PageContainer from '../common/PageContainer';
import Card from '../common/Card';
import Button from '../common/Button';
import Icon from '../common/Icons';
import Modal from '../common/Modal';
import DataTable, { RowActions } from '../common/DataTable';
import { TextField, TextAreaField, SelectField, Checkbox } from '../common/FormField';
import { Notice } from '../common/Feedback';
import { useStore } from '../../data/store';

// Generic admin table + create/edit modal used by the section 10 admin pages.
//
// fields: [{ name, label, type: text|textarea|select|date|time|number|checkbox, options, required, full, hint }]
// select: (state) => rows   (read from the in-memory store)
// filter: { label, options: [{ value, label }], test: (row, value) => boolean }
export default function CrudManager({
  title,
  subtitle,
  entityName,
  createLabel,
  select,
  columns,
  fields,
  emptyItem,
  toForm = (row) => row,
  fromForm = (values) => values,
  create,
  update,
  remove,
  removeLabel = 'Delete',
  searchKeys = ['title'],
  searchPlaceholder = 'Search by title',
  filter,
}) {
  const state = useStore();
  const data = useMemo(() => select(state), [state, select]);
  const [params, setParams] = useSearchParams();
  const [query, setQuery] = useState('');
  const [filterValue, setFilterValue] = useState('');
  const [editing, setEditing] = useState(null); // null | { mode: 'create' | 'edit', row?, values }
  const [confirming, setConfirming] = useState(null);
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState(null);

  const openCreate = () => {
    setErrors({});
    setEditing({ mode: 'create', values: { ...emptyItem } });
  };
  const openEdit = (row) => {
    setErrors({});
    setEditing({ mode: 'edit', row, values: { ...emptyItem, ...toForm(row) } });
  };

  // /admin/events?new=1 opens the create form (used by dashboard quick actions)
  useEffect(() => {
    if (params.get('new') === '1') {
      openCreate();
      params.delete('new');
      setParams(params, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const rows = useMemo(() => {
    let list = data;
    if (filter && filterValue) list = list.filter((r) => filter.test(r, filterValue));
    const q = query.trim().toLowerCase();
    if (q) list = list.filter((r) => searchKeys.some((k) => String(r[k] ?? '').toLowerCase().includes(q)));
    return list;
  }, [data, filter, filterValue, query, searchKeys]);

  const setValue = (name, value) => setEditing((e) => ({ ...e, values: { ...e.values, [name]: value } }));

  const save = (e) => {
    e.preventDefault();
    const found = {};
    fields.forEach((f) => {
      const v = editing.values[f.name];
      if (f.required && (v === '' || v === null || v === undefined)) found[f.name] = `${f.label} is required.`;
    });
    setErrors(found);
    if (Object.keys(found).length) return;
    try {
      const payload = fromForm(editing.values);
      if (editing.mode === 'create') create(payload);
      else update(editing.row.id, payload);
      setMessage({ tone: 'success', text: `${entityName} ${editing.mode === 'create' ? 'created' : 'saved'}.` });
      setEditing(null);
    } catch (err) {
      setErrors({ _form: err.message });
    }
  };

  const confirmRemove = () => {
    try {
      remove(confirming.id);
      setMessage({ tone: 'success', text: `${entityName} ${removeLabel === 'Archive' ? 'archived' : 'deleted'}.` });
    } catch (err) {
      setMessage({ tone: 'error', text: err.message });
    }
    setConfirming(null);
  };

  const allColumns = [
    ...columns,
    {
      key: '_actions',
      label: 'Actions',
      align: 'right',
      render: (row) => (
        <RowActions>
          <Button size="sm" onClick={() => openEdit(row)}>Edit</Button>
          {remove && (
            <Button size="sm" variant="danger" onClick={() => setConfirming(row)}>
              {removeLabel}
            </Button>
          )}
        </RowActions>
      ),
    },
  ];

  const renderField = (f) => {
    const id = `crud-${f.name}`;
    const value = editing.values[f.name] ?? '';
    const common = { id, label: f.label, hint: f.hint, error: errors[f.name], className: f.full ? 'sm:col-span-2' : undefined };
    if (f.type === 'textarea') return <TextAreaField key={f.name} {...common} value={value} onChange={(e) => setValue(f.name, e.target.value)} />;
    if (f.type === 'select')
      return <SelectField key={f.name} {...common} options={f.options} value={value} onChange={(e) => setValue(f.name, e.target.value)} />;
    if (f.type === 'checkbox')
      return (
        <Checkbox key={f.name} id={id} label={f.label} checked={Boolean(editing.values[f.name])}
          onChange={(e) => setValue(f.name, e.target.checked)} className={f.full ? 'sm:col-span-2' : undefined} />
      );
    return <TextField key={f.name} {...common} type={f.type || 'text'} value={value} onChange={(e) => setValue(f.name, e.target.value)} />;
  };

  return (
    <>
      <PageHeader
        title={title}
        subtitle={subtitle}
        actions={
          create && (
            <Button variant="light" onClick={openCreate}>
              <Icon name="plus" size={16} />
              {createLabel}
            </Button>
          )
        }
      />
      <PageContainer>
        {message && <Notice tone={message.tone}>{message.text}</Notice>}
        <Card as="section" className="flex flex-col gap-4.5 p-6">
          <div className="flex flex-wrap items-end gap-3">
            <TextField id="crud-search" type="search" label="Search" placeholder={searchPlaceholder} value={query}
              onChange={(e) => setQuery(e.target.value)} className="w-full sm:w-85" />
            {filter && (
              <SelectField id="crud-filter" label={filter.label} value={filterValue} onChange={(e) => setFilterValue(e.target.value)}
                options={filter.options} className="w-full sm:w-50" />
            )}
          </div>
          <DataTable columns={allColumns} rows={rows} empty={`No ${entityName.toLowerCase()}s found.`} />
          <span className="text-sm text-muted">
            Showing {rows.length} of {data.length}
          </span>
        </Card>
      </PageContainer>

      <Modal
        open={Boolean(editing)}
        onClose={() => setEditing(null)}
        title={editing?.mode === 'create' ? createLabel : `Edit ${entityName.toLowerCase()}`}
        width="max-w-180"
      >
        {editing && (
          <form onSubmit={save} noValidate className="flex flex-col gap-5">
            {errors._form && <Notice tone="error">{errors._form}</Notice>}
            <div className="grid gap-4 sm:grid-cols-2">{fields.map(renderField)}</div>
            <div className="flex justify-end gap-3">
              <Button variant="ghost" onClick={() => setEditing(null)}>Cancel</Button>
              <Button type="submit">{editing.mode === 'create' ? createLabel : 'Save changes'}</Button>
            </div>
          </form>
        )}
      </Modal>

      <Modal open={Boolean(confirming)} onClose={() => setConfirming(null)} title={`${removeLabel} this ${entityName.toLowerCase()}?`} width="max-w-120">
        <p className="text-base">
          <b>{confirming?.title || confirming?.name}</b> will be {removeLabel === 'Archive' ? 'hidden from the public list' : 'removed permanently'}.
        </p>
        <div className="flex justify-end gap-3">
          <Button variant="ghost" onClick={() => setConfirming(null)}>Keep it</Button>
          <Button variant="danger" onClick={confirmRemove}>{removeLabel}</Button>
        </div>
      </Modal>
    </>
  );
}
