import CrudManager from './CrudManager';
import { Tag } from '../common/Card';
import { selectPets, createPet, updatePet, archivePet } from '../../data/store';
import { cap } from '../../utils/format';

const selectAll = (state) => selectPets(state, { includeArchived: true });
const STATUS_TONE = { available: 'solid', reserved: 'dark', adopted: 'outline', archived: 'outline' };

// 10.2 Admin – Manage Pets (Adoption)
export default function ManagePets() {
  return (
    <CrudManager
      title="Manage pets"
      subtitle="Add pets for adoption and update their status."
      entityName="Pet"
      createLabel="Add pet"
      select={selectAll}
      create={createPet}
      update={updatePet}
      remove={archivePet}
      removeLabel="Archive"
      searchKeys={['name', 'breed']}
      searchPlaceholder="Search by name or breed"
      filter={{
        label: 'Status',
        options: [
          { value: '', label: 'All statuses' },
          { value: 'available', label: 'Available' },
          { value: 'reserved', label: 'Reserved' },
          { value: 'adopted', label: 'Adopted' },
          { value: 'archived', label: 'Archived' },
        ],
        test: (row, v) => row.status === v,
      }}
      columns={[
        { key: 'id', label: 'ID', render: (p) => `P-${p.id}` },
        { key: 'name', label: 'Name', render: (p) => <b>{p.name}</b> },
        { key: 'species', label: 'Species', render: (p) => cap(p.species) },
        { key: 'breed', label: 'Breed' },
        { key: 'status', label: 'Status', render: (p) => <Tag tone={STATUS_TONE[p.status]}>{cap(p.status)}</Tag> },
      ]}
      emptyItem={{
        name: '', species: 'dog', breed: '', age_years: '', gender: 'male', size: 'medium',
        description: '', temperament: '', photo_url: '', status: 'available', rescued_location: '',
      }}
      fromForm={(v) => ({ ...v, age_years: Number(v.age_years) })}
      fields={[
        { name: 'name', label: 'Name', required: true },
        { name: 'species', label: 'Species', type: 'select', options: [{ value: 'dog', label: 'Dog' }, { value: 'cat', label: 'Cat' }] },
        { name: 'breed', label: 'Breed', required: true, hint: 'e.g. Aspin, Puspin, Shih Tzu mix' },
        { name: 'age_years', label: 'Age (years)', type: 'number', required: true, hint: 'Use 0.5 for 6 months' },
        { name: 'gender', label: 'Gender', type: 'select', options: [{ value: 'male', label: 'Male' }, { value: 'female', label: 'Female' }] },
        { name: 'size', label: 'Size', type: 'select', options: ['small', 'medium', 'large'].map((s) => ({ value: s, label: cap(s) })) },
        { name: 'status', label: 'Status', type: 'select', options: ['available', 'reserved', 'adopted'].map((s) => ({ value: s, label: cap(s) })) },
        { name: 'rescued_location', label: 'Rescued location' },
        { name: 'photo_url', label: 'Photo URL', full: true, hint: 'Leave empty to show an illustration' },
        { name: 'description', label: 'Short bio', full: true, required: true, hint: 'One sentence shown on the pet card' },
        { name: 'temperament', label: 'Temperament notes', type: 'textarea', full: true },
      ]}
    />
  );
}
