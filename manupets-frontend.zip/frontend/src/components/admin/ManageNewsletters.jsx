import CrudManager from './CrudManager';
import { Tag } from '../common/Card';
import { getNewsletters, createNewsletter, updateNewsletter, deleteNewsletter } from '../../api/newsletters.api';
import { fmtShortDate } from '../../utils/format';

// 10.5 Admin – Newsletters
export default function ManageNewsletters() {
  return (
    <CrudManager
      title="Newsletters"
      subtitle="Write and publish updates for residents and employees."
      entityName="Newsletter"
      createLabel="Write newsletter"
      load={() => getNewsletters({ includeDrafts: true })}
      create={createNewsletter}
      update={updateNewsletter}
      remove={deleteNewsletter}
      columns={[
        { key: 'title', label: 'Title', render: (n) => <b>{n.title}</b> },
        { key: 'published_at', label: 'Published at', render: (n) => (n.published_at ? fmtShortDate(n.published_at) : <span className="text-muted">Not published</span>) },
        { key: 'status', label: 'Status', render: (n) => <Tag tone={n.published_at ? 'solid' : 'outline'}>{n.published_at ? 'Published' : 'Draft'}</Tag> },
      ]}
      emptyItem={{ title: '', summary: '', body: '', publish: true }}
      toForm={(row) => ({ ...row, publish: Boolean(row.published_at) })}
      fields={[
        { name: 'title', label: 'Title', required: true, full: true },
        { name: 'summary', label: 'Summary', full: true, required: true, hint: 'One or two sentences shown in the list' },
        { name: 'body', label: 'Body', type: 'textarea', full: true, required: true },
        { name: 'publish', label: 'Publish now (uncheck to save as draft)', type: 'checkbox', full: true },
      ]}
    />
  );
}
