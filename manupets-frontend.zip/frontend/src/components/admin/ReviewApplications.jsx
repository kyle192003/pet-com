import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import PageHeader from '../common/PageHeader';
import PageContainer from '../common/PageContainer';
import Card, { Tag } from '../common/Card';
import Button from '../common/Button';
import Icon from '../common/Icons';
import DataTable, { RowActions } from '../common/DataTable';
import { ChipGroup, TextAreaField } from '../common/FormField';
import { Loading, ErrorMessage, Notice } from '../common/Feedback';
import useFetch from '../../hooks/useFetch';
import { getApplications, updateApplication } from '../../api/adoptions.api';
import { cap, fmtShortDate } from '../../utils/format';

const STATUS_TONE = { pending: 'outline', approved: 'solid', rejected: 'dark' };

// 10.3 Admin – Review Adoption Applications
export default function ReviewApplications() {
  const [params, setParams] = useSearchParams();
  const [status, setStatus] = useState(params.get('id') ? '' : 'pending');
  const { data, loading, error, reload } = useFetch(() => getApplications({ status: status || undefined }), [status]);
  const [selectedId, setSelectedId] = useState(params.get('id') ? Number(params.get('id')) : null);
  const [notes, setNotes] = useState('');
  const [message, setMessage] = useState(null);
  const [busy, setBusy] = useState(false);

  const selected = data?.find((a) => a.id === selectedId) || null;
  useEffect(() => setNotes(selected?.admin_notes || ''), [selected?.id, selected?.admin_notes]);

  const select = (id) => {
    setSelectedId(id);
    setMessage(null);
    setParams(id ? { id: String(id) } : {}, { replace: true });
  };

  const decide = async (newStatus) => {
    setBusy(true);
    try {
      const updated = await updateApplication(selected.id, { status: newStatus, admin_notes: notes });
      setMessage({
        tone: 'success',
        text:
          newStatus === 'approved'
            ? `Approved. ${updated.pet_name} is now marked as adopted.`
            : newStatus === 'rejected'
              ? 'Application rejected.'
              : 'Notes saved.',
      });
      await reload();
    } catch (err) {
      setMessage({ tone: 'error', text: err.message });
    } finally {
      setBusy(false);
    }
  };

  const columns = [
    { key: 'pet_name', label: 'Pet', render: (a) => <b>{a.pet_name}</b> },
    { key: 'applicant_name', label: 'Applicant' },
    { key: 'created_at', label: 'Submitted', render: (a) => <span className="text-muted">{fmtShortDate(a.created_at)}</span> },
    { key: 'status', label: 'Status', render: (a) => <Tag tone={STATUS_TONE[a.status]}>{cap(a.status)}</Tag> },
    {
      key: 'actions',
      label: 'Actions',
      align: 'right',
      render: (a) => (
        <RowActions>
          <Button size="sm" variant={a.id === selectedId ? 'primary' : 'ghost'} onClick={() => select(a.id)}>
            View
          </Button>
        </RowActions>
      ),
    },
  ];

  const details = selected
    ? [
        ['Email', selected.applicant_email],
        ['Mobile', selected.applicant_phone],
        ['Address', selected.address],
        ['Residence', cap(selected.residence_type || '')],
        ['Experience', selected.experience_notes || 'None given'],
      ]
    : [];

  return (
    <>
      <PageHeader title="Adoption applications" subtitle="Review applications and approve or reject them." />
      <PageContainer>
        <div className="grid items-start gap-6 xl:grid-cols-[1.55fr_1fr]">
          <Card as="section" className="flex flex-col gap-4.5 p-6">
            <ChipGroup label="Status" value={status} onChange={setStatus}
              options={[{ value: '', label: 'All' }, { value: 'pending', label: 'Pending' }, { value: 'approved', label: 'Approved' }, { value: 'rejected', label: 'Rejected' }]} />
            <ErrorMessage error={error} onRetry={reload} />
            {loading ? <Loading /> : <DataTable columns={columns} rows={data || []} selectedKey={selectedId} empty="No applications with this status." />}
          </Card>

          {selected ? (
            <Card as="aside" tone="outlined" aria-label="Application details" className="flex flex-col gap-4.5 p-6.5 xl:sticky xl:top-24">
              <div className="flex items-start justify-between gap-4">
                <div className="flex flex-col gap-1">
                  <span className="text-sm font-semibold text-muted">Application for {selected.pet_name}</span>
                  <h2 className="text-2xl font-extrabold">{selected.applicant_name}</h2>
                </div>
                <button type="button" onClick={() => select(null)} aria-label="Close details"
                  className="inline-flex size-10 shrink-0 cursor-pointer items-center justify-center rounded-full border border-line-strong hover:bg-black hover:text-white">
                  <Icon name="x" size={16} />
                </button>
              </div>
              <Tag tone={STATUS_TONE[selected.status]}>{cap(selected.status)}</Tag>
              <dl className="flex flex-col gap-3.5">
                {details.map(([label, value]) => (
                  <div key={label} className="flex flex-col gap-0.5">
                    <dt className="text-[13px] font-semibold text-muted">{label}</dt>
                    <dd className="m-0 text-[15px] leading-snug">{value}</dd>
                  </div>
                ))}
              </dl>
              <TextAreaField id="aa-notes" label="Admin notes" placeholder="Visible to admins only" value={notes}
                onChange={(e) => setNotes(e.target.value)} />
              {message && <Notice tone={message.tone}>{message.text}</Notice>}
              {selected.status === 'pending' ? (
                <div className="flex gap-3">
                  <Button className="flex-1" disabled={busy} onClick={() => decide('approved')}>Approve</Button>
                  <Button className="flex-1" variant="danger" disabled={busy} onClick={() => decide('rejected')}>Reject</Button>
                </div>
              ) : (
                <Button variant="ghost" disabled={busy} onClick={() => decide(selected.status)}>Save notes</Button>
              )}
            </Card>
          ) : (
            <Card tone="tint" className="flex flex-col gap-2 p-6.5">
              <h2 className="text-xl font-extrabold">Pick an application</h2>
              <p className="text-[15px]">Select View on any row to see the applicant's details and approve or reject.</p>
            </Card>
          )}
        </div>
      </PageContainer>
    </>
  );
}
