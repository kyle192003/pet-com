import CrudManager from './CrudManager';
import { Tag } from '../common/Card';
import { getServices, createService, updateService, deleteService } from '../../api/services.api';
import { PET_TYPES, cap } from '../../utils/format';

// 10.4 Admin – Manage Services
export default function ManageServices() {
  return (
    <CrudManager
      title="Manage services"
      subtitle="Free and discounted services shown to residents."
      entityName="Service"
      createLabel="Add service"
      load={() => getServices()}
      create={createService}
      update={updateService}
      remove={deleteService}
      columns={[
        { key: 'title', label: 'Title', render: (s) => <b>{s.title}</b> },
        { key: 'service_type', label: 'Type', render: (s) => <Tag tone={s.service_type === 'free' ? 'solid' : 'dark'}>{cap(s.service_type)}</Tag> },
        { key: 'pet_type', label: 'Pet type', render: (s) => PET_TYPES[s.pet_type] },
        { key: 'location', label: 'Location' },
      ]}
      emptyItem={{
        title: '', service_type: 'free', pet_type: 'both', description: '', availability_schedule: '',
        location: '', contact_info: '', how_to_avail: 'walk_in',
      }}
      fields={[
        { name: 'title', label: 'Title', required: true, full: true },
        { name: 'service_type', label: 'Type', type: 'select', options: [{ value: 'free', label: 'Free' }, { value: 'discounted', label: 'Discounted' }] },
        { name: 'pet_type', label: 'Pet type', type: 'select', options: Object.entries(PET_TYPES).map(([value, label]) => ({ value, label })) },
        { name: 'availability_schedule', label: 'Schedule', required: true, hint: 'e.g. Every Saturday, 8 AM – 12 PM' },
        { name: 'location', label: 'Location', required: true },
        { name: 'how_to_avail', label: 'How to avail', type: 'select', options: [{ value: 'walk_in', label: 'Walk-in' }, { value: 'appointment', label: 'Appointment' }] },
        { name: 'contact_info', label: 'Contact info' },
        { name: 'description', label: 'Description', type: 'textarea', full: true, required: true },
      ]}
    />
  );
}
