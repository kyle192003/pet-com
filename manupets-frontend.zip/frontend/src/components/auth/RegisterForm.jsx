import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';
import Button from '../common/Button';
import Card from '../common/Card';
import { TextField, SelectField, Checkbox } from '../common/FormField';
import { Notice } from '../common/Feedback';

const EMPTY = {
  full_name: '',
  username: '',
  email: '',
  mobile_number: '',
  password: '',
  confirm_password: '',
  address: '',
  wants_to_volunteer: false,
  preferred_pet_type: 'both',
  skills: '',
  availability_notes: '',
};

function validate(f) {
  const e = {};
  if (!f.full_name.trim()) e.full_name = 'Enter your full name.';
  if (!f.username.trim()) e.username = 'Choose a username.';
  if (!/^\S+@\S+\.\S+$/.test(f.email)) e.email = 'Enter a valid email, like you@example.com.';
  if (!/^[0-9+\s-]{10,15}$/.test(f.mobile_number)) e.mobile_number = 'Enter a mobile number, like 0917 123 4567.';
  if (f.password.length < 8) e.password = 'Use at least 8 characters.';
  if (f.confirm_password !== f.password) e.confirm_password = 'Passwords do not match.';
  if (!f.address.trim()) e.address = 'Enter your address in Makati.';
  return e;
}

export default function RegisterForm() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');

  const update = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((f) => ({ ...f, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const found = validate(form);
    setErrors(found);
    if (Object.keys(found).length) return;
    setServerError('');
    try {
      const { confirm_password, ...payload } = form;
      await register(payload);
      navigate('/', { replace: true });
    } catch (err) {
      setServerError(err.message);
    }
  };

  const field = (name, label, props = {}) => (
    <TextField id={`rg-${name}`} name={name} label={label} value={form[name]} onChange={update} error={errors[name]} {...props} />
  );

  return (
    <Card as="form" onSubmit={handleSubmit} noValidate className="flex w-full max-w-205 flex-col gap-6 p-6 md:p-9">
      <h2 className="text-[26px] font-extrabold tracking-tight">Your details</h2>
      {serverError && <Notice tone="error">{serverError}</Notice>}

      <div className="grid gap-5 sm:grid-cols-2">
        {field('full_name', 'Full name', { placeholder: 'Juan Dela Cruz', autoComplete: 'name' })}
        {field('username', 'Username', { placeholder: 'juandc', autoComplete: 'username' })}
        {field('email', 'Email', { type: 'email', placeholder: 'you@example.com', hint: 'Used to log in', autoComplete: 'email' })}
        {field('mobile_number', 'Mobile number', { type: 'tel', placeholder: '09XX XXX XXXX', autoComplete: 'tel' })}
        {field('password', 'Password', { type: 'password', placeholder: 'At least 8 characters', autoComplete: 'new-password' })}
        {field('confirm_password', 'Confirm password', { type: 'password', placeholder: 'Re-enter password', autoComplete: 'new-password' })}
      </div>
      {field('address', 'Address', { placeholder: 'House no., street, barangay, Makati City', autoComplete: 'street-address' })}

      <div className="flex flex-col gap-5 rounded-card bg-brand-tint p-6">
        <Checkbox id="rg-volunteer" name="wants_to_volunteer" checked={form.wants_to_volunteer} onChange={update}
          label={<b className="text-base">I'd like to volunteer</b>} />
        {form.wants_to_volunteer && (
          <>
            <div className="grid gap-5 sm:grid-cols-2">
              <SelectField id="rg-pet" name="preferred_pet_type" label="Preferred pet type" value={form.preferred_pet_type}
                onChange={update}
                options={[
                  { value: 'both', label: 'Both dogs and cats' },
                  { value: 'dog', label: 'Dogs' },
                  { value: 'cat', label: 'Cats' },
                ]} />
              {field('skills', 'Skills', { placeholder: 'e.g. vet assistant, event marshal' })}
            </div>
            {field('availability_notes', 'Availability', { placeholder: 'e.g. weekends, Saturday mornings' })}
          </>
        )}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="text-[15px]">
          Already have an account?{' '}
          <Link to="/login" className="font-bold">
            Log in
          </Link>
        </p>
        <Button type="submit">Create account</Button>
      </div>
    </Card>
  );
}
