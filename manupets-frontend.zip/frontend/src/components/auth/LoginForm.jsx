import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';
import Button from '../common/Button';
import { TextField, Checkbox } from '../common/FormField';
import { Notice } from '../common/Feedback';
import { DEMO_ACCOUNTS } from '../../api/auth.api';
import { USE_MOCK } from '../../config';

export default function LoginForm() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const update = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password) {
      setError('Enter your email and password.');
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      await login(form);
      navigate(location.state?.from || '/', { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="flex w-full max-w-100 flex-col gap-5.5">
      <div className="flex flex-col gap-2">
        <h2 className="text-[32px] font-extrabold tracking-tight">Log in</h2>
        <p className="text-[15px] text-muted">Admins, Manulife employees and Makatizens all log in here.</p>
      </div>

      {error && <Notice tone="error">{error}</Notice>}

      <TextField id="login-email" name="email" type="email" label="Email" placeholder="you@example.com"
        autoComplete="email" value={form.email} onChange={update} required />
      <TextField id="login-password" name="password" type="password" label="Password" placeholder="Enter your password"
        autoComplete="current-password" value={form.password} onChange={update} required />

      <div className="flex items-center justify-between gap-3">
        <Checkbox id="login-remember" label="Keep me logged in" className="text-sm" defaultChecked />
        <a href="#forgot" className="text-sm font-semibold">
          Forgot password?
        </a>
      </div>

      <Button type="submit" full disabled={submitting}>
        {submitting ? 'Logging in…' : 'Log in'}
      </Button>

      <p className="border-t border-line pt-4.5 text-center text-[15px]">
        New to ManuPets?{' '}
        <Link to="/register" className="font-bold">
          Create an account
        </Link>
      </p>

      {USE_MOCK && (
        <div className="flex flex-col gap-2 rounded-card bg-brand-tint p-4 text-sm">
          <span className="font-bold">Demo accounts (mock mode)</span>
          {DEMO_ACCOUNTS.map((a) => (
            <button
              key={a.email}
              type="button"
              className="cursor-pointer text-left font-semibold text-brand-dark underline"
              onClick={() => setForm({ email: a.email, password: a.password })}
            >
              {a.label}: {a.email}
            </button>
          ))}
        </div>
      )}
    </form>
  );
}
