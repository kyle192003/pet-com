import { useState } from 'react';
import Card, { Tag, Meta, IconCircle } from '../common/Card';
import Button from '../common/Button';
import Icon from '../common/Icons';
import { ChipGroup } from '../common/FormField';
import { Loading, ErrorMessage, EmptyState } from '../common/Feedback';
import useFetch from '../../hooks/useFetch';
import { getServices } from '../../api/services.api';
import { PET_TYPES, cap } from '../../utils/format';

// Picks an icon from the service title
function serviceIcon(title = '') {
  const t = title.toLowerCase();
  if (t.includes('vaccin')) return 'syringe';
  if (t.includes('deworm')) return 'pill';
  if (t.includes('chip')) return 'chip';
  if (t.includes('consult') || t.includes('check')) return 'stethoscope';
  if (t.includes('regist')) return 'tag';
  return 'cross';
}

export function ServiceCard({ service }) {
  const free = service.service_type === 'free';
  return (
    <Card as="article" className="flex flex-col gap-3.5 p-5.5">
      <div className="flex items-center gap-3">
        <IconCircle>
          <Icon name={serviceIcon(service.title)} size={24} />
        </IconCircle>
        <div className="flex flex-col items-start gap-1">
          <Tag tone={free ? 'solid' : 'dark'}>{cap(service.service_type)}</Tag>
          <span className="text-sm font-semibold text-muted">{PET_TYPES[service.pet_type]}</span>
        </div>
      </div>
      <h3 className="text-[19px] font-bold leading-snug">{service.title}</h3>
      <p className="text-[15px] leading-snug text-muted">{service.description}</p>
      <div className="flex flex-1 flex-col gap-2">
        <Meta icon={<Icon name="clock" />}>{service.availability_schedule}</Meta>
        <Meta icon={<Icon name="pin" />}>{service.location}</Meta>
      </div>
      {service.how_to_avail === 'appointment' ? (
        <Button full onClick={() => window.alert(`Booking form for "${service.title}" goes here. Contact: ${service.contact_info}`)}>
          Book an appointment
        </Button>
      ) : (
        <div className="flex min-h-11 items-center justify-center rounded-full border border-black/40 text-sm font-semibold">
          Walk-in, no booking needed
        </div>
      )}
    </Card>
  );
}

export default function ServicesList() {
  const [type, setType] = useState('');
  const [petType, setPetType] = useState('');
  const { data, loading, error, reload } = useFetch(() => getServices({ type, petType }), [type, petType]);

  return (
    <div className="flex flex-col gap-8">
      <Card as="section" aria-label="Filter services" className="flex flex-wrap gap-10 p-5.5">
        <ChipGroup label="Type" value={type} onChange={setType}
          options={[{ value: '', label: 'All' }, { value: 'free', label: 'Free' }, { value: 'discounted', label: 'Discounted' }]} />
        <ChipGroup label="For" value={petType} onChange={setPetType}
          options={[{ value: '', label: 'Dogs and cats' }, { value: 'dog', label: 'Dogs' }, { value: 'cat', label: 'Cats' }]} />
      </Card>
      <ErrorMessage error={error} onRetry={reload} />
      {loading ? (
        <Loading label="Loading services…" />
      ) : data?.length ? (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {data.map((s) => (
            <ServiceCard key={s.id} service={s} />
          ))}
        </div>
      ) : (
        !error && <EmptyState title="No services match these filters">Try showing all service types.</EmptyState>
      )}
    </div>
  );
}
