// Original line illustrations used as the pet theme.
import cx from '../../utils/cx';

const STROKE = '#00663f';

export function Dog({ size = 120, stroke = STROKE, fill = '#ffffff', className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 120 120" fill="none" stroke={stroke} strokeWidth="4"
      strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d="M32 42C18 40 10 56 14 76c2 9 11 9 16 0" fill={fill} />
      <path d="M88 42c14-2 22 14 18 34-2 9-11 9-16 0" fill={fill} />
      <path d="M30 50c0-18 14-28 30-28s30 10 30 28v20c0 20-14 32-30 32S30 90 30 70z" fill={fill} />
      <path d="M60 22c-4 6-4 12 0 16" />
      <circle cx="47" cy="57" r="4.5" fill={stroke} stroke="none" />
      <circle cx="73" cy="57" r="4.5" fill={stroke} stroke="none" />
      <path d="M53 70h14l-7 8z" fill={stroke} />
      <path d="M60 78v5c-3 5-9 5-12 1M60 83c3 5 9 5 12 1" />
      <path d="M55 87c0 9 10 9 10 0" fill="#00a86b" />
    </svg>
  );
}

export function Cat({ size = 120, stroke = STROKE, fill = '#ffffff', className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 120 120" fill="none" stroke={stroke} strokeWidth="4"
      strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
      <path d="M28 54L30 18l22 17c5-1 11-1 16 0l22-17 2 36c2 30-12 48-32 48S26 84 28 54z" fill={fill} />
      <path d="M36 30l2 12M84 30l-2 12" />
      <ellipse cx="47" cy="61" rx="4" ry="5.5" fill={stroke} stroke="none" />
      <ellipse cx="73" cy="61" rx="4" ry="5.5" fill={stroke} stroke="none" />
      <path d="M55 71h10l-5 6z" fill={stroke} />
      <path d="M60 77c-2 5-8 5-10 2M60 77c2 5 8 5 10 2" />
      <path d="M40 73l-24-4M40 79l-22 3M80 73l24-4M80 79l22 3" />
    </svg>
  );
}

export function PawPrint({ size = 24, color = 'currentColor', rotate = 0, opacity = 1 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={color} aria-hidden="true"
      style={{ transform: `rotate(${rotate}deg)`, opacity }}>
      <ellipse cx="5.5" cy="10" rx="2.2" ry="2.8" />
      <ellipse cx="9.5" cy="5.5" rx="2.2" ry="2.8" />
      <ellipse cx="14.5" cy="5.5" rx="2.2" ry="2.8" />
      <ellipse cx="18.5" cy="10" rx="2.2" ry="2.8" />
      <path d="M12 11.5c-3.5 0-6 3.6-6 6.2 0 2 1.6 2.8 3.2 2.3 1-.3 1.8-.6 2.8-.6s1.8.3 2.8.6c1.6.5 3.2-.3 3.2-2.3 0-2.6-2.5-6.2-6-6.2z" />
    </svg>
  );
}

// Decorative trail of paw prints. spots: [{ left, top, rotate, size }]
export function PawTrail({ spots, color = '#00a86b', opacity = 0.55, className = '' }) {
  return (
    <span aria-hidden="true" className={cx('pointer-events-none absolute inset-0', className)}>
      {spots.map((s, i) => (
        <span key={i} className="absolute flex" style={{ left: s.left, top: s.top }}>
          <PawPrint size={s.size ?? 26} color={color} rotate={s.rotate ?? 0} opacity={opacity} />
        </span>
      ))}
    </span>
  );
}

export function PetPair({ dogSize = 196, catSize = 150, stroke = STROKE }) {
  return (
    <span className="flex items-end">
      <Cat size={catSize} stroke={stroke} />
      <span className="flex" style={{ marginLeft: -Math.round(catSize * 0.17) }}>
        <Dog size={dogSize} stroke={stroke} />
      </span>
    </span>
  );
}

// Shows the pet's photo, or a species illustration when there is no photo yet.
export function PetPhoto({ species, photoUrl, alt = 'Pet photo', height = 200, className = '' }) {
  const art = Math.round(height * 0.62);
  return (
    <div
      className={cx('relative flex items-center justify-center overflow-hidden bg-brand-tint text-brand', className)}
      style={{ height }}
    >
      {photoUrl ? (
        <img src={photoUrl} alt={alt} className="h-full w-full object-cover" />
      ) : (
        <>
          <span className="sr-only">{alt} (no photo yet)</span>
          {height >= 150 && (
            <PawTrail spots={[{ left: 14, top: 14, rotate: -20, size: 18 }, { left: 40, top: 34, rotate: 10, size: 14 }]} opacity={0.35} />
          )}
          {species === 'dog' && <Dog size={art} stroke="#008657" />}
          {species === 'cat' && <Cat size={art} stroke="#008657" />}
          {!species && <PetPair dogSize={art} catSize={Math.round(art * 0.8)} stroke="#008657" />}
        </>
      )}
    </div>
  );
}
