import cx from '../../utils/cx';

// columns: [{ key, label, render?(row), align?: 'right', className? }]
export default function DataTable({ columns, rows, rowKey = 'id', selectedKey, empty = 'Nothing here yet.' }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-[15px]">
        <thead>
          <tr>
            {columns.map((c) => (
              <th
                key={c.key}
                scope="col"
                className={cx('whitespace-nowrap border-b-2 border-black px-4 py-3 text-[13px] font-bold', c.align === 'right' ? 'text-right' : 'text-left')}
              >
                {c.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 && (
            <tr>
              <td colSpan={columns.length} className="px-4 py-10 text-center text-muted">
                {empty}
              </td>
            </tr>
          )}
          {rows.map((row) => (
            <tr key={row[rowKey]} className={cx(selectedKey === row[rowKey] && 'bg-brand-tint')}>
              {columns.map((c) => (
                <td key={c.key} className={cx('border-b border-line px-4 py-3 align-middle', c.align === 'right' && 'text-right', c.className)}>
                  {c.render ? c.render(row) : row[c.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Right-aligned group of row action buttons
export function RowActions({ children }) {
  return <div className="flex justify-end gap-2">{children}</div>;
}
