import { PawPrint } from './Illustrations';
import { APP_PARTNERS } from '../../config';

export default function Footer() {
  return (
    <footer className="mt-auto flex flex-wrap items-center justify-between gap-4 border-t border-line px-6 py-5.5 text-[13px] md:px-12">
      <span className="flex items-center gap-3">
        <span className="flex gap-1 text-brand">
          <PawPrint size={16} rotate={-20} />
          <PawPrint size={16} rotate={10} />
          <PawPrint size={16} rotate={-10} />
        </span>
        {APP_PARTNERS} pet initiatives. Dogs and cats only.
      </span>
      <span className="text-muted">Hackathon demo</span>
    </footer>
  );
}
