import cx from '../../utils/cx';

export const inputClass =
  'w-full h-12 rounded-xl border border-line-strong bg-white px-4 text-base text-black placeholder:text-black/45 ' +
  'focus:border-brand focus:outline-3 focus:outline-offset-1 focus:outline-brand-bright ' +
  '[&[readonly]]:border-brand-bright [&[readonly]]:bg-brand-tint [&[readonly]]:font-bold aria-[invalid=true]:border-2 aria-[invalid=true]:border-black';

function Wrapper({ id, label, hint, error, className, children }) {
  return (
    <div className={cx('flex flex-col gap-1.5', className)}>
      {label && (
        <label htmlFor={id} className="text-sm font-bold">
          {label}
        </label>
      )}
      {children}
      {error ? (
        <span id={`${id}-error`} className="text-[13px] font-bold">
          {error}
        </span>
      ) : (
        hint && (
          <span id={`${id}-hint`} className="text-[13px] text-muted">
            {hint}
          </span>
        )
      )}
    </div>
  );
}

const describedBy = (id, hint, error) => (error ? `${id}-error` : hint ? `${id}-hint` : undefined);

export function TextField({ id, label, hint, error, className, ...inputProps }) {
  return (
    <Wrapper id={id} label={label} hint={hint} error={error} className={className}>
      <input id={id} className={inputClass} aria-invalid={error ? true : undefined}
        aria-describedby={describedBy(id, hint, error)} {...inputProps} />
    </Wrapper>
  );
}

export function TextAreaField({ id, label, hint, error, className, ...props }) {
  return (
    <Wrapper id={id} label={label} hint={hint} error={error} className={className}>
      <textarea id={id} className={cx(inputClass, 'h-auto min-h-26 resize-y py-3')} aria-invalid={error ? true : undefined}
        aria-describedby={describedBy(id, hint, error)} {...props} />
    </Wrapper>
  );
}

// options: [{ value, label }] or ['a', 'b']
export function SelectField({ id, label, hint, error, options, className, ...props }) {
  return (
    <Wrapper id={id} label={label} hint={hint} error={error} className={className}>
      <select id={id} className={inputClass} aria-invalid={error ? true : undefined} {...props}>
        {options.map((o) => {
          const opt = typeof o === 'string' ? { value: o, label: o } : o;
          return (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          );
        })}
      </select>
    </Wrapper>
  );
}

export function Checkbox({ id, label, className, ...props }) {
  return (
    <label htmlFor={id} className={cx('flex cursor-pointer items-start gap-3 text-[15px] leading-snug', className)}>
      <input id={id} type="checkbox" className="mt-px size-5 shrink-0 accent-brand" {...props} />
      <span>{label}</span>
    </label>
  );
}

// Toggle buttons for filters: <ChipGroup label="Species" value={v} onChange={setV} options={[...]} />
export function ChipGroup({ label, options, value, onChange }) {
  return (
    <div role="group" aria-label={label}>
      <div className="mb-2 text-[13px] font-bold">{label}</div>
      <div className="flex flex-wrap gap-2">
        {options.map((o) => {
          const opt = typeof o === 'string' ? { value: o, label: o } : o;
          const on = opt.value === value;
          return (
            <button
              key={opt.value}
              type="button"
              aria-pressed={on}
              onClick={() => onChange(opt.value)}
              className={cx(
                'min-h-10 cursor-pointer rounded-full border px-4 text-sm font-semibold transition-colors',
                on ? 'border-black bg-black text-white' : 'border-line-strong bg-white text-black hover:border-black',
              )}
            >
              {opt.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
