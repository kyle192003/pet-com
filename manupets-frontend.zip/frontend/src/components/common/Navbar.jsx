import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';
import useUserRole from '../../hooks/useUserRole';
import Icon from './Icons';
import Button from './Button';
import { APP_NAME } from '../../config';
import { initials } from '../../utils/format';
import cx from '../../utils/cx';

const LINKS = {
  guest: [
    { to: '/events', label: 'Events' },
    { to: '/volunteer', label: 'Volunteer' },
    { to: '/services', label: 'Services' },
    { to: '/pets', label: 'Adopt a pet' },
    { to: '/newsletters', label: 'Newsletter' },
  ],
  makatizen: [
    { to: '/', label: 'Home', end: true },
    { to: '/events', label: 'Events' },
    { to: '/volunteer', label: 'Volunteer' },
    { to: '/services', label: 'Services' },
    { to: '/pets', label: 'Adopt a pet' },
    { to: '/newsletters', label: 'Newsletter' },
  ],
  employee: [
    { to: '/', label: 'Home', end: true },
    { to: '/events', label: 'Events' },
    { to: '/volunteer', label: 'Volunteer' },
    { to: '/services', label: 'Services' },
    { to: '/pets', label: 'Adopt a pet' },
    { to: '/insurance', label: 'Pet insurance' },
    { to: '/newsletters', label: 'Newsletter' },
  ],
  admin: [
    { to: '/', label: 'Dashboard', end: true },
    { to: '/admin/events', label: 'Events' },
    { to: '/admin/pets', label: 'Pets' },
    { to: '/admin/applications', label: 'Applications' },
    { to: '/admin/services', label: 'Services' },
    { to: '/admin/newsletters', label: 'Newsletters' },
  ],
};

const ROLE_LABEL = { admin: 'Admin', employee: 'Manulife employee', makatizen: 'Makatizen' };

export function Brand({ light = false }) {
  return (
    <Link
      to="/"
      className={cx(
        'flex items-center gap-2.5 text-[22px] font-extrabold tracking-tight no-underline',
        light ? 'text-white hover:text-white' : 'text-brand hover:text-brand-dark',
      )}
    >
      <Icon name="paw" size={26} />
      <span>{APP_NAME}</span>
    </Link>
  );
}

export default function Navbar() {
  const { user, logout } = useAuth();
  const { role } = useUserRole();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const links = LINKS[role] || LINKS.guest;

  const handleLogout = () => {
    logout();
    setOpen(false);
    navigate('/login');
  };

  return (
    <nav aria-label="Main" className="sticky top-0 z-20 border-b border-line bg-white">
      <div className="flex min-h-18 flex-wrap items-center justify-between gap-4 px-6 py-3 md:px-12 xl:flex-nowrap xl:py-0">
        <Brand />

        <button
          type="button"
          className="inline-flex size-11 items-center justify-center rounded-full border border-line-strong xl:hidden"
          aria-expanded={open}
          aria-controls="main-menu"
          aria-label={open ? 'Close menu' : 'Open menu'}
          onClick={() => setOpen((v) => !v)}
        >
          <Icon name={open ? 'x' : 'menu'} />
        </button>

        <div
          id="main-menu"
          className={cx(
            'w-full flex-col gap-4 xl:flex xl:w-auto xl:flex-1 xl:flex-row xl:items-center xl:justify-between xl:pl-8',
            open ? 'flex' : 'hidden',
          )}
        >
          <ul className="flex flex-col gap-0.5 xl:flex-row">
            {links.map((l) => (
              <li key={l.to}>
                <NavLink
                  to={l.to}
                  end={l.end}
                  onClick={() => setOpen(false)}
                  className={({ isActive }) =>
                    cx(
                      'block rounded-full px-3.5 py-2.5 text-[15px] no-underline',
                      isActive
                        ? 'bg-brand-tint font-bold text-brand-dark hover:text-brand-dark'
                        : 'font-medium text-black hover:bg-brand-tint hover:text-black',
                    )
                  }
                >
                  {l.label}
                </NavLink>
              </li>
            ))}
          </ul>

          {user ? (
            <div className="flex items-center gap-3 pb-2 text-sm xl:pb-0">
              <div className="flex flex-col xl:items-end">
                <span className="font-bold">{user.full_name}</span>
                <span className="text-[13px] text-muted">{ROLE_LABEL[user.role]}</span>
              </div>
              <div className="flex size-9.5 items-center justify-center rounded-full bg-black text-sm font-bold text-white" aria-hidden="true">
                {initials(user.full_name)}
              </div>
              <button
                type="button"
                onClick={handleLogout}
                className="inline-flex size-10 cursor-pointer items-center justify-center rounded-full border border-line-strong hover:bg-black hover:text-white"
                aria-label="Log out"
                title="Log out"
              >
                <Icon name="logout" />
              </button>
            </div>
          ) : (
            <div className="flex gap-3 pb-2 xl:pb-0">
              <Button variant="ghost" size="sm" to="/login" onClick={() => setOpen(false)}>
                Log in
              </Button>
              <Button size="sm" to="/register" onClick={() => setOpen(false)}>
                Create account
              </Button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
