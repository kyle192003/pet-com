import { PawPrint } from './Illustrations';
import cx from '../../utils/cx';

export function Loading({ label = 'Loading…' }) {
  return (
    <div className="flex items-center gap-3 py-8 font-semibold text-muted" role="status">
      <span className="animate-bob flex text-brand">
        <PawPrint size={22} />
      </span>
      {label}
    </div>
  );
}

export function Notice({ tone = 'success', children, className }) {
  return (
    <div
      role={tone === 'error' ? 'alert' : 'status'}
      className={cx(
        'flex items-start gap-3 rounded-[14px] px-4.5 py-3.5 text-[15px] font-semibold',
        tone === 'error' ? 'bg-black text-white' : 'bg-brand-tint text-brand-dark',
        className,
      )}
    >
      {children}
    </div>
  );
}

export function ErrorMessage({ error, onRetry }) {
  if (!error) return null;
  return (
    <Notice tone="error">
      <span className="flex-1">{error.message || String(error)}</span>
      {onRetry && (
        <button type="button" onClick={onRetry} className="cursor-pointer font-bold text-white underline">
          Try again
        </button>
      )}
    </Notice>
  );
}

export function EmptyState({ title, children, action }) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-card border-2 border-dashed border-line px-6 py-12 text-center">
      <span className="flex text-brand">
        <PawPrint size={32} rotate={-12} />
      </span>
      <h3 className="text-lg font-bold">{title}</h3>
      {children && <p className="max-w-110 text-muted">{children}</p>}
      {action}
    </div>
  );
}
