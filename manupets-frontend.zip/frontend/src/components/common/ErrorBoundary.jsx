import { Component } from 'react';
import safeStorage from '../../utils/safeStorage';

// Shows the error instead of a blank white page if something crashes.
export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidCatch(error, info) {
    // Visible in the browser console (F12) for debugging
    console.error('App crashed:', error, info?.componentStack);
  }

  handleReset = () => {
    safeStorage.remove('manupets_session_user_id');
    window.location.assign('/');
  };

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <main className="mx-auto flex min-h-screen max-w-xl flex-col justify-center gap-4 px-6">
        <h1 className="text-3xl font-extrabold tracking-tight">Something broke on this page</h1>
        <p className="text-muted">Copy the message below for whoever is fixing it, then reload.</p>
        <pre className="overflow-x-auto rounded-[14px] bg-black p-4 text-sm whitespace-pre-wrap text-white">
          {String(this.state.error?.message || this.state.error)}
        </pre>
        <div className="flex gap-3">
          <button type="button" onClick={() => window.location.reload()}
            className="min-h-11 cursor-pointer rounded-full border-2 border-brand bg-brand px-5 font-bold text-white">
            Reload
          </button>
          <button type="button" onClick={this.handleReset}
            className="min-h-11 cursor-pointer rounded-full border-2 border-black bg-white px-5 font-bold">
            Log out and start over
          </button>
        </div>
      </main>
    );
  }
}
