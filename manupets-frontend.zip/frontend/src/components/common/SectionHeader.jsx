import { Link } from 'react-router-dom';
import { PawPrint } from './Illustrations';

// Section title with a paw and an optional "See all" link
export default function SectionHeader({ title, linkTo, linkLabel, as: H = 'h2' }) {
  return (
    <div className="flex items-end justify-between gap-4">
      <H className="flex items-center gap-2.5 text-[22px] font-extrabold tracking-tight md:text-[26px]">
        <span className="flex text-brand">
          <PawPrint size={22} rotate={-15} />
        </span>
        {title}
      </H>
      {linkTo && (
        <Link to={linkTo} className="font-bold">
          {linkLabel}
        </Link>
      )}
    </div>
  );
}
