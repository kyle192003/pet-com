import cx from '../../utils/cx';

const TONES = {
  default: 'bg-white border border-black/15',
  dark: 'bg-black text-white border border-black',
  tint: 'bg-brand-tint border border-transparent',
  outlined: 'bg-white border-2 border-black',
};

// <Card padded>...</Card>  <Card as="article" tone="dark">...</Card>
export default function Card({ as: Tag = 'div', tone = 'default', padded = false, className, children, ...rest }) {
  return (
    <Tag className={cx('rounded-card', TONES[tone], padded && 'p-6', className)} {...rest}>
      {children}
    </Tag>
  );
}

const TAG_TONES = {
  tint: 'bg-brand-tint text-brand-dark',
  solid: 'bg-brand text-white',
  dark: 'bg-black text-white',
  outline: 'bg-white text-black border border-black/40 font-semibold',
  onband: 'bg-white text-brand-dark',
};

// Small pill label: <Tag tone="solid">Free</Tag>
export function Tag({ tone = 'tint', className, children }) {
  return (
    <span className={cx('inline-flex items-center gap-1.5 self-start whitespace-nowrap rounded-full px-2.5 py-1 text-[13px] font-bold', TAG_TONES[tone], className)}>
      {children}
    </span>
  );
}

// Icon inside a light green circle
export function IconCircle({ size = 'md', children }) {
  return (
    <span className={cx('flex shrink-0 items-center justify-center rounded-full bg-brand-tint text-brand', size === 'lg' ? 'size-14' : 'size-12')}>
      {children}
    </span>
  );
}

// Icon + text row
export function Meta({ icon, children }) {
  return (
    <div className="flex items-center gap-2 text-sm [&>svg]:text-brand">
      {icon}
      <span>{children}</span>
    </div>
  );
}

// Black date badge: OCT / 17
export function DateBlock({ month, day, small = false }) {
  return (
    <div className={cx('flex shrink-0 flex-col items-center justify-center rounded-[14px] bg-black text-white', small ? 'w-14 py-2' : 'w-21 py-3')}>
      <span className="text-[13px] font-bold">{month}</span>
      <b className={cx('font-extrabold leading-none', small ? 'text-[22px]' : 'text-[32px]')}>{day}</b>
    </div>
  );
}
