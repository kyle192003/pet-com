import { Link } from 'react-router-dom';
import cx from '../../utils/cx';

const BASE =
  'inline-flex items-center justify-center gap-2 rounded-full border-2 font-bold whitespace-nowrap no-underline transition-colors cursor-pointer disabled:cursor-not-allowed disabled:opacity-50';

const VARIANTS = {
  primary: 'border-brand bg-brand text-white hover:border-brand-dark hover:bg-brand-dark hover:text-white',
  ghost: 'border-black bg-white text-black hover:bg-black hover:text-white',
  light: 'border-white bg-white text-brand-dark hover:bg-brand-tint hover:text-brand-dark',
  onband: 'border-white bg-transparent text-white hover:bg-white hover:text-brand-dark',
  danger: 'border-line-strong bg-white text-black hover:border-black hover:bg-black hover:text-white',
};

const SIZES = {
  sm: 'min-h-9 px-3.5 text-sm',
  md: 'min-h-11 px-5 text-[15px]',
  lg: 'min-h-13 px-7 text-base',
};

// <Button variant="ghost" size="sm" to="/pets">See pets</Button>
export default function Button({ variant = 'primary', size = 'md', full = false, to, className, children, type = 'button', ...rest }) {
  const classes = cx(BASE, VARIANTS[variant], SIZES[size], full && 'w-full', className);
  if (to) {
    return (
      <Link to={to} className={classes} {...rest}>
        {children}
      </Link>
    );
  }
  return (
    <button type={type} className={classes} {...rest}>
      {children}
    </button>
  );
}
