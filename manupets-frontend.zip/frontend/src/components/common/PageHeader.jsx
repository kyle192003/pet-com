import { Link } from 'react-router-dom';
import { PawTrail, PetPair } from './Illustrations';
import cx from '../../utils/cx';

const BAND_TRAIL = [
  { left: 790, top: 168, rotate: 55 },
  { left: 836, top: 118, rotate: 65 },
  { left: 806, top: 64, rotate: 50 },
  { left: 856, top: 18, rotate: 70 },
];

// Green page header with paw trail and peeking dog + cat.
// crumbs: [{ label, to }], tags / actions: React nodes
export default function PageHeader({ title, subtitle, crumbs, tags, actions, pets = true, className, children }) {
  return (
    <header
      className={cx(
        'relative overflow-hidden rounded-b-3xl bg-brand px-6 pt-11 pb-12 text-white sm:rounded-b-[32px] md:px-12 lg:min-h-59',
        className,
      )}
    >
      <PawTrail spots={BAND_TRAIL} className="hidden lg:block" />
      {pets && (
        <span className="pointer-events-none absolute -bottom-8.5 right-6 z-[1] hidden origin-bottom-right scale-75 md:flex lg:right-14 lg:scale-100">
          <PetPair />
        </span>
      )}
      <div className="relative z-[2] max-w-180">
        {crumbs && (
          <nav aria-label="Breadcrumb" className="mb-3.5 text-sm">
            {crumbs.map((c, i) => (
              <span key={c.label}>
                {i > 0 && ' / '}
                {c.to ? (
                  <Link to={c.to} className="text-white underline hover:text-white">
                    {c.label}
                  </Link>
                ) : (
                  <span aria-current="page">{c.label}</span>
                )}
              </span>
            ))}
          </nav>
        )}
        {tags && <div className="mb-4 flex flex-wrap gap-2">{tags}</div>}
        <h1 className="text-3xl leading-[1.06] font-extrabold tracking-tight sm:text-4xl lg:text-[46px]">{title}</h1>
        {subtitle && <p className="mt-3 max-w-150 text-lg leading-normal">{subtitle}</p>}
        {actions && <div className="mt-6 flex flex-wrap gap-3">{actions}</div>}
        {children}
      </div>
    </header>
  );
}
