import cx from '../../utils/cx';

// Standard page content width and spacing
export default function PageContainer({ as: Tag = 'main', className, children }) {
  return (
    <Tag id="main" className={cx('mx-auto flex w-full max-w-7xl flex-col gap-8 px-6 py-10 md:px-12', className)}>
      {children}
    </Tag>
  );
}
