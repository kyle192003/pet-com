import { useState } from 'react';
import Card, { Tag, IconCircle } from '../common/Card';
import Button from '../common/Button';
import Icon from '../common/Icons';
import DataTable from '../common/DataTable';
import { TextField, ChipGroup } from '../common/FormField';
import { Loading, ErrorMessage, Notice } from '../common/Feedback';
import useFetch from '../../hooks/useFetch';
import { getMyPolicies, enrollPet } from '../../api/insurance.api';
import { cap, fmtShortDate } from '../../utils/format';

// Placeholder coverage details. Replace [bracketed] values with the real plan terms.
const COVERAGE = [
  { icon: 'shield', title: 'Coverage limit', text: 'Up to [₱ amount] per year for illness, accidents and surgery.' },
  { icon: 'paw', title: 'Eligible pets', text: 'Dogs and cats, [min age] to [max age] old.' },
  { icon: 'check', title: 'Basic requirements', text: 'Active Manulife employee, up-to-date anti-rabies vaccination, pet registered with the city.' },
];

const STATUS_TONE = { active: 'solid', pending: 'outline', expired: 'dark' };
const EMPTY = { pet_name: '', species: 'dog', age_years: '', breed: '' };

// Info cards + enrollment form + "Your pets under insurance" (section 9.1)
export default function PetInsurancePage() {
  const { data: policies, loading, error, reload } = useFetch(() => getMyPolicies(), []);
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState(null);
  const [busy, setBusy] = useState(false);

  const update = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    const found = {};
    if (!form.pet_name.trim()) found.pet_name = "Enter your pet's name.";
    if (form.age_years === '' || Number(form.age_years) < 0) found.age_years = 'Enter an age in years.';
    if (!form.breed.trim()) found.breed = 'Enter a breed, or "Aspin" / "Puspin".';
    setErrors(found);
    if (Object.keys(found).length) return;
    setBusy(true);
    setMessage(null);
    try {
      const policy = await enrollPet({ ...form, age_years: Number(form.age_years) });
      setMessage({ tone: 'success', text: `${policy.pet_name} is enrolled. The policy is pending review.` });
      setForm(EMPTY);
      reload();
    } catch (err) {
      setMessage({ tone: 'error', text: err.message });
    } finally {
      setBusy(false);
    }
  };

  const columns = [
    { key: 'pet_name', label: 'Pet', render: (p) => <b>{p.pet_name}</b> },
    { key: 'species', label: 'Species', render: (p) => cap(p.species) },
    { key: 'breed', label: 'Breed' },
    { key: 'age_years', label: 'Age' },
    { key: 'created_at', label: 'Enrolled', render: (p) => fmtShortDate(p.created_at) },
    { key: 'policy_status', label: 'Status', render: (p) => <Tag tone={STATUS_TONE[p.policy_status]}>{cap(p.policy_status)}</Tag> },
  ];

  return (
    <div className="flex flex-col gap-8">
      <div className="grid gap-5 md:grid-cols-3">
        {COVERAGE.map((c) => (
          <Card as="article" key={c.title} className="flex flex-col gap-3 p-6">
            <IconCircle size="lg">
              <Icon name={c.icon} size={28} />
            </IconCircle>
            <h3 className="text-[19px] font-bold">{c.title}</h3>
            <p className="text-[15px] leading-normal">{c.text}</p>
          </Card>
        ))}
      </div>

      <div className="grid items-start gap-6 lg:grid-cols-[1fr_1.2fr]">
        <Card as="form" onSubmit={handleSubmit} noValidate className="flex flex-col gap-4.5 p-7">
          <h2 className="text-[22px] font-extrabold">Enroll a pet</h2>
          {message && <Notice tone={message.tone}>{message.text}</Notice>}
          <TextField id="in-name" name="pet_name" label="Pet name" placeholder="e.g. Mango" value={form.pet_name} onChange={update} error={errors.pet_name} />
          <ChipGroup label="Species" value={form.species} onChange={(v) => setForm((f) => ({ ...f, species: v }))}
            options={[{ value: 'dog', label: 'Dog' }, { value: 'cat', label: 'Cat' }]} />
          <div className="grid gap-4 sm:grid-cols-2">
            <TextField id="in-age" name="age_years" type="number" min="0" step="0.5" label="Age (years)" placeholder="e.g. 2"
              value={form.age_years} onChange={update} error={errors.age_years} />
            <TextField id="in-breed" name="breed" label="Breed" placeholder="e.g. Aspin" value={form.breed} onChange={update} error={errors.breed} />
          </div>
          <Button type="submit" full disabled={busy}>
            {busy ? 'Enrolling…' : 'Enroll my pet'}
          </Button>
          <p className="text-sm text-muted">Enrollments are reviewed before the policy becomes active.</p>
        </Card>

        <Card as="section" className="flex flex-col gap-4 p-7">
          <h2 className="text-[22px] font-extrabold">Your pets under insurance</h2>
          <ErrorMessage error={error} onRetry={reload} />
          {loading ? <Loading /> : <DataTable columns={columns} rows={policies || []} empty="You haven't enrolled a pet yet." />}
        </Card>
      </div>
    </div>
  );
}
