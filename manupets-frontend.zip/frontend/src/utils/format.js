// Small display helpers shared across components.

const asDate = (d) => (d instanceof Date ? d : new Date(String(d).length <= 10 ? `${d}T00:00:00` : d));

export const fmtDate = (d, opts = { weekday: 'short', month: 'short', day: 'numeric' }) =>
  d ? asDate(d).toLocaleDateString('en-US', opts) : '';

export const fmtLongDate = (d) =>
  fmtDate(d, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });

export const fmtShortDate = (d) => fmtDate(d, { month: 'short', day: 'numeric', year: 'numeric' });

export const fmtTime = (t) => {
  if (!t) return '';
  const [h, m] = t.split(':').map(Number);
  const ap = h >= 12 ? 'PM' : 'AM';
  return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${ap}`;
};

export const timeRange = (a, b) => `${fmtTime(a)} – ${fmtTime(b)}`;

export const monthShort = (d) => asDate(d).toLocaleDateString('en-US', { month: 'short' }).toUpperCase();
export const dayNum = (d) => asDate(d).getDate();

export const cap = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : '');

export const ageLabel = (years) => {
  const y = Number(years);
  if (Number.isNaN(y)) return '';
  if (y < 1) return `${Math.max(1, Math.round(y * 12))} mos`;
  return `${y} yr${y === 1 ? '' : 's'}`;
};

export const EVENT_TYPES = {
  fun_run: 'Fun run',
  adoption_day: 'Adoption day',
  volunteer: 'Volunteer',
  recreational: 'Recreational',
};

export const PET_TYPES = { dog: 'Dogs', cat: 'Cats', both: 'Dogs and cats' };

export const initials = (name = '') =>
  name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0].toUpperCase())
    .join('');
