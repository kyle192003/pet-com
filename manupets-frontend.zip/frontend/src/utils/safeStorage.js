// localStorage wrapper that never throws.
// Some browsers and work laptops block storage; the app keeps working without it.
const safeStorage = {
  get(key) {
    try {
      return window.localStorage.getItem(key);
    } catch {
      return null;
    }
  },
  set(key, value) {
    try {
      window.localStorage.setItem(key, String(value));
    } catch {
      /* storage blocked: ignore */
    }
  },
  remove(key) {
    try {
      window.localStorage.removeItem(key);
    } catch {
      /* storage blocked: ignore */
    }
  },
};

export default safeStorage;
