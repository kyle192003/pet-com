import useAuth from './useAuth';
import { ROLES } from '../config';

// Role helpers: admin / employee / makatizen
export default function useUserRole() {
  const { user } = useAuth();
  const role = user?.role ?? 'guest';
  return {
    role,
    isGuest: !user,
    isAdmin: role === ROLES.ADMIN,
    isEmployee: role === ROLES.EMPLOYEE,
    isMakatizen: role === ROLES.MAKATIZEN,
    hasRole: (...roles) => roles.includes(role),
  };
}
