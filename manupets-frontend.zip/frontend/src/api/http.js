// Axios instance for all calls to the Express backend.
import axios from 'axios';
import { API_URL, TOKEN_KEY } from '../config';

const http = axios.create({
  baseURL: API_URL,
  headers: { 'Content-Type': 'application/json' },
});

// Attach the JWT (if any) to every request
http.interceptors.request.use((config) => {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Turn backend errors into plain Error objects with a readable message
http.interceptors.response.use(
  (res) => res,
  (err) => {
    const message = err.response?.data?.message || err.message || 'Something went wrong. Try again.';
    const error = new Error(message);
    error.status = err.response?.status;
    return Promise.reject(error);
  },
);

// Helper: return only the response body
export const unwrap = (promise) => promise.then((res) => res.data);

export default http;
