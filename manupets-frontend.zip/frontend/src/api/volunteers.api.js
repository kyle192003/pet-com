import http, { unwrap } from './http';
import { USE_MOCK } from '../config';
import { db, save, delay, nextId, fail, currentUser } from './mockDb';
import { getEvents } from './events.api';

// GET /volunteers/opportunities?hoursEligibleOnly=
export async function getOpportunities({ hoursEligibleOnly = false } = {}) {
  if (!USE_MOCK) return unwrap(http.get('/volunteers/opportunities', { params: { hoursEligibleOnly } }));
  return getEvents({ volunteerOnly: true, hoursEligibleOnly });
}

// POST /volunteers/roles/:roleId/signup
export async function signUpForRole(roleId) {
  if (!USE_MOCK) return unwrap(http.post(`/volunteers/roles/${roleId}/signup`));
  await delay();
  const user = currentUser();
  if (!user) fail('Log in to sign up as a volunteer.', 401);
  const s = db();
  const role = s.volunteer_roles.find((r) => r.id === Number(roleId));
  if (!role) fail('This volunteer role no longer exists.', 404);
  if (s.volunteer_assignments.some((a) => a.volunteer_role_id === role.id && a.user_id === user.id)) {
    fail("You're already signed up for this role.", 409);
  }
  if (role.slots_available <= 0) fail('This role is full. Pick another role.', 409);
  role.slots_available -= 1;
  s.volunteer_assignments.push({
    id: nextId(s.volunteer_assignments),
    volunteer_role_id: role.id,
    user_id: user.id,
    status: 'assigned',
    hours_earned: 0,
  });
  save();
  return role;
}

// GET /volunteers/assignments/me
export async function getMyAssignments() {
  if (!USE_MOCK) return unwrap(http.get('/volunteers/assignments/me'));
  await delay(100);
  const user = currentUser();
  if (!user) return [];
  return db().volunteer_assignments.filter((a) => a.user_id === user.id);
}

// GET /volunteers/me/summary -> { total_hours, completed, upcoming, goal_hours }
export async function getMyVolunteerSummary() {
  if (!USE_MOCK) return unwrap(http.get('/volunteers/me/summary'));
  await delay();
  const user = currentUser();
  if (!user) fail('Log in to see your volunteer hours.', 401);
  const s = db();
  const volunteer = s.volunteers.find((v) => v.user_id === user.id);
  const mine = s.volunteer_assignments.filter((a) => a.user_id === user.id);
  return {
    total_hours: volunteer?.total_volunteer_hours ?? 0,
    completed: mine.filter((a) => a.status === 'completed').length,
    upcoming: mine.filter((a) => a.status === 'assigned').length,
    goal_hours: 40, // [placeholder] yearly goal, set by the program
  };
}

// GET /volunteers (admin)
export async function getVolunteers() {
  if (!USE_MOCK) return unwrap(http.get('/volunteers'));
  await delay();
  return db().volunteers;
}
