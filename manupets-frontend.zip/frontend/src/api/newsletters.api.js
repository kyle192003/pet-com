import http, { unwrap } from './http';
import { USE_MOCK } from '../config';
import { db, save, delay, nextId, nowIso, fail, currentUser } from './mockDb';

const requireAdmin = () => {
  const u = currentUser();
  if (!u || u.role !== 'admin') fail('Only admins can do this.', 403);
  return u;
};

const byNewest = (a, b) => (b.published_at || '9999').localeCompare(a.published_at || '9999');

// GET /newsletters?includeDrafts=
export async function getNewsletters({ includeDrafts = false } = {}) {
  if (!USE_MOCK) return unwrap(http.get('/newsletters', { params: { includeDrafts } }));
  await delay();
  return db()
    .newsletters.filter((n) => includeDrafts || n.published_at)
    .slice()
    .sort(byNewest);
}

// GET /newsletters/:id
export async function getNewsletter(id) {
  if (!USE_MOCK) return unwrap(http.get(`/newsletters/${id}`));
  await delay();
  const item = db().newsletters.find((n) => n.id === Number(id));
  if (!item) fail('This newsletter no longer exists.', 404);
  return item;
}

// POST /newsletters  { title, summary, body, publish } (admin)
export async function createNewsletter({ publish, ...data }) {
  if (!USE_MOCK) return unwrap(http.post('/newsletters', { ...data, publish }));
  await delay();
  const admin = requireAdmin();
  const s = db();
  const item = {
    ...data,
    id: nextId(s.newsletters),
    author_user_id: admin.id,
    published_at: publish ? nowIso() : null,
  };
  s.newsletters.push(item);
  save();
  return item;
}

// PUT /newsletters/:id  { title, summary, body, publish } (admin)
export async function updateNewsletter(id, { publish, ...data }) {
  if (!USE_MOCK) return unwrap(http.put(`/newsletters/${id}`, { ...data, publish }));
  await delay();
  requireAdmin();
  const item = db().newsletters.find((n) => n.id === Number(id));
  if (!item) fail('This newsletter no longer exists.', 404);
  Object.assign(item, data);
  if (publish && !item.published_at) item.published_at = nowIso();
  if (publish === false) item.published_at = null;
  save();
  return item;
}

// DELETE /newsletters/:id (admin)
export async function deleteNewsletter(id) {
  if (!USE_MOCK) return unwrap(http.delete(`/newsletters/${id}`));
  await delay();
  requireAdmin();
  const s = db();
  s.newsletters = s.newsletters.filter((n) => n.id !== Number(id));
  save();
  return { ok: true };
}
