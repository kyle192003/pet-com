import http, { unwrap } from './http';
import { USE_MOCK } from '../config';
import { db, save, delay, nextId, nowIso, fail, currentUser } from './mockDb';

const requireEmployee = () => {
  const u = currentUser();
  if (!u || u.role !== 'employee') fail('Pet insurance is for Manulife employees only.', 403);
  return u;
};

// GET /insurance/policies/me
export async function getMyPolicies() {
  if (!USE_MOCK) return unwrap(http.get('/insurance/policies/me'));
  await delay();
  const u = requireEmployee();
  return db()
    .pet_insurance_policies.filter((p) => p.user_id === u.id)
    .slice()
    .sort((a, b) => b.created_at.localeCompare(a.created_at));
}

// POST /insurance/policies  { pet_name, species, breed, age_years }
export async function enrollPet(data) {
  if (!USE_MOCK) return unwrap(http.post('/insurance/policies', data));
  await delay();
  const u = requireEmployee();
  const s = db();
  const policy = {
    ...data,
    id: nextId(s.pet_insurance_policies),
    user_id: u.id,
    policy_status: 'pending',
    created_at: nowIso(),
  };
  s.pet_insurance_policies.push(policy);
  save();
  return policy;
}
