import http, { unwrap } from './http';
import { USE_MOCK } from '../config';
import { db, save, delay, nextId, fail, currentUser } from './mockDb';

const requireAdmin = () => {
  const u = currentUser();
  if (!u || u.role !== 'admin') fail('Only admins can do this.', 403);
  return u;
};

// GET /services?type=free|discounted&petType=dog|cat
export async function getServices(filters = {}) {
  if (!USE_MOCK) return unwrap(http.get('/services', { params: filters }));
  await delay();
  let list = db().services;
  if (filters.type) list = list.filter((s) => s.service_type === filters.type);
  if (filters.petType) list = list.filter((s) => s.pet_type === filters.petType || s.pet_type === 'both');
  return list;
}

// POST /services (admin)
export async function createService(data) {
  if (!USE_MOCK) return unwrap(http.post('/services', data));
  await delay();
  const admin = requireAdmin();
  const s = db();
  const service = { ...data, id: nextId(s.services), created_by_user_id: admin.id };
  s.services.push(service);
  save();
  return service;
}

// PUT /services/:id (admin)
export async function updateService(id, data) {
  if (!USE_MOCK) return unwrap(http.put(`/services/${id}`, data));
  await delay();
  requireAdmin();
  const service = db().services.find((s) => s.id === Number(id));
  if (!service) fail('This service no longer exists.', 404);
  Object.assign(service, data);
  save();
  return service;
}

// DELETE /services/:id (admin)
export async function deleteService(id) {
  if (!USE_MOCK) return unwrap(http.delete(`/services/${id}`));
  await delay();
  requireAdmin();
  const s = db();
  s.services = s.services.filter((x) => x.id !== Number(id));
  save();
  return { ok: true };
}
