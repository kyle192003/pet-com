import http, { unwrap } from './http';
import { USE_MOCK } from '../config';
import { db, save, delay, nextId, nowIso, fail, currentUser } from './mockDb';

const withPet = (app) => {
  const pet = db().pets.find((p) => p.id === app.pet_id);
  return { ...app, pet_name: pet?.name ?? 'Unknown pet', pet_species: pet?.species };
};

// POST /adoptions
// body: pet_id, applicant_name, applicant_email, applicant_phone, address,
//       residence_type, experience_notes, agreed_to_terms
export async function submitApplication(data) {
  if (!USE_MOCK) return unwrap(http.post('/adoptions', data));
  await delay();
  const user = currentUser();
  const s = db();
  const pet = s.pets.find((p) => p.id === Number(data.pet_id));
  if (!pet) fail('This pet is no longer listed.', 404);
  if (pet.status === 'adopted') fail(`${pet.name} has already been adopted.`, 409);
  const app = {
    ...data,
    pet_id: pet.id,
    id: nextId(s.adoption_applications),
    user_id: user?.id ?? null,
    status: 'pending',
    admin_notes: '',
    created_at: nowIso(),
  };
  s.adoption_applications.push(app);
  save();
  return withPet(app);
}

// GET /adoptions?status= (admin)
export async function getApplications({ status } = {}) {
  if (!USE_MOCK) return unwrap(http.get('/adoptions', { params: { status } }));
  await delay();
  let list = db().adoption_applications;
  if (status) list = list.filter((a) => a.status === status);
  return list
    .slice()
    .sort((a, b) => b.created_at.localeCompare(a.created_at))
    .map(withPet);
}

// PATCH /adoptions/:id  { status, admin_notes } (admin)
// Approving marks the pet as adopted.
export async function updateApplication(id, { status, admin_notes }) {
  if (!USE_MOCK) return unwrap(http.patch(`/adoptions/${id}`, { status, admin_notes }));
  await delay();
  const u = currentUser();
  if (!u || u.role !== 'admin') fail('Only admins can review applications.', 403);
  const s = db();
  const app = s.adoption_applications.find((a) => a.id === Number(id));
  if (!app) fail('This application no longer exists.', 404);
  if (status) app.status = status;
  if (admin_notes !== undefined) app.admin_notes = admin_notes;
  if (status === 'approved') {
    const pet = s.pets.find((p) => p.id === app.pet_id);
    if (pet) pet.status = 'adopted';
  }
  save();
  return withPet(app);
}
