import http, { unwrap } from './http';
import { USE_MOCK } from '../config';
import { db, save, delay, nextId, fail, currentUser } from './mockDb';

const AGE_GROUPS = {
  under1: (y) => y < 1,
  '1to5': (y) => y >= 1 && y <= 5,
  over5: (y) => y > 5,
};

const requireAdmin = () => {
  const u = currentUser();
  if (!u || u.role !== 'admin') fail('Only admins can do this.', 403);
};

// GET /pets?species=&size=&age=&status=&includeArchived=
export async function getPets(filters = {}) {
  if (!USE_MOCK) return unwrap(http.get('/pets', { params: filters }));
  await delay();
  let list = db().pets.filter((p) => filters.includeArchived || p.status !== 'archived');
  if (filters.species) list = list.filter((p) => p.species === filters.species);
  if (filters.size) list = list.filter((p) => p.size === filters.size);
  if (filters.status) list = list.filter((p) => p.status === filters.status);
  if (filters.age && AGE_GROUPS[filters.age]) list = list.filter((p) => AGE_GROUPS[filters.age](p.age_years));
  return list;
}

// GET /pets/:id -> pet with { medical } from pet_medical_info
export async function getPet(id) {
  if (!USE_MOCK) return unwrap(http.get(`/pets/${id}`));
  await delay();
  const s = db();
  const pet = s.pets.find((p) => p.id === Number(id));
  if (!pet) fail('This pet is no longer listed.', 404);
  const medical = s.pet_medical_info.find((m) => m.pet_id === pet.id) || null;
  return { ...pet, medical };
}

// POST /pets (admin)
export async function createPet(data) {
  if (!USE_MOCK) return unwrap(http.post('/pets', data));
  await delay();
  requireAdmin();
  const s = db();
  const pet = {
    photo_url: '',
    temperament: '',
    rescued_location: '',
    ...data,
    id: nextId(s.pets),
    date_listed: new Date().toISOString().slice(0, 10),
  };
  s.pets.push(pet);
  save();
  return pet;
}

// PUT /pets/:id (admin)
export async function updatePet(id, data) {
  if (!USE_MOCK) return unwrap(http.put(`/pets/${id}`, data));
  await delay();
  requireAdmin();
  const pet = db().pets.find((p) => p.id === Number(id));
  if (!pet) fail('This pet is no longer listed.', 404);
  Object.assign(pet, data);
  save();
  return pet;
}

// PATCH /pets/:id/archive (admin)
export async function archivePet(id) {
  if (!USE_MOCK) return unwrap(http.patch(`/pets/${id}/archive`));
  return updatePet(id, { status: 'archived' });
}
