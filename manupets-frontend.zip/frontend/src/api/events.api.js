import http, { unwrap } from './http';
import { USE_MOCK } from '../config';
import { db, save, delay, nextId, nowIso, fail, currentUser } from './mockDb';

// Adds registration counts and volunteer roles, like the backend's JOINs would
function toPublic(event) {
  const s = db();
  const regs = s.event_registrations.filter((r) => r.event_id === event.id && r.status !== 'cancelled');
  const roles = s.volunteer_roles.filter((r) => r.event_id === event.id);
  const { _seed_volunteers = 0, _seed_participants = 0, ...rest } = event;
  return {
    ...rest,
    volunteer_count: _seed_volunteers + regs.filter((r) => r.role_at_event === 'volunteer').length,
    participant_count: _seed_participants + regs.filter((r) => r.role_at_event === 'participant').length,
    volunteer_slots_left: roles.reduce((n, r) => n + r.slots_available, 0),
    volunteer_roles: roles,
  };
}

const requireAdmin = () => {
  const u = currentUser();
  if (!u || u.role !== 'admin') fail('Only admins can do this.', 403);
  return u;
};

// GET /events?type=&from=&to=&location=&volunteerOnly=&hoursEligibleOnly=&includeInactive=
export async function getEvents(filters = {}) {
  if (!USE_MOCK) return unwrap(http.get('/events', { params: filters }));
  await delay();
  let list = db().events.filter((e) => filters.includeInactive || e.is_active);
  if (filters.type) list = list.filter((e) => e.event_type === filters.type);
  if (filters.from) list = list.filter((e) => e.date >= filters.from);
  if (filters.to) list = list.filter((e) => e.date <= filters.to);
  if (filters.location) list = list.filter((e) => e.location === filters.location);
  if (filters.volunteerOnly) list = list.filter((e) => e.is_volunteer_event);
  if (filters.hoursEligibleOnly) list = list.filter((e) => e.is_hours_eligible);
  return list
    .slice()
    .sort((a, b) => a.date.localeCompare(b.date))
    .map(toPublic);
}

// GET /events/:id
export async function getEvent(id) {
  if (!USE_MOCK) return unwrap(http.get(`/events/${id}`));
  await delay();
  const event = db().events.find((e) => e.id === Number(id));
  if (!event) fail('This event no longer exists.', 404);
  return toPublic(event);
}

// POST /events (admin)
export async function createEvent(data) {
  if (!USE_MOCK) return unwrap(http.post('/events', data));
  await delay();
  const admin = requireAdmin();
  const s = db();
  const event = { ...data, id: nextId(s.events), created_by_user_id: admin.id, created_at: nowIso() };
  s.events.push(event);
  save();
  return toPublic(event);
}

// PUT /events/:id (admin)
export async function updateEvent(id, data) {
  if (!USE_MOCK) return unwrap(http.put(`/events/${id}`, data));
  await delay();
  requireAdmin();
  const event = db().events.find((e) => e.id === Number(id));
  if (!event) fail('This event no longer exists.', 404);
  Object.assign(event, data);
  save();
  return toPublic(event);
}

// DELETE /events/:id (admin)
export async function deleteEvent(id) {
  if (!USE_MOCK) return unwrap(http.delete(`/events/${id}`));
  await delay();
  requireAdmin();
  const s = db();
  s.events = s.events.filter((e) => e.id !== Number(id));
  save();
  return { ok: true };
}

// POST /events/:id/register  { role_at_event: 'volunteer' | 'participant' }
export async function registerForEvent(eventId, roleAtEvent) {
  if (!USE_MOCK) return unwrap(http.post(`/events/${eventId}/register`, { role_at_event: roleAtEvent }));
  await delay();
  const user = currentUser();
  if (!user) fail('Log in to register for this event.', 401);
  const s = db();
  const event = s.events.find((e) => e.id === Number(eventId));
  if (!event) fail('This event no longer exists.', 404);
  const existing = s.event_registrations.find(
    (r) => r.event_id === event.id && r.user_id === user.id && r.status !== 'cancelled',
  );
  if (existing) fail(`You're already registered as a ${existing.role_at_event}.`, 409);
  s.event_registrations.push({
    id: nextId(s.event_registrations),
    event_id: event.id,
    user_id: user.id,
    role_at_event: roleAtEvent,
    status: 'confirmed',
    hours_credited: 0,
  });
  save();
  return toPublic(event);
}

// GET /events/registrations/me
export async function getMyRegistrations() {
  if (!USE_MOCK) return unwrap(http.get('/events/registrations/me'));
  await delay(100);
  const user = currentUser();
  if (!user) return [];
  return db().event_registrations.filter((r) => r.user_id === user.id && r.status !== 'cancelled');
}
