import http, { unwrap } from './http';
import { USE_MOCK } from '../config';
import { db, save, delay, nextId, nowIso, fail, currentUser, publicUser } from './mockDb';

// Demo logins shown on the login page in mock mode
export const DEMO_ACCOUNTS = [
  { label: 'Admin (Makati Gov)', email: 'admin@makati.gov.ph', password: 'admin123' },
  { label: 'Manulife employee', email: 'ana.reyes@manulife.com', password: 'employee123' },
  { label: 'Makatizen', email: 'juan@example.com', password: 'makatizen123' },
];

// POST /auth/login  { email, password } -> { token, user }
export async function login({ email, password }) {
  if (!USE_MOCK) return unwrap(http.post('/auth/login', { email, password }));
  await delay();
  const user = db().users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
  if (!user || user.password !== password) fail('Email or password is incorrect.', 401);
  return { token: `mock-token-${user.id}`, user: publicUser(user) };
}

// POST /auth/register -> { token, user }
// body: full_name, username, email, password, mobile_number, address,
//       wants_to_volunteer, preferred_pet_type, skills, availability_notes
export async function register(data) {
  if (!USE_MOCK) return unwrap(http.post('/auth/register', data));
  await delay();
  const s = db();
  if (s.users.some((u) => u.email.toLowerCase() === data.email.toLowerCase())) {
    fail('An account with this email already exists. Log in instead.', 409);
  }
  if (s.users.some((u) => u.username.toLowerCase() === data.username.toLowerCase())) {
    fail('This username is taken. Try another one.', 409);
  }
  const user = {
    id: nextId(s.users),
    role: 'makatizen',
    full_name: data.full_name,
    email: data.email,
    username: data.username,
    password: data.password,
    mobile_number: data.mobile_number,
    address: data.address,
    created_at: nowIso(),
  };
  s.users.push(user);
  if (data.wants_to_volunteer) {
    s.volunteers.push({
      id: nextId(s.volunteers),
      user_id: user.id,
      preferred_pet_type: data.preferred_pet_type,
      skills: data.skills,
      availability_notes: data.availability_notes,
      total_volunteer_hours: 0,
    });
  }
  save();
  return { token: `mock-token-${user.id}`, user: publicUser(user) };
}

// GET /auth/me -> user
export async function getMe() {
  if (!USE_MOCK) return unwrap(http.get('/auth/me'));
  await delay(100);
  const user = currentUser();
  if (!user) fail('Your session has ended. Log in again.', 401);
  return publicUser(user);
}
