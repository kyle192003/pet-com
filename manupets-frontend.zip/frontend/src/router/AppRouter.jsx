import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import useAuth from '../hooks/useAuth';
import useUserRole from '../hooks/useUserRole';
import HomePage from '../pages/HomePage';
import LoginPage from '../pages/LoginPage';
import RegisterPage from '../pages/RegisterPage';
import EventsPage from '../pages/EventsPage';
import VolunteerPage from '../pages/VolunteerPage';
import ServicesPage from '../pages/ServicesPage';
import PetsPage from '../pages/PetsPage';
import AdoptionPage from '../pages/AdoptionPage';
import NewsletterPage from '../pages/NewsletterPage';
import InsurancePage from '../pages/InsurancePage';
import AdminPage from '../pages/AdminPage';
import NotFoundPage from '../pages/NotFoundPage';

// Wrap a route to require login, and optionally specific roles
function RequireAuth({ roles, children }) {
  const { isLoggedIn } = useAuth();
  const { hasRole } = useUserRole();
  const location = useLocation();

  if (!isLoggedIn) return <Navigate to="/login" replace state={{ from: location.pathname + location.search }} />;
  if (roles && !hasRole(...roles)) return <Navigate to="/" replace />;
  return children;
}

export default function AppRouter() {
  return (
    <Routes>
      {/* Public */}
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/events" element={<EventsPage />} />
      <Route path="/events/:id" element={<EventsPage />} />
      <Route path="/volunteer" element={<VolunteerPage />} />
      <Route path="/services" element={<ServicesPage />} />
      <Route path="/pets" element={<PetsPage />} />
      <Route path="/pets/:id" element={<PetsPage />} />
      <Route path="/newsletters" element={<NewsletterPage />} />
      <Route path="/newsletters/:id" element={<NewsletterPage />} />

      {/* Logged in */}
      <Route path="/" element={<RequireAuth><HomePage /></RequireAuth>} />
      <Route path="/adopt/:petId" element={<RequireAuth roles={['makatizen', 'employee']}><AdoptionPage /></RequireAuth>} />
      <Route path="/insurance" element={<RequireAuth roles={['employee']}><InsurancePage /></RequireAuth>} />
      <Route path="/admin/:section" element={<RequireAuth roles={['admin']}><AdminPage /></RequireAuth>} />

      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}
