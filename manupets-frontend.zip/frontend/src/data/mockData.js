// Sample data for the frontend-only demo.
// Field names follow the planned PostgreSQL tables so the backend team can
// match them. Everything lives in memory and resets when the page reloads.

// Generic placeholder ID card for the sample applications (not a real ID design)
function sampleIdImage(name, idType) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="400" viewBox="0 0 640 400">
<rect width="640" height="400" rx="28" fill="#ffffff" stroke="#000" stroke-width="4"/>
<rect x="2" y="2" width="636" height="70" rx="26" fill="#008657"/>
<text x="32" y="47" font-family="Arial, sans-serif" font-size="26" font-weight="700" fill="#fff">SAMPLE ID · DEMO ONLY</text>
<rect x="32" y="104" width="170" height="210" rx="14" fill="#e6fff3" stroke="#008657" stroke-width="3"/>
<circle cx="117" cy="180" r="42" fill="#008657"/>
<path d="M57 300c8-44 34-66 60-66s52 22 60 66z" fill="#008657"/>
<text x="232" y="138" font-family="Arial, sans-serif" font-size="18" fill="#555">Name</text>
<text x="232" y="170" font-family="Arial, sans-serif" font-size="28" font-weight="700" fill="#000">${name}</text>
<text x="232" y="218" font-family="Arial, sans-serif" font-size="18" fill="#555">ID type</text>
<text x="232" y="248" font-family="Arial, sans-serif" font-size="24" fill="#000">${idType}</text>
<text x="232" y="296" font-family="Arial, sans-serif" font-size="18" fill="#555">No. XXXX-XXXX-0000</text>
</svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

const idFields = (name, type, label, status = 'unverified') => ({
  valid_id_type: type,
  valid_id_image: sampleIdImage(name, label),
  valid_id_file_name: `${name.toLowerCase().replace(/\s+/g, '-')}-id.png`,
  id_terms_accepted: true,
  privacy_consent: true,
  consent_at: '2026-10-10T08:00:00Z',
  terms_version: '2026-09',
  id_verification_status: status, // unverified | verified | mismatch
});

const SEED = {
  users: [
    // Demo only: passwords are plain text because there is no backend.
    { id: 1, role: 'admin', full_name: 'Makati Admin', email: 'admin@makati.gov.ph', username: 'makatiadmin', password: 'admin123', mobile_number: '', address: 'Makati City Hall', created_at: '2026-01-05T08:00:00Z' },
    { id: 2, role: 'employee', full_name: 'Ana Reyes', email: 'ana.reyes@manulife.com', username: 'anareyes', password: 'employee123', mobile_number: '0917 000 1111', address: '', created_at: '2026-02-11T08:00:00Z' },
    { id: 3, role: 'makatizen', full_name: 'Juan Dela Cruz', email: 'juan@example.com', username: 'juandc', password: 'makatizen123', mobile_number: '0917 123 4567', address: '123 J.P. Rizal Ave, Poblacion, Makati', created_at: '2026-03-02T08:00:00Z' },
  ],
  volunteers: [
    { id: 1, user_id: 2, preferred_pet_type: 'both', skills: 'Event marshal', availability_notes: 'Weekends', total_volunteer_hours: 18.5 },
    { id: 2, user_id: 3, preferred_pet_type: 'dog', skills: 'Dog walking', availability_notes: 'Saturday mornings', total_volunteer_hours: 6 },
    ...Array.from({ length: 126 }, (_, i) => ({ id: i + 3, user_id: 100 + i, preferred_pet_type: 'both', skills: '', availability_notes: '', total_volunteer_hours: 0 })),
  ],
  events: [
    { id: 101, title: 'Paws Fun Run 2026', description: 'Run a 3K or 5K route around Ayala Triangle with your dog, or come on your own and cheer. Every registration helps fund food, vaccines and medical care for rescued animals at the city shelter.\n\nDogs must be leashed and vaccinated. Water stations for pets are set up every kilometer, and shelter dogs will be at the finish line for anyone ready to adopt.', short_description: 'Run 3K or 5K with your dog. Proceeds support shelter care.', event_type: 'fun_run', date: '2026-10-17', start_time: '05:30', end_time: '09:00', location: 'Ayala Triangle Gardens', max_attendees: 300, created_by_user_id: 1, sponsor: 'Manulife', is_active: true, is_volunteer_event: true, is_hours_eligible: true, created_at: '2026-09-01T08:00:00Z', _seed_volunteers: 18, _seed_participants: 142 },
    { id: 102, title: 'Adoption Day at the Park', description: 'Meet dogs and cats ready for a home and talk to shelter staff about the adoption process. Bring a valid ID if you plan to apply on the day.', short_description: 'Meet dogs and cats ready for a home and talk to shelter staff.', event_type: 'adoption_day', date: '2026-10-25', start_time: '09:00', end_time: '15:00', location: 'Washington SyCip Park', max_attendees: 500, created_by_user_id: 1, sponsor: 'Manulife', is_active: true, is_volunteer_event: false, is_hours_eligible: false, created_at: '2026-09-03T08:00:00Z', _seed_volunteers: 0, _seed_participants: 96 },
    { id: 103, title: 'Shelter Clean-up Drive', description: 'Help clean kennels, sort donated food and supplies, and take the shelter dogs for short walks. Wear comfortable clothes you do not mind getting dirty.', short_description: 'Help clean kennels, sort donations and walk the dogs.', event_type: 'volunteer', date: '2026-11-07', start_time: '08:00', end_time: '12:00', location: 'Makati City Animal Shelter', max_attendees: 40, created_by_user_id: 1, sponsor: 'Manulife', is_active: true, is_volunteer_event: true, is_hours_eligible: true, created_at: '2026-09-05T08:00:00Z', _seed_volunteers: 20, _seed_participants: 0 },
    { id: 104, title: 'Meet & Greet: Senior Dogs', description: 'Spend a relaxed afternoon with older dogs who are looking for a quiet home. Shelter staff will share each dog\'s story and care needs.', short_description: 'Spend an afternoon with older dogs looking for a quiet home.', event_type: 'adoption_day', date: '2026-11-14', start_time: '13:00', end_time: '17:00', location: 'Poblacion Barangay Hall', max_attendees: 80, created_by_user_id: 1, sponsor: '', is_active: true, is_volunteer_event: true, is_hours_eligible: false, created_at: '2026-09-06T08:00:00Z', _seed_volunteers: 4, _seed_participants: 31 },
    { id: 105, title: 'Anti-Rabies Vaccination Day', description: 'City veterinarians will vaccinate dogs and cats for free. Volunteers help with registration, queueing and holding pets during vaccination.', short_description: 'Assist vets with registration and pet handling.', event_type: 'volunteer', date: '2026-11-22', start_time: '08:00', end_time: '14:00', location: 'Bel-Air Covered Court', max_attendees: 30, created_by_user_id: 1, sponsor: 'Manulife', is_active: true, is_volunteer_event: true, is_hours_eligible: true, created_at: '2026-09-08T08:00:00Z', _seed_volunteers: 22, _seed_participants: 0 },
    { id: 106, title: 'Cat Care Basics Workshop', description: 'A short class on feeding, litter training, grooming and when to see a vet. Great for first-time cat owners and new adopters.', short_description: 'A short class on feeding, litter training and vet visits.', event_type: 'recreational', date: '2026-11-28', start_time: '10:00', end_time: '12:00', location: 'Makati City Hall, Bldg. II', max_attendees: 60, created_by_user_id: 1, sponsor: '', is_active: false, is_volunteer_event: false, is_hours_eligible: false, created_at: '2026-09-10T08:00:00Z', _seed_volunteers: 0, _seed_participants: 12 },
  ],
  event_registrations: [],
  volunteer_roles: [
    { id: 1, event_id: 101, role_name: 'Registration booth', description: 'Check in runners and hand out race kits.', slots_available: 4 },
    { id: 2, event_id: 101, role_name: 'Dog handler', description: 'Help manage shelter dogs at the finish line.', slots_available: 6 },
    { id: 3, event_id: 101, role_name: 'Route marshal', description: 'Guide runners and keep the route safe.', slots_available: 2 },
    { id: 4, event_id: 103, role_name: 'Kennel cleaning', description: 'Clean and disinfect kennels.', slots_available: 10 },
    { id: 5, event_id: 103, role_name: 'Donation sorting', description: 'Sort donated food and supplies.', slots_available: 6 },
    { id: 6, event_id: 103, role_name: 'Dog walker', description: 'Walk shelter dogs around the compound.', slots_available: 4 },
    { id: 7, event_id: 105, role_name: 'Pet handler', description: 'Hold pets steady during vaccination.', slots_available: 5 },
    { id: 8, event_id: 105, role_name: 'Registration booth', description: 'Record pet owner details.', slots_available: 3 },
    { id: 9, event_id: 104, role_name: 'Photographer', description: 'Take adoption profile photos.', slots_available: 2 },
    { id: 10, event_id: 104, role_name: 'Adoption counselor', description: 'Talk visitors through the adoption process.', slots_available: 3 },
  ],
  volunteer_assignments: [
    { id: 1, volunteer_role_id: 4, user_id: 2, status: 'completed', hours_earned: 4 },
  ],
  pets: [
    { id: 142, name: 'Mango', species: 'dog', breed: 'Aspin', age_years: 2, gender: 'male', size: 'medium', description: 'Gentle, loves long walks and belly rubs.', temperament: 'Gentle and a little shy with strangers. Loves long walks, belly rubs and napping by the door. Gets along with other calm dogs.', photo_url: '', status: 'available', rescued_location: 'Barangay Poblacion', date_listed: '2026-09-30' },
    { id: 143, name: 'Luna', species: 'cat', breed: 'Puspin', age_years: 1, gender: 'female', size: 'small', description: 'Curious lap cat who follows you room to room.', temperament: 'Very social and curious. Will sit on your laptop. Fine with gentle kids.', photo_url: '', status: 'available', rescued_location: 'Barangay Bel-Air', date_listed: '2026-09-22' },
    { id: 144, name: 'Choco', species: 'dog', breed: 'Shih Tzu mix', age_years: 4, gender: 'male', size: 'small', description: 'Calm, good with kids, already house-trained.', temperament: 'Calm and patient. House-trained and used to apartment life.', photo_url: '', status: 'reserved', rescued_location: 'Barangay San Lorenzo', date_listed: '2026-08-14' },
    { id: 145, name: 'Mochi', species: 'cat', breed: 'Persian mix', age_years: 3, gender: 'female', size: 'small', description: 'Quiet and shy at first, then very affectionate.', temperament: 'Takes a few days to warm up, then loves to be brushed and held.', photo_url: '', status: 'available', rescued_location: 'Barangay Guadalupe Nuevo', date_listed: '2026-09-02' },
    { id: 146, name: 'Bantay', species: 'dog', breed: 'Aspin', age_years: 5, gender: 'male', size: 'large', description: 'Loyal watchdog, best as the only pet at home.', temperament: 'Protective and loyal. Needs a yard and an owner with dog experience.', photo_url: '', status: 'available', rescued_location: 'Barangay Pio del Pilar', date_listed: '2026-07-19' },
    { id: 147, name: 'Ube', species: 'cat', breed: 'Puspin', age_years: 0.7, gender: 'female', size: 'small', description: 'Playful kitten, needs toys and attention.', temperament: 'High energy kitten. Best with someone home most of the day.', photo_url: '', status: 'available', rescued_location: 'Barangay Poblacion', date_listed: '2026-09-18' },
    { id: 148, name: 'Kulot', species: 'dog', breed: 'Poodle mix', age_years: 2, gender: 'female', size: 'medium', description: 'Smart, energetic, learns tricks quickly.', temperament: 'Eager to please and quick to learn. Needs daily play.', photo_url: '', status: 'available', rescued_location: 'Barangay Palanan', date_listed: '2026-09-09' },
    { id: 149, name: 'Tiger', species: 'cat', breed: 'Puspin', age_years: 6, gender: 'male', size: 'medium', description: 'Relaxed senior who loves sunny windows.', temperament: 'Laid back and quiet. Happy to nap most of the day.', photo_url: '', status: 'available', rescued_location: 'Barangay Olympia', date_listed: '2026-06-28' },
  ],
  pet_medical_info: [
    { id: 1, pet_id: 142, vaccinated: true, neutered_spayed: true, notes: 'Healed leg fracture, no ongoing treatment needed.' },
    { id: 2, pet_id: 143, vaccinated: true, neutered_spayed: true, notes: '' },
    { id: 3, pet_id: 144, vaccinated: true, neutered_spayed: true, notes: 'Mild skin allergy, managed with diet.' },
    { id: 4, pet_id: 145, vaccinated: true, neutered_spayed: false, notes: 'Scheduled for spay next month.' },
    { id: 5, pet_id: 146, vaccinated: true, neutered_spayed: true, notes: '' },
    { id: 6, pet_id: 147, vaccinated: false, neutered_spayed: false, notes: 'Second vaccine dose due soon.' },
    { id: 7, pet_id: 148, vaccinated: true, neutered_spayed: true, notes: '' },
    { id: 8, pet_id: 149, vaccinated: true, neutered_spayed: true, notes: 'Senior check-up done in September.' },
  ],
  adoption_applications: [
    { id: 1, pet_id: 142, user_id: null, applicant_name: 'Maria Santos', applicant_email: 'maria.santos@example.com', applicant_phone: '0918 555 0142', address: '45 Kalayaan Ave, Poblacion, Makati', residence_type: 'house', experience_notes: 'Had two Aspins for 10 years. Works from home.', status: 'pending', admin_notes: '', created_at: '2026-10-12T09:10:00Z', ...idFields('Maria Santos', 'philsys', 'PhilSys National ID') },
    { id: 2, pet_id: 143, user_id: null, applicant_name: 'Paolo Cruz', applicant_email: 'paolo.cruz@example.com', applicant_phone: '0917 222 3344', address: 'Salcedo Village, Makati', residence_type: 'condo', experience_notes: 'First cat, has researched care basics.', status: 'pending', admin_notes: '', created_at: '2026-10-12T07:30:00Z', ...idFields('Paolo Cruz', 'drivers_license', "Driver's license") },
    { id: 3, pet_id: 145, user_id: null, applicant_name: 'Liza Mendoza', applicant_email: 'liza.m@example.com', applicant_phone: '0919 111 2233', address: 'Guadalupe Nuevo, Makati', residence_type: 'apartment', experience_notes: 'Currently has one senior cat.', status: 'pending', admin_notes: '', created_at: '2026-10-11T12:00:00Z', ...idFields('Liza Mendoza', 'passport', 'Passport', 'verified') },
    { id: 4, pet_id: 148, user_id: null, applicant_name: 'Ramon Garcia', applicant_email: 'ramon.g@example.com', applicant_phone: '0920 333 4455', address: 'Palanan, Makati', residence_type: 'townhouse', experience_notes: 'Grew up with dogs.', status: 'pending', admin_notes: '', created_at: '2026-10-10T10:00:00Z', ...idFields('Ramon Garcia', 'umid', 'UMID') },
    { id: 5, pet_id: 144, user_id: null, applicant_name: 'Ben Villanueva', applicant_email: 'ben.v@example.com', applicant_phone: '0921 444 5566', address: 'San Lorenzo, Makati', residence_type: 'condo', experience_notes: 'Owned a Shih Tzu before.', status: 'approved', admin_notes: 'Home visit done.', created_at: '2026-10-08T10:00:00Z', ...idFields('Ben Villanueva', 'postal', 'Postal ID', 'verified') },
  ],
  services: [
    { id: 1, title: 'Free anti-rabies vaccination', description: 'Yearly anti-rabies shot for pets of Makati residents.', service_type: 'free', pet_type: 'both', availability_schedule: 'Every Saturday, 8 AM – 12 PM', location: 'Makati Veterinary Office', contact_info: '[Contact number]', how_to_avail: 'walk_in', created_by_user_id: 1 },
    { id: 2, title: 'Low-cost spay and neuter', description: 'Subsidized surgery with a post-op check-up included.', service_type: 'discounted', pet_type: 'both', availability_schedule: 'Tue and Thu, by appointment', location: 'Makati Veterinary Office', contact_info: '[Contact number]', how_to_avail: 'appointment', created_by_user_id: 1 },
    { id: 3, title: 'Free deworming', description: 'Deworming tablets for puppies, kittens and adults.', service_type: 'free', pet_type: 'both', availability_schedule: 'Every Saturday, 8 AM – 12 PM', location: 'Barangay health centers', contact_info: '[Contact number]', how_to_avail: 'walk_in', created_by_user_id: 1 },
    { id: 4, title: 'Pet microchipping', description: 'Permanent ID chip registered to your address.', service_type: 'discounted', pet_type: 'both', availability_schedule: 'Wednesdays, by appointment', location: 'Makati Veterinary Office', contact_info: '[Contact number]', how_to_avail: 'appointment', created_by_user_id: 1 },
    { id: 5, title: 'Vet consultation', description: 'General check-up with a licensed city veterinarian.', service_type: 'discounted', pet_type: 'both', availability_schedule: 'Mon to Fri, 9 AM – 4 PM', location: 'Makati Veterinary Office', contact_info: '[Contact number]', how_to_avail: 'appointment', created_by_user_id: 1 },
    { id: 6, title: 'Free pet registration', description: 'Register your dog with the city and get a pet tag.', service_type: 'free', pet_type: 'dog', availability_schedule: 'Mon to Fri, 8 AM – 5 PM', location: 'Makati City Hall, Bldg. II', contact_info: '[Contact number]', how_to_avail: 'walk_in', created_by_user_id: 1 },
  ],
  newsletters: [
    { id: 1, title: 'Adoption Day comes to Washington SyCip Park', summary: 'What to expect on October 25, which pets will be there and how to prepare your home before applying.', body: 'Adoption Day is back on October 25 at Washington SyCip Park.\n\nShelter staff will bring dogs and cats that are vaccinated and ready for a home. Bring a valid ID if you plan to apply on the day, and think about who at home will care for your new pet day to day.\n\nSee you at the park.', published_at: '2026-10-01T08:00:00Z', author_user_id: 1 },
    { id: 2, title: 'Paws Fun Run registration is open', summary: 'Sign-ups for the October run are live, with new volunteer roles for employees.', body: 'Registration for the Paws Fun Run 2026 is now open.\n\nManulife employees can sign up as volunteers and earn volunteer hours.', published_at: '2026-09-02T08:00:00Z', author_user_id: 1 },
    { id: 3, title: 'Vaccination drive recap', summary: 'City vets and volunteers vaccinated pets across barangays in one weekend.', body: 'Thank you to everyone who brought their pets and to the volunteers who helped with registration and handling.', published_at: '2026-08-05T08:00:00Z', author_user_id: 1 },
    { id: 4, title: 'Meet this month\'s adoptees', summary: 'Six dogs and cats found homes, and their families shared first-week photos.', body: 'Six pets went home with new families this month. Here is how they are settling in.', published_at: '2026-07-03T08:00:00Z', author_user_id: 1 },
    { id: 5, title: 'November shelter wishlist', summary: 'Supplies the shelter needs this month.', body: 'Draft: list the food, litter and medicine the shelter needs.', published_at: null, author_user_id: 1 },
  ],
  pet_insurance_policies: [
    { id: 1, user_id: 2, pet_name: 'Mango', species: 'dog', breed: 'Aspin', age_years: 2, policy_status: 'active', created_at: '2026-05-01T08:00:00Z' },
    { id: 2, user_id: 2, pet_name: 'Luna', species: 'cat', breed: 'Puspin', age_years: 1, policy_status: 'pending', created_at: '2026-09-20T08:00:00Z' },
    { id: 3, user_id: 2, pet_name: 'Brownie', species: 'dog', breed: 'Beagle', age_years: 9, policy_status: 'expired', created_at: '2025-03-01T08:00:00Z' },
  ],
};

export default SEED;
