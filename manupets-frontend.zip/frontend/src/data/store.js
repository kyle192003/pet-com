// In-memory data store for the frontend-only app (no backend, no API calls).
//
// Read:   const state = useStore();  then  useMemo(() => selectPets(state, filters), [state, ...])
// Write:  call an action, e.g. createEvent(values). Actions throw an Error with a
//         readable message when something isn't allowed; components show it.
//
// Data resets on page reload. Only the logged-in user id is remembered.
import { useSyncExternalStore } from 'react';
import SEED from './mockData';
import safeStorage from '../utils/safeStorage';

const SESSION_KEY = 'manupets_session_user_id';
const clone = (x) => JSON.parse(JSON.stringify(x));

function initialState() {
  const data = clone(SEED);
  const savedId = Number(safeStorage.get(SESSION_KEY));
  const currentUserId = data.users.some((u) => u.id === savedId) ? savedId : null;
  return { ...data, currentUserId };
}

let state = initialState();
const listeners = new Set();

const subscribe = (listener) => {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
};

export const getState = () => state;

function update(patch) {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
}

export function useStore() {
  return useSyncExternalStore(subscribe, getState, getState);
}

// ---------- helpers ----------
const nextId = (list) => list.reduce((max, item) => Math.max(max, item.id), 0) + 1;
const nowIso = () => new Date().toISOString();
const today = () => new Date().toISOString().slice(0, 10);
const fail = (message) => {
  throw new Error(message);
};

export const currentUser = (s = state) => s.users.find((u) => u.id === s.currentUserId) || null;

export const publicUser = (u) => {
  if (!u) return null;
  const { password, ...rest } = u;
  return rest;
};

const requireUser = (message = 'Log in first.') => currentUser() || fail(message);
const requireRole = (role, message) => {
  const u = currentUser();
  if (!u || u.role !== role) fail(message);
  return u;
};
const requireAdmin = () => requireRole('admin', 'Only admins can do this.');

const replaceById = (list, id, changes) => list.map((x) => (x.id === Number(id) ? { ...x, ...changes } : x));

// ============================================================
// Auth
// ============================================================
export const DEMO_ACCOUNTS = [
  { label: 'Admin (Makati Gov)', email: 'admin@makati.gov.ph', password: 'admin123' },
  { label: 'Manulife employee', email: 'ana.reyes@manulife.com', password: 'employee123' },
  { label: 'Makatizen', email: 'juan@example.com', password: 'makatizen123' },
];

export function login(email, password) {
  const user = state.users.find((u) => u.email.toLowerCase() === String(email).trim().toLowerCase());
  if (!user || user.password !== password) fail('Email or password is incorrect.');
  safeStorage.set(SESSION_KEY, user.id);
  update({ currentUserId: user.id });
  return publicUser(user);
}

export function register(data) {
  if (state.users.some((u) => u.email.toLowerCase() === data.email.toLowerCase())) {
    fail('An account with this email already exists. Log in instead.');
  }
  if (state.users.some((u) => u.username.toLowerCase() === data.username.toLowerCase())) {
    fail('This username is taken. Try another one.');
  }
  const user = {
    id: nextId(state.users),
    role: 'makatizen',
    full_name: data.full_name,
    email: data.email,
    username: data.username,
    password: data.password,
    mobile_number: data.mobile_number,
    address: data.address,
    created_at: nowIso(),
  };
  const volunteers = data.wants_to_volunteer
    ? [
        ...state.volunteers,
        {
          id: nextId(state.volunteers),
          user_id: user.id,
          preferred_pet_type: data.preferred_pet_type,
          skills: data.skills,
          availability_notes: data.availability_notes,
          total_volunteer_hours: 0,
        },
      ]
    : state.volunteers;
  safeStorage.set(SESSION_KEY, user.id);
  update({ users: [...state.users, user], volunteers, currentUserId: user.id });
  return publicUser(user);
}

export function logout() {
  safeStorage.remove(SESSION_KEY);
  update({ currentUserId: null });
}

// ============================================================
// Events
// ============================================================
export function eventView(s, event) {
  const regs = s.event_registrations.filter((r) => r.event_id === event.id && r.status !== 'cancelled');
  const roles = s.volunteer_roles.filter((r) => r.event_id === event.id);
  const { _seed_volunteers = 0, _seed_participants = 0, ...rest } = event;
  return {
    ...rest,
    volunteer_count: _seed_volunteers + regs.filter((r) => r.role_at_event === 'volunteer').length,
    participant_count: _seed_participants + regs.filter((r) => r.role_at_event === 'participant').length,
    volunteer_slots_left: roles.reduce((n, r) => n + r.slots_available, 0),
    volunteer_roles: roles,
  };
}

export function selectEvents(s, filters = {}) {
  let list = s.events.filter((e) => filters.includeInactive || e.is_active);
  if (filters.type) list = list.filter((e) => e.event_type === filters.type);
  if (filters.from) list = list.filter((e) => e.date >= filters.from);
  if (filters.to) list = list.filter((e) => e.date <= filters.to);
  if (filters.location) list = list.filter((e) => e.location === filters.location);
  if (filters.volunteerOnly) list = list.filter((e) => e.is_volunteer_event);
  if (filters.hoursEligibleOnly) list = list.filter((e) => e.is_hours_eligible);
  return list
    .slice()
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((e) => eventView(s, e));
}

export function selectEvent(s, id) {
  const event = s.events.find((e) => e.id === Number(id));
  return event ? eventView(s, event) : null;
}

export function selectMyRegistrations(s) {
  return s.event_registrations.filter((r) => r.user_id === s.currentUserId && r.status !== 'cancelled');
}

export function createEvent(data) {
  const admin = requireAdmin();
  const event = { ...data, id: nextId(state.events), created_by_user_id: admin.id, created_at: nowIso() };
  update({ events: [...state.events, event] });
  return event;
}

export function updateEvent(id, data) {
  requireAdmin();
  update({ events: replaceById(state.events, id, data) });
}

export function deleteEvent(id) {
  requireAdmin();
  update({ events: state.events.filter((e) => e.id !== Number(id)) });
}

export function registerForEvent(eventId, roleAtEvent) {
  const user = requireUser('Log in to register for this event.');
  const event = state.events.find((e) => e.id === Number(eventId)) || fail('This event no longer exists.');
  const existing = state.event_registrations.find(
    (r) => r.event_id === event.id && r.user_id === user.id && r.status !== 'cancelled',
  );
  if (existing) fail(`You're already registered as a ${existing.role_at_event}.`);
  update({
    event_registrations: [
      ...state.event_registrations,
      {
        id: nextId(state.event_registrations),
        event_id: event.id,
        user_id: user.id,
        role_at_event: roleAtEvent,
        status: 'confirmed',
        hours_credited: 0,
      },
    ],
  });
}

// ============================================================
// Volunteers
// ============================================================
export function selectMyAssignments(s) {
  return s.volunteer_assignments.filter((a) => a.user_id === s.currentUserId);
}

export function selectVolunteerSummary(s) {
  const volunteer = s.volunteers.find((v) => v.user_id === s.currentUserId);
  const mine = selectMyAssignments(s);
  return {
    total_hours: volunteer?.total_volunteer_hours ?? 0,
    completed: mine.filter((a) => a.status === 'completed').length,
    upcoming: mine.filter((a) => a.status === 'assigned').length,
    goal_hours: 40, // [placeholder] yearly goal set by the program
  };
}

export function signUpForRole(roleId) {
  const user = requireUser('Log in to sign up as a volunteer.');
  const role = state.volunteer_roles.find((r) => r.id === Number(roleId)) || fail('This volunteer role no longer exists.');
  if (state.volunteer_assignments.some((a) => a.volunteer_role_id === role.id && a.user_id === user.id)) {
    fail("You're already signed up for this role.");
  }
  if (role.slots_available <= 0) fail('This role is full. Pick another role.');
  update({
    volunteer_roles: replaceById(state.volunteer_roles, role.id, { slots_available: role.slots_available - 1 }),
    volunteer_assignments: [
      ...state.volunteer_assignments,
      { id: nextId(state.volunteer_assignments), volunteer_role_id: role.id, user_id: user.id, status: 'assigned', hours_earned: 0 },
    ],
  });
  return role;
}

// ============================================================
// Pets
// ============================================================
const AGE_GROUPS = {
  under1: (y) => y < 1,
  '1to5': (y) => y >= 1 && y <= 5,
  over5: (y) => y > 5,
};

export function selectPets(s, filters = {}) {
  let list = s.pets.filter((p) => filters.includeArchived || p.status !== 'archived');
  if (filters.species) list = list.filter((p) => p.species === filters.species);
  if (filters.size) list = list.filter((p) => p.size === filters.size);
  if (filters.status) list = list.filter((p) => p.status === filters.status);
  if (filters.age && AGE_GROUPS[filters.age]) list = list.filter((p) => AGE_GROUPS[filters.age](p.age_years));
  return list;
}

export function selectPet(s, id) {
  const pet = s.pets.find((p) => p.id === Number(id));
  if (!pet) return null;
  return { ...pet, medical: s.pet_medical_info.find((m) => m.pet_id === pet.id) || null };
}

export function createPet(data) {
  requireAdmin();
  const pet = { photo_url: '', temperament: '', rescued_location: '', ...data, id: nextId(state.pets), date_listed: today() };
  update({ pets: [...state.pets, pet] });
  return pet;
}

export function updatePet(id, data) {
  requireAdmin();
  update({ pets: replaceById(state.pets, id, data) });
}

export function archivePet(id) {
  updatePet(id, { status: 'archived' });
}

// ============================================================
// Adoption applications
// ============================================================
const withPet = (s, app) => {
  const pet = s.pets.find((p) => p.id === app.pet_id);
  return { ...app, pet_name: pet?.name ?? 'Unknown pet', pet_species: pet?.species };
};

export function selectApplications(s, status) {
  let list = s.adoption_applications;
  if (status) list = list.filter((a) => a.status === status);
  return list
    .slice()
    .sort((a, b) => b.created_at.localeCompare(a.created_at))
    .map((a) => withPet(s, a));
}

export function submitApplication(data) {
  const user = currentUser();
  const pet = state.pets.find((p) => p.id === Number(data.pet_id)) || fail('This pet is no longer listed.');
  if (pet.status === 'adopted') fail(`${pet.name} has already been adopted.`);
  if (!data.valid_id_image) fail('Upload a valid ID to submit your application.');
  if (!data.id_terms_accepted || !data.privacy_consent) {
    fail('Agree to the Terms and Conditions and the Data Privacy Act consent before submitting.');
  }
  const app = {
    ...data,
    pet_id: pet.id,
    id: nextId(state.adoption_applications),
    user_id: user?.id ?? null,
    status: 'pending',
    admin_notes: '',
    id_verification_status: 'unverified',
    created_at: nowIso(),
  };
  update({ adoption_applications: [...state.adoption_applications, app] });
  return withPet(state, app);
}

// Admin checks the uploaded ID: 'verified' | 'mismatch' | 'unverified'
export function setIdVerification(id, verification) {
  const admin = requireRole('admin', 'Only admins can verify IDs.');
  state.adoption_applications.find((a) => a.id === Number(id)) || fail('This application no longer exists.');
  update({
    adoption_applications: replaceById(state.adoption_applications, id, {
      id_verification_status: verification,
      id_verified_by_user_id: verification === 'unverified' ? null : admin.id,
      id_verified_at: verification === 'unverified' ? null : nowIso(),
    }),
  });
}

// Approving needs a verified ID, and marks the pet as adopted
export function updateApplication(id, { status, admin_notes }) {
  requireRole('admin', 'Only admins can review applications.');
  const app = state.adoption_applications.find((a) => a.id === Number(id)) || fail('This application no longer exists.');
  if (status === 'approved' && app.status !== 'approved' && app.id_verification_status !== 'verified') {
    fail("Verify the applicant's ID before approving.");
  }
  const changes = {};
  if (status) changes.status = status;
  if (admin_notes !== undefined) changes.admin_notes = admin_notes;
  update({
    adoption_applications: replaceById(state.adoption_applications, id, changes),
    pets: status === 'approved' ? replaceById(state.pets, app.pet_id, { status: 'adopted' }) : state.pets,
  });
  return withPet(state, { ...app, ...changes });
}

// ============================================================
// Services
// ============================================================
export function selectServices(s, filters = {}) {
  let list = s.services;
  if (filters.type) list = list.filter((x) => x.service_type === filters.type);
  if (filters.petType) list = list.filter((x) => x.pet_type === filters.petType || x.pet_type === 'both');
  return list;
}

export function createService(data) {
  const admin = requireAdmin();
  update({ services: [...state.services, { ...data, id: nextId(state.services), created_by_user_id: admin.id }] });
}

export function updateService(id, data) {
  requireAdmin();
  update({ services: replaceById(state.services, id, data) });
}

export function deleteService(id) {
  requireAdmin();
  update({ services: state.services.filter((x) => x.id !== Number(id)) });
}

// ============================================================
// Newsletters (published_at = null means draft)
// ============================================================
const byNewest = (a, b) => (b.published_at || '9999').localeCompare(a.published_at || '9999');

export function selectNewsletters(s, { includeDrafts = false } = {}) {
  return s.newsletters.filter((n) => includeDrafts || n.published_at).slice().sort(byNewest);
}

export function selectNewsletter(s, id) {
  return s.newsletters.find((n) => n.id === Number(id)) || null;
}

export function createNewsletter({ publish, ...data }) {
  const admin = requireAdmin();
  const item = { ...data, id: nextId(state.newsletters), author_user_id: admin.id, published_at: publish ? nowIso() : null };
  update({ newsletters: [...state.newsletters, item] });
}

export function updateNewsletter(id, { publish, ...data }) {
  requireAdmin();
  const item = state.newsletters.find((n) => n.id === Number(id)) || fail('This newsletter no longer exists.');
  let published_at = item.published_at;
  if (publish && !published_at) published_at = nowIso();
  if (publish === false) published_at = null;
  update({ newsletters: replaceById(state.newsletters, id, { ...data, published_at }) });
}

export function deleteNewsletter(id) {
  requireAdmin();
  update({ newsletters: state.newsletters.filter((n) => n.id !== Number(id)) });
}

// ============================================================
// Pet insurance (Manulife employees only)
// ============================================================
export function selectMyPolicies(s) {
  return s.pet_insurance_policies
    .filter((p) => p.user_id === s.currentUserId)
    .slice()
    .sort((a, b) => b.created_at.localeCompare(a.created_at));
}

export function enrollPet(data) {
  const user = requireRole('employee', 'Pet insurance is for Manulife employees only.');
  const policy = { ...data, id: nextId(state.pet_insurance_policies), user_id: user.id, policy_status: 'pending', created_at: nowIso() };
  update({ pet_insurance_policies: [...state.pet_insurance_policies, policy] });
  return policy;
}

// ============================================================
// Admin dashboard counts
// ============================================================
export function selectAdminStats(s) {
  return {
    activeEvents: s.events.filter((e) => e.is_active).length,
    pendingApplications: s.adoption_applications.filter((a) => a.status === 'pending').length,
    volunteers: s.volunteers.length,
    services: s.services.length,
  };
}
