# ManuPets – Frontend (React + Vite + Tailwind CSS)

Makati LGU x Manulife pet initiative: adoption, events, volunteering, animal
services, newsletters and pet insurance for Manulife employees.

## Run it

```bash
cd frontend
npm install
cp .env.example .env      # optional, mock mode is on by default
npm run dev               # http://localhost:5173
```

### Mock mode (default)

With `VITE_USE_MOCK=true` (or no `.env`), the app uses built-in sample data
saved in your browser, so the whole frontend works before the backend is
ready. Demo logins are shown on the login page:

| Role | Email | Password |
| --- | --- | --- |
| Admin (Makati Gov) | admin@makati.gov.ph | admin123 |
| Manulife employee | ana.reyes@manulife.com | employee123 |
| Makatizen | juan@example.com | makatizen123 |

To reset the sample data, run `localStorage.clear()` in the browser console.

### Real backend

Set in `.env`:

```
VITE_API_URL=http://localhost:5000/api
VITE_USE_MOCK=false
```

Only the files in `src/api/` talk to the backend. Components never change.

## Styling

Tailwind CSS v4 via `@tailwindcss/vite`. Brand tokens live in
`src/assets/styles/main.css` under `@theme`:

| Class | Color | Use |
| --- | --- | --- |
| `bg-brand` / `text-brand` | #008657 | Buttons, headers |
| `brand-dark` | #00663f | Hover, text on light green |
| `brand-bright` | #00a86b | Decoration, focus ring |
| `brand-tint` | #e6fff3 | Soft backgrounds |
| `text-muted` | black 66% | Secondary text |
| `border-line` | black 12% | Dividers |

Only white, black and green are used. To rename the app, change `APP_NAME`
in `src/config.js`.

## Folder structure

```
frontend/
├── index.html                  # Vite needs this at the root (not in public/)
├── public/favicon.svg
├── src/
│   ├── assets/
│   │   ├── images/             # put logo-manulife.png, logo-makati.png, pets/*.jpg here
│   │   └── styles/
│   │       ├── main.css        # Tailwind import + brand theme
│   │       └── components.css  # keyframes, reduced motion
│   ├── components/
│   │   ├── common/             # Navbar, Footer, Button, Card (+Tag, Meta, DateBlock),
│   │   │                       # FormField, PageHeader, PageContainer, SectionHeader,
│   │   │                       # Modal, DataTable, Feedback, Icons, Illustrations
│   │   ├── auth/               # LoginForm, RegisterForm
│   │   ├── dashboard/          # AdminDashboard, EmployeeDashboard, MakatizenDashboard
│   │   ├── events/             # EventsList (+EventCard), EventDetail
│   │   ├── volunteers/         # VolunteerOpportunities
│   │   ├── services/           # ServicesList (+ServiceCard)
│   │   ├── pets/               # PetsList (+PetCard), PetDetail
│   │   ├── adoptions/          # AdoptionForm
│   │   ├── newsletters/        # NewsletterList, NewsletterDetail
│   │   ├── insurance/          # PetInsurancePage
│   │   └── admin/              # NEW: CrudManager, ManageEvents, ManagePets,
│   │                           # ReviewApplications, ManageServices, ManageNewsletters
│   ├── pages/                  # route-level pages (+ AdminPage, NotFoundPage)
│   ├── api/                    # http.js + *.api.js (+ mockDb.js for mock mode)
│   ├── hooks/                  # useAuth, useUserRole, useFetch
│   ├── router/AppRouter.jsx    # routes + role guards
│   ├── context/AuthContext.jsx
│   ├── utils/                  # NEW: format.js, cx.js
│   ├── config.js               # NEW: app name, API URL, mock switch
│   ├── App.jsx
│   └── index.jsx               # React DOM render
├── package.json
└── README.md
```

## Routes

| Path | Who | Page |
| --- | --- | --- |
| `/login`, `/register` | Guests | Auth |
| `/` | Logged in | Dashboard for the user's role |
| `/events`, `/events/:id` | Everyone | Events list, event detail |
| `/volunteer` | Everyone (sign-up needs login) | Volunteer opportunities |
| `/services` | Everyone | Animal welfare services |
| `/pets`, `/pets/:id` | Everyone | Pets for adoption, pet detail |
| `/adopt/:petId` | Makatizen, employee | Adoption form |
| `/newsletters`, `/newsletters/:id` | Everyone | Newsletter list, issue |
| `/insurance` | Employee | Pet insurance |
| `/admin/events` `/admin/pets` `/admin/applications` `/admin/services` `/admin/newsletters` | Admin | Section 10 management pages |

## API the frontend expects (for the Express team)

All requests send `Authorization: Bearer <token>` when logged in. Errors
should return `{ "message": "..." }`; the frontend shows that text.

| Method | Path | Body / query | Returns |
| --- | --- | --- | --- |
| POST | `/auth/login` | `email, password` | `{ token, user }` |
| POST | `/auth/register` | `full_name, username, email, password, mobile_number, address, wants_to_volunteer, preferred_pet_type, skills, availability_notes` | `{ token, user }` |
| GET | `/auth/me` | | `user` |
| GET | `/events` | `type, from, to, location, volunteerOnly, hoursEligibleOnly, includeInactive` | events[] |
| GET | `/events/:id` | | event |
| POST / PUT / DELETE | `/events`, `/events/:id` | event fields | event |
| POST | `/events/:id/register` | `role_at_event` | event |
| GET | `/events/registrations/me` | | registrations[] |
| GET | `/volunteers/opportunities` | `hoursEligibleOnly` | events[] |
| POST | `/volunteers/roles/:roleId/signup` | | role |
| GET | `/volunteers/assignments/me` | | assignments[] |
| GET | `/volunteers/me/summary` | | `{ total_hours, completed, upcoming, goal_hours }` |
| GET | `/volunteers` | | volunteers[] (admin) |
| GET | `/pets` | `species, size, age (under1, 1to5, over5), status, includeArchived` | pets[] |
| GET | `/pets/:id` | | pet with `medical` |
| POST / PUT | `/pets`, `/pets/:id` | pet fields | pet |
| PATCH | `/pets/:id/archive` | | pet |
| POST | `/adoptions` | application fields | application |
| GET | `/adoptions` | `status` | applications[] with `pet_name` (admin) |
| PATCH | `/adoptions/:id` | `status, admin_notes` | application |
| GET | `/services` | `type, petType` | services[] |
| POST / PUT / DELETE | `/services`, `/services/:id` | service fields | service |
| GET | `/newsletters` | `includeDrafts` | newsletters[] |
| GET | `/newsletters/:id` | | newsletter |
| POST / PUT / DELETE | `/newsletters`, `/newsletters/:id` | `title, summary, body, publish` | newsletter |
| GET | `/insurance/policies/me` | | policies[] (employee) |
| POST | `/insurance/policies` | `pet_name, species, breed, age_years` | policy |

Event objects should include computed `volunteer_count`,
`participant_count`, `volunteer_slots_left` and `volunteer_roles[]`.

### Columns added beyond the brainstorm doc

The UI needs these, so please add them to the tables:

- `users.email`, `users.username` (login uses email)
- `events.short_description`, `is_active`, `is_volunteer_event`, `is_hours_eligible`;
  `event_type` values: `fun_run`, `adoption_day`, `volunteer`, `recreational`
- `pets.temperament`
- `adoption_applications.residence_type`
- `services.how_to_avail` (`walk_in` | `appointment`)
- `newsletter.summary`, `body`; `published_at = null` means draft

Values in `[brackets]` (insurance coverage limit, age range, review time,
volunteer hour goal) are placeholders for the real program details.
