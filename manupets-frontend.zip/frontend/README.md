# ManuPets – Frontend (React + Vite + Tailwind CSS)

Makati LGU x Manulife pet initiative: adoption, events, volunteering, animal
services, newsletters and pet insurance for Manulife employees.

## Run it

```bash
cd frontend
npm install
npm run dev               # http://localhost:5173
```

This is a **frontend-only** build: no backend and no API calls. All data
comes from `src/data/mockData.js` and lives in memory, so changes (new
events, applications, sign-ups) reset when you reload the page. Only the
logged-in user is remembered.

Demo logins (also shown on the login page):

| Role | Email | Password |
| --- | --- | --- |
| Admin (Makati Gov) | admin@makati.gov.ph | admin123 |
| Manulife employee | ana.reyes@manulife.com | employee123 |
| Makatizen | juan@example.com | makatizen123 |

### How data flows

- `src/data/mockData.js`: sample rows, named like the planned database tables
- `src/data/store.js`: `useStore()` to read, `select*()` helpers to filter,
  and actions like `createEvent()` or `submitApplication()` to change data
- Components never call a server. When the backend is ready, the store's
  actions are the one place to swap in real requests.

### If the page ever goes blank

The app now shows an error screen with the message instead of a blank
page. If you still see white, open DevTools (F12) → Console and share the
red error.

## Styling

Tailwind CSS v4 via `@tailwindcss/vite`. Brand tokens live in
`src/assets/styles/main.css` under `@theme`:

| Class | Color | Use |
| --- | --- | --- |
| `bg-brand` / `text-brand` | #008657 | Buttons, headers |
| `brand-dark` | #00663f | Hover, text on light green |
| `brand-bright` | #00a86b | Decoration, focus ring |
| `brand-tint` | #e6fff3 | Soft backgrounds |
| `text-muted` | black 66% | Secondary text |
| `border-line` | black 12% | Dividers |

Only white, black and green are used. To rename the app, change `APP_NAME`
in `src/config.js`.

## Folder structure

```
frontend/
├── index.html                  # Vite needs this at the root (not in public/)
├── public/favicon.svg
├── src/
│   ├── assets/
│   │   ├── images/             # put logo-manulife.png, logo-makati.png, pets/*.jpg here
│   │   └── styles/
│   │       ├── main.css        # Tailwind import + brand theme
│   │       └── components.css  # keyframes, reduced motion
│   ├── components/
│   │   ├── common/             # Navbar, Footer, Button, Card (+Tag, Meta, DateBlock),
│   │   │                       # FormField, PageHeader, PageContainer, SectionHeader,
│   │   │                       # Modal, DataTable, Feedback, Icons, Illustrations, ErrorBoundary
│   │   ├── auth/               # LoginForm, RegisterForm
│   │   ├── dashboard/          # AdminDashboard, EmployeeDashboard, MakatizenDashboard
│   │   ├── events/             # EventsList (+EventCard), EventDetail
│   │   ├── volunteers/         # VolunteerOpportunities
│   │   ├── services/           # ServicesList (+ServiceCard)
│   │   ├── pets/               # PetsList (+PetCard), PetDetail
│   │   ├── adoptions/          # AdoptionForm, IdUpload, IdPrivacyNotice (terms + RA 10173 notice)
│   │   ├── newsletters/        # NewsletterList, NewsletterDetail
│   │   ├── insurance/          # PetInsurancePage
│   │   └── admin/              # NEW: CrudManager, ManageEvents, ManagePets, ReviewApplications,
│   │                           # IdVerification, ManageServices, ManageNewsletters
│   ├── pages/                  # route-level pages (+ AdminPage, NotFoundPage)
│   ├── data/                   # NEW: mockData.js (sample data), store.js (in-memory store)
│   ├── hooks/                  # useAuth, useUserRole, useFetch (unused until backend)
│   ├── router/AppRouter.jsx    # routes + role guards
│   ├── context/AuthContext.jsx
│   ├── utils/                  # NEW: format.js, cx.js, safeStorage.js
│   ├── config.js               # NEW: app name, roles
│   ├── App.jsx
│   └── index.jsx               # React DOM render
├── package.json
└── README.md
```

## Routes

| Path | Who | Page |
| --- | --- | --- |
| `/login`, `/register` | Guests | Auth |
| `/` | Logged in | Dashboard for the user's role |
| `/events`, `/events/:id` | Everyone | Events list, event detail |
| `/volunteer` | Everyone (sign-up needs login) | Volunteer opportunities |
| `/services` | Everyone | Animal welfare services |
| `/pets`, `/pets/:id` | Everyone | Pets for adoption, pet detail |
| `/adopt/:petId` | Makatizen, employee | Adoption form |
| `/newsletters`, `/newsletters/:id` | Everyone | Newsletter list, issue |
| `/insurance` | Employee | Pet insurance |
| `/admin/events` `/admin/pets` `/admin/applications` `/admin/services` `/admin/newsletters` | Admin | Section 10 management pages |

## Valid ID upload and Data Privacy Act consent

The adoption form asks for a photo of a valid government ID so an admin can
verify the applicant.

1. The applicant reads a short summary and can open the full Terms and
   Conditions and Privacy Notice (Data Privacy Act of 2012, RA 10173).
2. The upload box stays locked until both boxes are checked: the Terms for ID
   upload and the data privacy consent.
3. They choose the ID type and upload a JPG, PNG or WEBP photo (up to 5 MB).
4. On the admin side, Review Applications shows the ID with a full-size view.
   The admin marks it **verified** or **doesn't match**. **Approve stays
   locked until the ID is verified.**

The notice text is in `src/components/adoptions/IdPrivacyNotice.jsx`. It is a
template: have the Makati LGU Data Protection Officer or legal team review it
and fill in every `[bracketed]` value (office name, retention period, DPO
contact, date).

## Notes for the backend team

### Handling ID images

In this frontend-only build the ID photo is kept in memory as a data URL.
When you store real IDs:

- Keep them in private storage (not a public URL); serve them only to admins
  through an authenticated request
- Encrypt at rest and log who viewed each ID
- Delete them after the retention period in the privacy notice
- Save the consent record: `privacy_consent`, `id_terms_accepted`,
  `consent_at`, `terms_version`


### Columns the UI uses beyond the brainstorm doc

The UI needs these, so please add them to the tables:

- `users.email`, `users.username` (login uses email)
- `events.short_description`, `is_active`, `is_volunteer_event`, `is_hours_eligible`;
  `event_type` values: `fun_run`, `adoption_day`, `volunteer`, `recreational`
- `pets.temperament`
- `adoption_applications.residence_type`
- `adoption_applications.valid_id_type`, `valid_id_image` (file reference),
  `valid_id_file_name`, `id_terms_accepted`, `privacy_consent`, `consent_at`,
  `terms_version`, `id_verification_status` (`unverified` | `verified` |
  `mismatch`), `id_verified_by_user_id`, `id_verified_at`
- `services.how_to_avail` (`walk_in` | `appointment`)
- `newsletter.summary`, `body`; `published_at = null` means draft

Values in `[brackets]` (insurance coverage limit, age range, review time,
volunteer hour goal) are placeholders for the real program details.
